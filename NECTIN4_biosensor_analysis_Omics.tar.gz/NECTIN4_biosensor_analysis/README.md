# NECTIN4 EV-biosensor target-nomination analysis

Bioinformatics pipeline behind the figures of the lung-adenocarcinoma (LUAD)
NECTIN4 extracellular-vesicle (EV) photonic-crystal biosensor study.

The analysis is framed not as biomarker *discovery* (NECTIN4 over-expression
in lung cancer is established since Takano *et al.*, 2009) but as a
**topology-constrained algorithm that nominates and validates a single
SELEX-tractable, EV-displayable surface analyte** for the sensor.

---

## Repository layout

```
NECTIN4_biosensor_analysis/
├── README.md
├── requirements.txt
├── run_all.sh                      # reproduce every figure end-to-end
├── FIGURE_LEGENDS.md               # final English legends, Fig 1–3
├── MANUSCRIPT_DRAFT.md             # defensive prose for the key reviewer points
├── scripts/
│   ├── figures/                    # one script per (group of) figure(s)
│   │   ├── fig_utils.py                       # shared palette + helpers
│   │   ├── figure1_selection_cascade.py       # → Figure 1
│   │   ├── figure2_validation.py              # → Figure 2
│   │   ├── figure3_ev_display.py              # → Figure 3
│   │   ├── figureS1_S3_qc_candidates.py       # → Figure S1 (QC) + S3 (candidates)
│   │   ├── figureS2_coexpression.py           # → Figure S2 (co-expression neighbourhood)
│   │   ├── figureS4_specificity_discordance.py# → Figure S4 (HPA specificity + mRNA-protein)
│   │   ├── figureS5_hpa_ihc_gallery.py        # → Figure S5 (HPA IHC image gallery)
│   │   └── figureS6_singlecell_ev.py          # → Figure S6 (single-cell EV co-expression)
│   └── analysis/                   # upstream calculations consumed by the figures
│       ├── topology_filter.py                 # surface-topology hard filter → candidate set
│       ├── rank_sensitivity.py                # weight-grid / Borda / Dirichlet rank stability
│       ├── extra_cohorts_effectsize.py        # Hedges' g in extra LUAD GEO cohorts
│       ├── auc_options_audit.py               # honest audit of every defensible AUC
│       ├── pooled_meta_auc.py                 # within-cohort z-normalised pooled meta-AUC
│       └── infercnv_malignancy.py             # Kim 2020 inferCNV malignant-cell calls
├── results/                        # small derived tables (committed for convenience)
└── figures/                        # rendered PNG previews of the final figures
```

---

## Final figure set

**Main**
| Figure | Script | Content |
|--------|--------|---------|
| 1 | `figure1_selection_cascade.py` | pipeline schematic; PRISMA-style selection flowchart; volcano; T-vs-N; stage forest; Stage-I ROC; matched-pair Wilcoxon |
| 2 | `figure2_validation.py` | GSE19188 histology violins; 7-cohort effect-size forest (+ ESMO 2025 / Duravelo precedent); tissue-origin enrichment; per-donor KNUH reproducibility |
| 3 | `figure3_ev_display.py` | bulk EV-machinery bars; NECTIN4↔EV Pearson; scRNA cell-type heatmap; NECTIN4⁺/⁻ malignant co-expression; NECTIN-family EV evidence |

**Supplementary** (S1–S6)
| Figure | Script |
|--------|--------|
| S1 (QC) + S3 (candidate landscape & scoring robustness) | `figureS1_S3_qc_candidates.py` |
| S2 (NECTIN4 co-expression neighbourhood) | `figureS2_coexpression.py` |
| S4 (HPA specificity & mRNA–protein discordance) | `figureS4_specificity_discordance.py` |
| S5 (HPA IHC image gallery) | `figureS5_hpa_ihc_gallery.py` |
| S6 (single-cell EV co-expression, two LUAD cohorts) | `figureS6_singlecell_ev.py` |

---

## Reproducing the figures

```bash
pip install -r requirements.txt
# place input data (see below) under ./data and ./results
PYTHON=python ./run_all.sh
```

Figures render to `./figures/` as both `.pdf` (vector, fonttype 42) and
`.png` (350 dpi). Fonts default to **TeX Gyre Heros** (a metric-compatible
free Helvetica clone); install the four `texgyreheros-*.otf` files into a
font directory on your system, or the scripts fall back to Helvetica /
Arial / Nimbus Sans automatically.

---

## Input data (not committed — license / size)

Place the following under `./data` and `./results` before running. None are
redistributed here; download from the original public sources.

| Path | Source |
|------|--------|
| `data/TCGA-LUAD.*` | TCGA-LUAD bulk RNA-seq counts + phenotype (GDC / UCSC Xena) |
| `results/tcga_log2cpm.csv.gz`, `deg_results.csv`, `tcga_metadata.csv` | upstream TCGA DE pipeline outputs |
| `results/dep_results.csv` | CPTAC-LUAD TMT-10 proteomics differential abundance |
| `data/GSE19188`, `GSE31210`, `GSE40791` | NSCLC / LUAD microarray series matrices (GEO) |
| `data/GSE131907/GSE131907_processed.h5ad` | Kim 2020 LUAD scRNA-seq (208k cells) |
| `results/sc_nectin4_ev.csv`, `sc_barcode_origin.csv`, `scrna2_per_donor_nectin4.csv` | scRNA-derived NECTIN4 / EV-gene matrices |
| `data/HPA/nectin4.xml` + `data/HPA/ihc/*.jpg` | Human Protein Atlas NECTIN4 (antibody HPA010775) |

---

## Key external references baked into the figures

- Takano *et al.*, *Cancer Res* 2009 — original NECTIN4 NSCLC biomarker report (IHC + serum ELISA).
- Brägelmann *et al.*, ESMO 2025 poster 161P — NECTIN4 amplification in 583 NSCLC; IHC↔CN ρ = 0.67.
- Duravelo-1 (NCT04561362) — zelenectide pevedotin 40 % RR in NECTIN4-amplified NSCLC.
- ExoCarta v5 / Vesiclepedia v5.1 — NECTIN-family EV cargo records (NECTIN4 in A549 sEVs by MS).
