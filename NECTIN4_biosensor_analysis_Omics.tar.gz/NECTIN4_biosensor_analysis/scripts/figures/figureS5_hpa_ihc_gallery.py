#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════
Figure S8 — Human Protein Atlas IHC images of NECTIN4
═══════════════════════════════════════════════════════════════
Six representative IHC tissue micrographs from HPA (Antibody HPA010775):
  a  Normal lung               — patient 2101   (Not detected)
  b  Lung cancer (medium)      — patient 3391   (membranous brown)
  c  Lung cancer (medium)      — patient 2050
  d  Lung cancer (negative)    — patient 3003
  e  Urothelial cancer (high)  — patient 1871   (positive control)
  f  Breast cancer (medium)    — patient 1838
  g  Quantitative staining summary across HPA lung-cancer cores
═══════════════════════════════════════════════════════════════
"""
import warnings; warnings.filterwarnings("ignore")
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.image as mpimg
from matplotlib.colors import to_rgba
from matplotlib.patches import Rectangle, FancyBboxPatch
import seaborn as sns

R = Path("results"); F = Path("figures"); F.mkdir(exist_ok=True)
DATA = Path("data")
IHC  = DATA/"HPA/ihc"

C = {
    "ink":    "#26333D", "tumor":  "#9E3B4E", "normal": "#6E94A6",
    "star":   "#C06A33", "sage":   "#6E8C73", "gold":   "#C9A24A",
    "plum":   "#7C6884", "grey":   "#AEACA2", "pale":   "#EDE7DC",
    "mist":   "#D3D8DA", "line":   "#9AA0A4",
}
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["TeX Gyre Heros","Helvetica Neue","Helvetica","Arial","Nimbus Sans","Liberation Sans","DejaVu Sans"],
    "font.size":11, "axes.titlesize":12, "axes.labelsize":11,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9,
    "figure.dpi": 300, "savefig.dpi": 300, "savefig.bbox": "standard",
    "axes.linewidth": 0.6, "axes.edgecolor": C["ink"],
    "axes.labelcolor": C["ink"], "text.color": C["ink"],
    "xtick.color": C["ink"], "ytick.color": C["ink"],
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "axes.spines.top": False, "axes.spines.right": False,
    "lines.linewidth": 1.0, "pdf.fonttype": 42, "ps.fonttype": 42,
})
sns.set_style("ticks")
def lab(ax, s, x=-0.06, y=1.05):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=11,
            fontweight="bold", va="top", ha="left", color=C["ink"])
def style(ax):
    for sp in ax.spines.values():
        sp.set_color(C["ink"]); sp.set_linewidth(0.6)

# ── Build IHC image panel layout ──────────────────────────────
IMG_PANELS = [
    ("a", "normal_lung_p2101.jpg",         "Normal lung",            "Not detected",     "p 2101",  C["normal"]),
    ("b", "lung_cancer_p3391_medium.jpg",  "LUAD (positive)",        "Medium / Moderate","p 3391",  C["tumor"]),
    ("c", "lung_cancer_p2050_medium.jpg",  "LUAD (positive)",        "Medium / Moderate","p 2050",  C["tumor"]),
    ("d", "lung_cancer_p3003_neg.jpg",     "LUAD (negative case)",   "Not detected",     "p 3003",  C["grey"]),
    ("e", "urothelial_p1871_high.jpg",     "Urothelial cancer",      "High / Strong",    "p 1871",  C["star"]),
    ("f", "breast_p1838_medium.jpg",       "Breast cancer",          "Medium / Moderate","p 1838",  C["plum"]),
]

# ── Parse HPA XML for quantitative summary of lung-cancer staining ──
def parse_lung_cancer_staining():
    root = ET.parse(DATA/"HPA/nectin4.xml").getroot()
    entry = root.find("entry")
    out = {"High":0, "Medium":0, "Low":0, "Not detected":0}
    for ab in entry.findall("antibody"):
        for te in ab.findall("tissueExpression"):
            if te.get("assayType") != "cancer": continue
            for d in te.findall("data"):
                tissue = d.find("tissue")
                if tissue is None: continue
                if "lung" not in (tissue.text or "").lower(): continue
                for pat in d.findall("patient"):
                    stain = pat.find("level[@type='staining']")
                    if stain is not None and stain.text in out:
                        out[stain.text] += 1
    return out
lung_stain = parse_lung_cancer_staining()
print("Lung-cancer staining distribution:", lung_stain)

# ══════════════════════════════════════════════════════════════
# Build figure
# ══════════════════════════════════════════════════════════════
W2 = 180/25.4
fig = plt.figure(figsize=(14, 11))
gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.30, wspace=0.18,
                       left=0.04, right=0.97, top=0.94, bottom=0.07,
                       height_ratios=[1.0, 1.0, 0.50])

# Row 1+2: IHC image grid (3 cols × 2 rows = 6 panels)
for i, (letter, fname, title, stain, pid, col) in enumerate(IMG_PANELS):
    r, c = i // 3, i % 3
    ax = fig.add_subplot(gs[r, c])
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values(): sp.set_visible(False)
    img_path = IHC/fname
    if img_path.exists():
        img = mpimg.imread(img_path)
        ax.imshow(img, aspect="equal")
        # Coloured frame
        for sp in ax.spines.values():
            sp.set_visible(True); sp.set_color(col); sp.set_linewidth(2.0)
    else:
        ax.text(0.5, 0.5, f"image missing\n{fname}", transform=ax.transAxes,
                ha="center", va="center", color=C["grey"])
    # Panel label
    ax.text(-0.04, 1.04, letter, transform=ax.transAxes, fontsize=11,
            fontweight="bold", va="top", ha="left", color=C["ink"])
    # [removed for Nature style] ax.set_title(title, fontsize=12, color=col, fontweight="bold", pad=4)
    # Sub-caption: staining + patient
    ax.text(0.5, -0.04, f"{stain}   ({pid})",
            transform=ax.transAxes, ha="center", va="top",
            fontsize=10, color=col, fontstyle="italic")

# Row 3: Quantitative staining summary across all HPA lung-cancer cores
ax = fig.add_subplot(gs[2, :]); lab(ax, "g", x=-0.02, y=1.10); style(ax)
order = ["Not detected","Low","Medium","High"]
counts = [lung_stain.get(k, 0) for k in order]
cols_g = [C["grey"], C["gold"], C["plum"], C["star"]]
total = sum(counts) if sum(counts)>0 else 1
xpos = np.arange(len(order))
ax.bar(xpos, counts, color=cols_g, edgecolor="white", lw=0.5, width=0.65)
for x, c, n in zip(xpos, counts, [counts[i] for i in range(len(counts))]):
    if c > 0:
        ax.text(x, c+0.3, f"{c}  ({100*c/total:.0f}%)",
                ha="center", va="bottom", fontsize=11, fontweight="bold",
                color=cols_g[xpos.tolist().index(x)])
ax.set_xticks(xpos)
ax.set_xticklabels(order, fontsize=11)
ax.set_ylabel("# HPA lung-cancer cores (HPA010775)")
ax.set_ylim(0, max(counts)*1.30 if max(counts)>0 else 5)
# [removed for Nature style] ax.set_title("Staining intensity distribution across HPA NECTIN4-positive lung-cancer cores",
# [removed for Nature style] pad=8, fontweight="bold")
# Inset summary box
total_pos = sum(counts[1:])   # Low + Medium + High
ax.text(0.97, 0.95,
        f"  Detected (Low/Med/High):  {total_pos}/{total}  ({100*total_pos/total:.0f}%)\n"
        f"  Membranous + cytoplasmic localisation in positive cases  \n"
        f"  Reference antibody: HPA010775 (Sigma-Aldrich)",
        transform=ax.transAxes, ha="right", va="top",
        fontsize=10, color=C["ink"], fontstyle="italic",
        bbox=dict(fc=to_rgba(C["star"],0.06), ec=C["star"], lw=0.5, pad=4))

# Caption
# caption removed

plt.rcParams["savefig.bbox"] = "standard"
for ext in ("pdf","png"):
    fig.savefig(F/f"FigureS5_HPA_IHC.{ext}", facecolor="white", dpi=350)
plt.close(fig)
print(f"\n[✓] FigureS5_HPA_IHC.pdf  (+ .png)")
