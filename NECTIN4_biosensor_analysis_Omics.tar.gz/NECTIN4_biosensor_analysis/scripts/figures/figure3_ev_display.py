#!/usr/bin/env python3
"""FIGURE 3 — EV-display rationale for NECTIN4 (6 panels, a–f).

This figure answers the sensor-principle question: *can NECTIN4 be loaded
onto tumour-derived EVs?* Bulk-tissue co-expression (a–d) is presented
honestly — significant but modest in magnitude (Pearson r ≤ ~0.3) — and
the EV-loading rationale is anchored on single-cell co-expression in
CNV-confirmed malignant cells (panel e), which is the strongest in-silico
evidence available short of patient-derived EV proteomics.

Layout (2 rows × 12 cols, figsize=(14, 10)):
  Row 1:  [a Bulk EV bars TCGA T vs N, cols 0:6]   [b NECTIN4↔EV r barh, cols 6:9]
          [c Tetraspanin matrix, cols 9:12]
  Row 2:  [d scRNA cell-type heatmap, cols 0:4]
          [e CNV-confirmed malignant-cell co-expression with tetraspanins, cols 4:8]
          [f NECTIN family EV evidence, cols 8:12]
"""
import warnings; warnings.filterwarnings("ignore")
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from fig_utils import PALETTE as C, panel_label, clean_axes

import numpy as np, pandas as pd
from scipy import stats
from scipy.stats import fisher_exact, pearsonr
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Rectangle
from matplotlib.colors import LinearSegmentedColormap, to_rgba
from matplotlib.lines import Line2D
import seaborn as sns

R = Path("results"); F = Path("figures"); F.mkdir(exist_ok=True)
DATA = Path("data")

CMAP_DIV = LinearSegmentedColormap.from_list("div", [C["normal"], "#EDEAE3", C["tumor"]])
plt.rcParams.update({
    "font.family":"sans-serif",
    "font.sans-serif":["TeX Gyre Heros","Helvetica Neue","Helvetica","Arial","Nimbus Sans","Liberation Sans","DejaVu Sans"],
    "font.size":11, "axes.titlesize":12, "axes.labelsize":11,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9,
    "figure.dpi":300, "savefig.dpi":300, "savefig.bbox":"standard",
    "axes.linewidth":0.6, "axes.edgecolor":"black", "axes.labelcolor":"black",
    "text.color":"black", "xtick.color":"black", "ytick.color":"black",
    "axes.spines.top":False, "axes.spines.right":False,
    "lines.linewidth":1.0, "pdf.fonttype":42, "ps.fonttype":42,
})
sns.set_style("ticks")

def sigstar(p): return "***" if p<1e-3 else "**" if p<1e-2 else "*" if p<0.05 else "n.s."

# ── Load data ─────────────────────────────────────────────────
print("Loading data ...")
lcpm = pd.read_csv(R/"tcga_log2cpm.csv.gz", index_col=0)
meta = pd.read_csv(R/"tcga_metadata.csv")
tc = [c for c in meta[meta.condition=="Tumor"].sample_id if c in lcpm.columns]
nc = [c for c in meta[meta.condition=="Normal"].sample_id if c in lcpm.columns]
NEC = "NECTIN4"

sc_mat = pd.read_csv(R/"sc_nectin4_ev.csv", index_col=0)
if "NECTIN4" not in sc_mat.columns and "PVRL4" in sc_mat.columns:
    sc_mat = sc_mat.rename(columns={"PVRL4":"NECTIN4"})
sc_bo = pd.read_csv(R/"sc_barcode_origin.csv").set_index("barcode")
shared = sc_mat.index.intersection(sc_bo.index)
ct_arr = sc_bo.loc[shared, "cell_type"].values
epi_mask = pd.Series(ct_arr).str.lower().str.contains("pitheli").values

# EV markers
EV_TETRA = ["CD9","CD63","CD81","CD82"]
EV_ESCRT = ["TSG101","PDCD6IP","SDCBP","VPS4A","VPS4B","CHMP4B"]
EV_RAB   = ["RAB27A","RAB27B","RAB5A","RAB7A","RAB11A"]
EV_HSP   = ["HSPA8","HSP90AA1","HSP90AB1"]
EV_ANNEX = ["ANXA1","ANXA2","ANXA5"]
EV_OTHER = ["FLOT1","FLOT2","ARF6","ALDOA","GAPDH"]
EV_ALL_BULK = EV_TETRA + EV_ESCRT + EV_RAB + EV_HSP + EV_ANNEX + EV_OTHER
EV_IN_BULK  = [g for g in EV_ALL_BULK if g in lcpm.index]

# Single-cell EV set (smaller)
EV_SC_TETRA = ["CD9","CD63","CD81","CD82"]
EV_SC_ESCRT = ["TSG101","PDCD6IP","SDCBP"]
EV_SC_RAB   = ["RAB27A","RAB27B"]
EV_SC_HSP   = ["HSPA8"]
EV_SC_ANNEX = ["ANXA1","ANXA2"]
EV_SC_ALL   = EV_SC_TETRA + EV_SC_ESCRT + EV_SC_RAB + EV_SC_HSP + EV_SC_ANNEX

# ══════════════════════════════════════════════════════════════
# FIGURE — 6 panels, 2 rows × 6 cols, figsize=(14, 10)
# ══════════════════════════════════════════════════════════════
W, H = 14.0, 10.0
fig = plt.figure(figsize=(W, H))
# 12-column virtual grid for better span control
outer = gridspec.GridSpec(2, 12, figure=fig,
                          height_ratios=[1.0, 1.0],
                          hspace=0.80, wspace=1.55,
                          left=0.085, right=0.975, top=0.955, bottom=0.085)

# ── a) Bulk EV bar chart: TCGA T vs N (wider now that panel c dropped) ──
axa = fig.add_subplot(outer[0, 0:7]); clean_axes(axa)
mean_t = lcpm.loc[EV_IN_BULK, tc].mean(axis=1)
mean_n = lcpm.loc[EV_IN_BULK, nc].mean(axis=1)
xp = np.arange(len(EV_IN_BULK)); bw = 0.38
axa.bar(xp-bw/2, mean_t, bw, color=C["tumor"], edgecolor="white", lw=0.4, label="Tumour")
axa.bar(xp+bw/2, mean_n, bw, color=C["normal"], edgecolor="white", lw=0.4, label="Normal")
axa.set_xticks(xp)
xlbl = axa.set_xticklabels(EV_IN_BULK, fontsize=9, rotation=55, ha="right",
                            fontstyle="italic", color="black")
axa.set_ylabel(r"Mean log$_2$ CPM (TCGA-LUAD)", fontsize=11)
leg_a = axa.legend(loc="upper right", frameon=True, fontsize=9, fancybox=False,
                   edgecolor="black")
leg_a.get_frame().set_linewidth(0.5)

# ── b) NECTIN4 ↔ EV marker correlation (bulk, tumours) ───────
axb = fig.add_subplot(outer[0, 7:12]); clean_axes(axb)
co_rows = []
for g in [g for g in EV_TETRA+EV_ESCRT+EV_RAB+EV_HSP+EV_ANNEX if g in lcpm.index][:16]:
    r, p = pearsonr(lcpm.loc[NEC, tc], lcpm.loc[g, tc])
    co_rows.append((g, r, p))
co = pd.DataFrame(co_rows, columns=["g","r","p"]).sort_values("r")
cols_b = [C["tumor"] if r>0 else C["normal"] for r in co.r]
yp_b = np.arange(len(co))
axb.barh(yp_b, co.r, color=cols_b, alpha=0.80, edgecolor="white", lw=0.5)
axb.axvline(0, color="black", lw=0.6)
axb.set_yticks(yp_b)
ylbl = axb.set_yticklabels(co.g, fontsize=10, fontstyle="italic", color="black")
for i, (_, row) in enumerate(co.iterrows()):
    s = sigstar(row.p)
    axb.text(row.r + (0.005 if row.r>=0 else -0.005), i, s,
             ha="left" if row.r>=0 else "right", va="center",
             fontsize=9, color="black")
axb.set_xlabel(r"Pearson $r$  vs NECTIN4 (tumours)", fontsize=11)
# Honest framing: bulk-tissue r ≤ ~0.3, significance driven by n=542.
# Placed in upper-right empty area to avoid overlap with panel c label.
axb.text(0.05, 0.02,
         "Bulk-tissue r ≤ ~0.3:\nsignificant (n = 542)\nbut modest in magnitude.\n"
         "Cell-resolved evidence\nin panel e.",
         transform=axb.transAxes, ha="left", va="bottom",
         fontsize=7.5, color="black", fontstyle="italic", linespacing=1.15,
         bbox=dict(fc="white", ec=C["mist"], lw=0.4, pad=2))

# [DROPPED: bulk tetraspanin × NECTIN4 5×5 correlation matrix.
#  Same biology shown at single-cell resolution in panel e (cell-resolved
#  evidence is stronger than bulk-tumour Pearson).]

# ── d) scRNA cell-type heatmap (NECTIN4 + EV biogenesis) ────
axd = fig.add_subplot(outer[1, 0:4]); clean_axes(axd)
genes_d = [NEC] + [g for g in EV_SC_ALL if g in sc_mat.columns]
ct_unique = sorted(set(ct_arr))
ct_means = {}
for ct in ct_unique:
    m = ct_arr==ct
    if m.sum()>=50:
        ct_means[ct] = np.log1p(sc_mat.loc[shared].loc[m, genes_d].mean())
mat = pd.DataFrame(ct_means).T[genes_d]
z = (mat - mat.mean())/(mat.std()+1e-9)
im = axd.imshow(z.values, aspect="auto", cmap=CMAP_DIV, vmin=-2, vmax=2)
axd.set_xticks(range(len(genes_d)))
xlab_d = axd.set_xticklabels(genes_d, fontsize=8.5, fontstyle="italic", rotation=45, ha="right")
for t in xlab_d:
    if t.get_text()==NEC: t.set_color(C["star"]); t.set_fontweight("bold")
    else: t.set_color("black")
axd.set_yticks(range(len(z)))
axd.set_yticklabels(z.index, fontsize=9, color="black")
axd.tick_params(axis="x", pad=4, length=2); axd.tick_params(axis="y", pad=4, length=2)
axd.add_patch(Rectangle((-0.5,-0.5),1,len(z),fill=False,
                         edgecolor=C["star"], lw=1.6, zorder=5))
cb = plt.colorbar(im, ax=axd, fraction=0.025, pad=0.025, shrink=0.78)
cb.set_label("Z-score", fontsize=9, labelpad=4); cb.ax.tick_params(labelsize=8)
cb.outline.set_linewidth(0.4)

# ── e) Single-cell co-expression in CNV-confirmed malignant cells ──
# Uses Kim 2020 author-derived inferCNV malignancy calls (Cell_subtype ∈
# {Malignant cells, tS1, tS2, tS3}). Rules out non-malignant epithelial
# contamination. Promoted from old S10 — strongest EV-loading evidence.
axe = fig.add_subplot(outer[1, 4:8]); clean_axes(axe)
cnv_path = R/"sc_cnv_malignancy_with_evgenes.csv"
if cnv_path.exists():
    src_e = pd.read_csv(cnv_path, index_col=0)
    src_e = src_e[src_e.malignant_cnv].copy()
    for c in ["NECTIN4","CD9","CD63","CD81","CD82"]:
        src_e[c] = src_e[c] > 0
    n4 = src_e["NECTIN4"].values
    rows_e = []
    for g in ["CD9","CD63","CD81","CD82"]:
        pp = 100.0 * src_e[g][n4].mean()
        pn = 100.0 * src_e[g][~n4].mean()
        fc = (pp+1e-3)/(pn+1e-3)
        tab = [[int((src_e[g] & src_e.NECTIN4).sum()),
                int((~src_e[g] & src_e.NECTIN4).sum())],
               [int((src_e[g] & ~src_e.NECTIN4).sum()),
                int((~src_e[g] & ~src_e.NECTIN4).sum())]]
        try: _, pv = fisher_exact(tab, alternative="greater")
        except Exception: pv = 1.0
        rows_e.append((g, pp, pn, fc, pv))
    edf = pd.DataFrame(rows_e, columns=["g","pos","neg","fc","pv"]).sort_values("fc")
    yp_e = np.arange(len(edf)); bh = 0.36
    axe.barh(yp_e+bh/2, edf.pos, height=bh, color=C["star"], edgecolor="white", lw=0.4,
             label=r"NECTIN4$^+$ malignant")
    axe.barh(yp_e-bh/2, edf.neg, height=bh, color=C["mist"], edgecolor="white", lw=0.4,
             label=r"NECTIN4$^-$ malignant")
    for i,(_,r) in enumerate(edf.iterrows()):
        axe.text(max(r.pos, r.neg) + 2.0, i,
                 f"{r.fc:.2f}× {sigstar(r.pv)}",
                 va="center", fontsize=9.5, color="black", fontweight="bold")
    axe.set_yticks(yp_e)
    axe.set_yticklabels(edf.g, fontsize=10, fontstyle="italic", color="black")
    axe.set_xlabel("% CNV-confirmed malignant cells positive", fontsize=11)
    # Percentage axis hard-capped at 100; fold-change annotations now sit
    # immediately right of each bar within the data range.
    axe.set_xlim(0, 100)
    # Triple co-expression headline placed in upper-LEFT empty region (the
    # bars are sorted ascending so the longest bar is at the top — text
    # box won't collide with data labels at top-left between bar y=2.5–3.4)
    n4_pos_cells = src_e[src_e.NECTIN4]
    tet_count = n4_pos_cells[["CD9","CD63","CD81"]].sum(axis=1).values
    p_any  = 100 * (tet_count >= 1).mean()
    p_two  = 100 * (tet_count >= 2).mean()
    p_all3 = 100 * (tet_count == 3).mean()
    # Cumulative ≥1 / ≥2 / =3 co-expression headline is shown visually in
    # Fig S6b — annotation removed here to avoid duplication.
    leg_e = axe.legend(loc="upper right", frameon=True, fontsize=8.5,
                       fancybox=False, edgecolor="black", borderpad=0.4)
    leg_e.get_frame().set_linewidth(0.5)

# ── f) NECTIN family — EV evidence (ExoCarta + this work) ──
axf = fig.add_subplot(outer[1, 8:12]); axf.axis("off")
axf.set_xlim(0, 1); axf.set_ylim(-0.02, 1.05)
# Curated data table from ExoCarta v5 + literature scan
# Single-column bullet layout (avoids cross-column overlap entirely)
evidence_rows = [
    ("NECTIN2",      "Ovarian (IGROV1, OVCAR-3) — MS  ·  PMID 23333927"),
    ("NECTIN2",      "Prostate (DU145) — MS + WB  ·  PMID 25844599"),
    ("NECTIN2",      "Platelet PL-Exs — MS + WB  ·  PMID 25332113"),
    ("NECTIN1 / 3",  "Multiple tumour cell lines — MS  ·  Vesiclepedia"),
    ("NECTIN4",      "Lung A549 small-EV preparations — MS  ·  ExoCarta v5"),
]
axf.text(0.0, 0.97, "NECTIN family in EVs  (ExoCarta + literature)",
         fontsize=11, fontweight="bold", color="black", va="center")
axf.plot([0, 1], [0.92, 0.92], color="black", lw=0.8)
y0 = 0.84
row_h = 0.155
for i, (fam, detail) in enumerate(evidence_rows):
    y = y0 - i*row_h
    if i % 2 == 0:
        axf.add_patch(Rectangle((-0.01, y-row_h*0.40), 1.04, row_h*0.80,
                                  fc=to_rgba(C["pale"], 0.45), ec="none", zorder=0))
    is_n4 = fam == "NECTIN4"
    txt_col = C["star"] if is_n4 else "black"
    fw = "bold" if is_n4 else "normal"
    axf.text(0.0,  y+0.025, fam,    fontsize=11, color=txt_col, fontweight=fw, va="center")
    axf.text(0.0,  y-0.035, detail, fontsize=10, color="black", va="center", fontstyle="italic")

# Pre-emptive declaration of the wet-lab validation step (per user spec)
axf.text(0.0, -0.05,
         "Patient-plasma EV proteomic profiling = the\n"
         "designated experimental validation step.",
         fontsize=8.0, color=C["ink"], fontstyle="italic", va="top")

# ── Panel labels (bullet-proof figure coords) ─────────────────
fig.canvas.draw()
for ax_obj, letter in [(axa,"a"),(axb,"b"),(axd,"c"),(axe,"d"),(axf,"e")]:
    panel_label(fig, ax_obj, letter, dx=-0.038, dy=0.012, fontsize=14)

plt.rcParams["savefig.bbox"] = "standard"
for ext in ("pdf","png"):
    fig.savefig(F/f"Figure3.{ext}", facecolor="white", dpi=350)
plt.close(fig)
print(f"\n[✓] Figure3.pdf  (+ .png)")
