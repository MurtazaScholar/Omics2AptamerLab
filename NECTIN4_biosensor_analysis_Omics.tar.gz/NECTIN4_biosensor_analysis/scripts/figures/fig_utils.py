"""
fig_utils.py — shared utilities for Nature-grade figures.

Provides:
  • panel_label(fig, ax, letter)  — bullet-proof panel label that
       NEVER overlaps the title (uses figure coordinates anchored
       to the axes bounding box, called AFTER all subplots created).
  • beautiful_volcano(ax, deg, …) — polished editorial volcano.
  • clean_axes(ax)               — slim spines, restrained ticks.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgba
from matplotlib.patches import Rectangle
try:
    from adjustText import adjust_text
    HAS_ADJUST = True
except Exception:
    HAS_ADJUST = False

PALETTE = {
    "ink":     "#26333D",
    "tumor":   "#9E3B4E",
    "normal":  "#6E94A6",
    "star":    "#C06A33",
    "sage":    "#6E8C73",
    "gold":    "#C9A24A",
    "plum":    "#7C6884",
    "grey":    "#AEACA2",
    "pale":    "#EDE7DC",
    "mist":    "#D3D8DA",
    "line":    "#9AA0A4",
    "up":      "#C97064",
    "down":    "#6B9AC4",
    "ns":      "#D6D6D6",
}

# ──────────────────────────────────────────────────────────────────────────────
def clean_axes(ax, lw=0.55):
    """Apply consistent slim-spine editorial style."""
    C = PALETTE
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_linewidth(lw)
        ax.spines[s].set_color(C["ink"])
    ax.tick_params(which="both", length=2.5, width=lw, color=C["ink"])
    ax.grid(False)


def panel_label(fig, ax, letter, dx=-0.04, dy=0.012, fontsize=14):
    """Place a bullet-proof panel-letter label anchored to the axes
    bounding-box in figure coordinates.  Call AFTER the figure has been
    laid out (i.e. after all axes are created).  Never overlaps titles.
    """
    bbox = ax.get_position()
    fig.text(bbox.x0 + dx, bbox.y1 + dy, letter,
             fontsize=fontsize, fontweight="bold",
             va="bottom", ha="left", color=PALETTE["ink"])


def panel_label_image(fig, ax, letter, dx=-0.012, dy=0.012, fontsize=11):
    """Variant for image / map panels with no axes — same anchor logic."""
    panel_label(fig, ax, letter, dx=dx, dy=dy, fontsize=fontsize)


# ──────────────────────────────────────────────────────────────────────────────
def beautiful_volcano(ax, deg, highlight_genes, star_gene="NECTIN4",
                       fc_thresh=1.0, p_thresh=0.05,
                       title=None, footnote_n=None):
    """
    Polished editorial volcano plot.

    deg : DataFrame with columns log2FC, neglog10p, sig (Up/Down/NS), gene
    highlight_genes : list of gene names to label (besides star_gene)
    star_gene       : single gene to spotlight with star + halo
    fc_thresh, p_thresh : threshold lines
    title : optional axis title (set by caller if more control needed)
    footnote_n : tuple (n_tumor, n_normal) for axis subtitle
    """
    C = PALETTE
    clean_axes(ax)

    # Background: NS points (small, faint grey)
    ns = deg[deg.sig == "NS"]
    sig = deg[deg.sig != "NS"]
    ax.scatter(ns.log2FC, ns.neglog10p,
               s=2.0, color=C["ns"], alpha=0.30,
               edgecolors="none", rasterized=True, zorder=1)

    # Significant points: up red, down blue
    up = sig[sig.sig == "Up"]; dn = sig[sig.sig == "Down"]
    ax.scatter(up.log2FC, up.neglog10p,
               s=3.0, color=C["up"], alpha=0.55,
               edgecolors="none", rasterized=True, zorder=2)
    ax.scatter(dn.log2FC, dn.neglog10p,
               s=3.0, color=C["down"], alpha=0.55,
               edgecolors="none", rasterized=True, zorder=2)

    # Threshold lines (subtle)
    ax.axhline(-np.log10(p_thresh), color=C["line"],
               ls=(0, (4, 3)), lw=0.5, zorder=3)
    ax.axvline( fc_thresh, color=C["line"], ls=(0, (4, 3)), lw=0.5, zorder=3)
    ax.axvline(-fc_thresh, color=C["line"], ls=(0, (4, 3)), lw=0.5, zorder=3)

    # Background shading for significance regions (very subtle)
    ymax = max(deg.neglog10p.max(), 1)
    xmin, xmax = deg.log2FC.min(), deg.log2FC.max()
    ax.fill_betweenx([-np.log10(p_thresh), ymax * 1.05],
                       fc_thresh, xmax * 1.05,
                       color=to_rgba(C["up"], 0.04), zorder=0)
    ax.fill_betweenx([-np.log10(p_thresh), ymax * 1.05],
                       xmin * 1.05, -fc_thresh,
                       color=to_rgba(C["down"], 0.04), zorder=0)

    # Highlight genes with circle markers + adjust-text labels
    texts = []; tx = []; ty = []
    for g in highlight_genes:
        row = deg[deg.gene == g]
        if not len(row): continue
        r = row.iloc[0]
        ax.scatter(r.log2FC, r.neglog10p,
                   s=28, facecolor="white",
                   edgecolor=C["ink"], lw=0.8, zorder=5)
        t = ax.text(r.log2FC, r.neglog10p, g,
                    fontsize=9, fontstyle="italic", color=C["ink"],
                    fontweight="normal", zorder=6)
        texts.append(t); tx.append(r.log2FC); ty.append(r.neglog10p)

    # Star gene (NECTIN4) — halo + filled star + label
    if star_gene is not None:
        row = deg[deg.gene == star_gene]
        if len(row):
            r = row.iloc[0]
            # Outer halo
            ax.scatter(r.log2FC, r.neglog10p, s=240, marker="o",
                       facecolor=to_rgba(C["star"], 0.10), edgecolor="none",
                       zorder=4)
            # Inner ring
            ax.scatter(r.log2FC, r.neglog10p, s=100, marker="o",
                       facecolor="none", edgecolor=C["star"],
                       lw=0.8, zorder=5)
            # Star
            ax.scatter(r.log2FC, r.neglog10p, s=120, marker="*",
                       facecolor=C["star"], edgecolor="white",
                       lw=0.8, zorder=7)
            t = ax.text(r.log2FC, r.neglog10p, star_gene,
                        fontsize=10, fontweight="bold", fontstyle="italic",
                        color=C["star"], zorder=8)
            texts.append(t); tx.append(r.log2FC); ty.append(r.neglog10p)

    # adjustText pass
    if HAS_ADJUST and texts:
        adjust_text(texts, x=tx, y=ty, ax=ax,
                    expand=(1.5, 1.8),
                    arrowprops=dict(arrowstyle="-", color=C["grey"],
                                     lw=0.35, shrinkA=2, shrinkB=2),
                    force_text=(0.55, 0.65),
                    max_move=80, time_lim=1.8)

    # Up / down counts — top corners, with bullet + count
    n_up = int((deg.sig == "Up").sum())
    n_dn = int((deg.sig == "Down").sum())
    ax.text(0.985, 0.97,
            f"●  {n_up:,}  up", transform=ax.transAxes,
            ha="right", va="top", fontsize=9,
            color=C["up"], fontweight="bold")
    ax.text(0.015, 0.97,
            f"●  {n_dn:,}  down", transform=ax.transAxes,
            ha="left", va="top", fontsize=9,
            color=C["down"], fontweight="bold")

    # Axis labels
    ax.set_xlabel(r"log$_{2}$ fold-change", fontsize=11)
    ax.set_ylabel(r"$-$log$_{10}$ (adj. P-value)", fontsize=11)

    # Y/X scaling tight
    ax.set_ylim(-0.5, ymax * 1.05)

    # Per-panel titles intentionally removed (Nature style).
    # Title argument retained for back-compat but ignored.
    if footnote_n is not None:
        ax.text(0.5, -0.18,
                f"n = {footnote_n[0]:,} tumour  vs  {footnote_n[1]} normal",
                transform=ax.transAxes, ha="center", va="top",
                fontsize=8, fontstyle="italic", color=C["ink"])
