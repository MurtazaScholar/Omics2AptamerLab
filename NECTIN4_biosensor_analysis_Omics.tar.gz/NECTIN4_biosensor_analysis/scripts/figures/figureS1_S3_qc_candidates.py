#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════
Supplementary figures S1–S5  (same editorial palette as Figure 1)
═══════════════════════════════════════════════════════════════
S1  Pipeline QC (PCA, library size, FC, QQ, cohort, sample correlation)
S2  WGCNA detail (soft threshold, connectivity, module-trait, sizes, hub net)
S3  Candidate landscape (top novel candidates: T vs N, ROC, correlation, scores)
S4  NECTIN4 clinical stratification (stage, smoking, vital, AUC bootstrap)
S5  Extended exosome cargo (bulk EV markers, NECTIN4↔EV r, tetraspanin matrix)
═══════════════════════════════════════════════════════════════
"""
import warnings; warnings.filterwarnings("ignore")
from pathlib import Path
import numpy as np, pandas as pd
from scipy import stats
from scipy.stats import kendalltau, fisher_exact, chi2
from sklearn.metrics import roc_curve, auc, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch, Circle, Rectangle
from matplotlib.colors import LinearSegmentedColormap, to_rgba
from matplotlib.lines import Line2D
import seaborn as sns

R = Path("results"); F = Path("figures"); F.mkdir(exist_ok=True)
DATA = Path("data")

# ── Editorial palette (matches Figure 1) ──────────────────────
C = {
    "ink":    "#26333D", "tumor":  "#9E3B4E", "normal": "#6E94A6",
    "star":   "#C06A33", "sage":   "#6E8C73", "gold":   "#C9A24A",
    "plum":   "#7C6884", "grey":   "#AEACA2", "pale":   "#EDE7DC",
    "mist":   "#D3D8DA", "line":   "#9AA0A4",
}
CMAP_DIV = LinearSegmentedColormap.from_list("div",
              [C["normal"], "#EDEAE3", C["tumor"]])
W2 = 180/25.4

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["TeX Gyre Heros", "Helvetica Neue", "Helvetica",
                        "Arial", "Nimbus Sans", "Liberation Sans", "DejaVu Sans"],
    "font.size":11, "axes.titlesize":12, "axes.labelsize":11,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9,
    "figure.dpi": 300, "savefig.dpi": 300, "savefig.bbox": "tight",
    "axes.linewidth": 0.6, "axes.edgecolor": C["ink"],
    "axes.labelcolor": C["ink"], "text.color": C["ink"],
    "xtick.color": C["ink"], "ytick.color": C["ink"],
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "axes.spines.top": False, "axes.spines.right": False,
    "lines.linewidth": 1.0, "pdf.fonttype": 42, "ps.fonttype": 42,
})
sns.set_style("ticks")

def lab(ax, s, x=None, y=None, dx=-0.040, dy=0.014):
    """fig-coord panel label anchored to ax position (never overlaps title)."""
    fig = ax.figure
    fig.canvas.draw()
    bbox = ax.get_position()
    fig.text(bbox.x0 + dx, bbox.y1 + dy, s,
             fontsize=11, fontweight="bold",
             va="bottom", ha="left", color=C["ink"])

def style(ax):
    for sp in ax.spines.values():
        sp.set_color(C["ink"]); sp.set_linewidth(0.6)
def sigstar(p):
    return "***" if p<1e-3 else "**" if p<1e-2 else "*" if p<0.05 else "n.s."
def save_fig(fig, stem):
    for ext in ("pdf","png"):
        fig.savefig(F/f"{stem}.{ext}", facecolor="white", dpi=350)
    plt.close(fig); print(f"  [✓] {stem}")

# ══════════════════════════════════════════════════════════════
# LOAD DATA
# ══════════════════════════════════════════════════════════════
print("Loading data ...")
deg     = pd.read_csv(R/"deg_results.csv")
dep     = pd.read_csv(R/"dep_results.csv") if (R/"dep_results.csv").exists() else pd.DataFrame()
lcpm    = pd.read_csv(R/"tcga_log2cpm.csv.gz", index_col=0)
meta    = pd.read_csv(R/"tcga_metadata.csv")
novel   = pd.read_csv(R/"novel_candidates.csv")
scores  = pd.read_csv(R/"biosensor_scores_all.csv")
# Fair scoring: signed z, prot weight 0.30, no novelty term — reviewer-corrected
scores_fair = pd.read_csv(R/"biosensor_scores_refitted.csv") if (R/"biosensor_scores_refitted.csv").exists() else pd.DataFrame()
pairs   = pd.read_csv(R/"dual_target_panels.csv")
sft     = pd.read_csv(R/"wgcna_sft.csv")     if (R/"wgcna_sft.csv").exists() else pd.DataFrame()
trait   = pd.read_csv(R/"wgcna_trait.csv")   if (R/"wgcna_trait.csv").exists() else pd.DataFrame()
hub     = pd.read_csv(R/"wgcna_hub_genes.csv") if (R/"wgcna_hub_genes.csv").exists() else pd.DataFrame()
modules = pd.read_csv(R/"wgcna_modules.csv") if (R/"wgcna_modules.csv").exists() else pd.DataFrame()
pca_df  = pd.read_csv(R/"pca_results.csv")
ve      = np.load(R/"pca_variance_explained.npy")
pheno   = pd.read_csv(DATA/"TCGA-LUAD.GDC_phenotype.tsv.gz", sep="\t", low_memory=False).set_index("barcode")

tc = [c for c in meta[meta.condition=="Tumor"].sample_id if c in lcpm.columns]
nc = [c for c in meta[meta.condition=="Normal"].sample_id if c in lcpm.columns]
ac = tc + nc
y_roc = np.array([1]*len(tc) + [0]*len(nc))

NEC = "NECTIN4"
nec_row = deg[deg.gene==NEC].iloc[0]
nec_auc = roc_auc_score(y_roc, lcpm.loc[NEC, ac].values.astype(float))
if nec_auc < 0.5: nec_auc = 1-nec_auc

# EV markers
EV_TETRA = ["CD9","CD63","CD81","CD82"]
EV_ESCRT = ["TSG101","PDCD6IP","SDCBP","VPS4A","VPS4B","CHMP4B"]
EV_RAB   = ["RAB27A","RAB27B","RAB5A","RAB7A","RAB11A"]
EV_HSP   = ["HSPA8","HSP90AA1","HSP90AB1"]
EV_ANNEX = ["ANXA1","ANXA2","ANXA5"]
EV_ALL   = EV_TETRA + EV_ESCRT + EV_RAB + EV_HSP + EV_ANNEX
EV_IN_LCPM = [g for g in EV_ALL if g in lcpm.index]

# ══════════════════════════════════════════════════════════════
# Figure S1 — Pipeline QC
# ══════════════════════════════════════════════════════════════
print("\n── Figure S1: pipeline QC ──")
fig = plt.figure(figsize=(15, 9))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.55, wspace=0.75,
                       left=0.12, right=0.97, top=0.93, bottom=0.09)

# a) PCA by condition
ax = fig.add_subplot(gs[0,0]); lab(ax,"a"); style(ax)
col_map = pca_df.condition.map({"Tumor":C["tumor"],"Normal":C["normal"]})
ax.scatter(pca_df.PC1, pca_df.PC2, c=col_map, s=8, alpha=0.6,
           edgecolors="none", rasterized=True)
ax.set_xlabel(f"PC1 ({ve[0]:.1f}%)"); ax.set_ylabel(f"PC2 ({ve[1]:.1f}%)")
ax.legend(handles=[Line2D([0],[0],marker="o",ls="none",color=C["tumor"],ms=4,label="Tumour"),
                   Line2D([0],[0],marker="o",ls="none",color=C["normal"],ms=4,label="Normal")],
          frameon=False, loc="upper right")
# [removed for Nature style] ax.set_title("PCA — sample clustering", pad=14, fontweight="bold")

# b) Scree
ax = fig.add_subplot(gs[0,1]); lab(ax,"b"); style(ax)
nve = min(10, len(ve))
ax.bar(range(1, nve+1), ve[:nve], color=C["plum"], alpha=0.85, edgecolor="white", lw=0.4)
ax.set_xlabel("PC"); ax.set_ylabel("% variance")
# [removed for Nature style] ax.set_title("Variance explained", pad=14, fontweight="bold")

# c) Library normalization
ax = fig.add_subplot(gs[0,2]); lab(ax,"c"); style(ax)
mean_t = lcpm[tc].mean(axis=0); mean_n = lcpm[nc].mean(axis=0)
bp = ax.boxplot([mean_t.values, mean_n.values], labels=["Tumour","Normal"],
                patch_artist=True, widths=0.55, showfliers=True,
                flierprops=dict(marker=".",ms=1.5,alpha=0.3),
                medianprops=dict(color=C["ink"], lw=0.8))
for p, c in zip(bp["boxes"], [C["tumor"], C["normal"]]):
    p.set_facecolor("white"); p.set_edgecolor(c); p.set_lw(0.8)
ax.set_ylabel("Mean log\u2082 CPM")
# [removed for Nature style] ax.set_title("Library normalization", pad=14, fontweight="bold")

# d) DEG count summary
ax = fig.add_subplot(gs[1,0]); lab(ax,"d"); style(ax)
nu = (deg.sig=="Up").sum(); nd = (deg.sig=="Down").sum(); ns_ = (deg.sig=="NS").sum()
counts_x = ["Up","Down","NS"]; counts_v = [nu, nd, ns_]
cols_x = [C["tumor"], C["normal"], C["mist"]]
ax.bar(counts_x, counts_v, color=cols_x, alpha=0.85, edgecolor="white", lw=0.5)
for x, v in zip(counts_x, counts_v):
    ax.text(x, v+max(counts_v)*0.02, f"{v:,}", ha="center", fontsize=10, fontweight="bold")
ax.set_ylabel("# genes")
# [removed for Nature style] ax.set_title("Differential expression summary", pad=14, fontweight="bold")

# e) FC distribution + NECTIN4
ax = fig.add_subplot(gs[1,1]); lab(ax,"e"); style(ax)
ax.hist(deg.log2FC, bins=80, color=C["plum"], alpha=0.7, edgecolor="white", lw=0.2)
ax.axvline(1,  color=C["line"], ls=(0,(4,3)), lw=0.5)
ax.axvline(-1, color=C["line"], ls=(0,(4,3)), lw=0.5)
ax.axvline(nec_row.log2FC, color=C["star"], lw=1.4)
ax.text(nec_row.log2FC+0.15, ax.get_ylim()[1]*0.92, "NECTIN4",
        fontsize=10, color=C["star"], fontweight="bold")
ax.set_xlabel("log\u2082 fold-change"); ax.set_ylabel("# genes")
# [removed for Nature style] ax.set_title("Fold-change distribution", pad=14, fontweight="bold")

# f) QQ plot
ax = fig.add_subplot(gs[1,2]); lab(ax,"f"); style(ax)
obs = -np.log10(np.sort(deg.pvalue.values))
exp = -np.log10(np.linspace(1/len(obs), 1, len(obs)))
ax.scatter(exp, obs, s=1.4, color=C["plum"], alpha=0.55, rasterized=True)
ax.plot([0, exp.max()], [0, exp.max()], color=C["line"], lw=0.6, ls=":")
ax.set_xlabel("Expected $-$log$_{10}$ P"); ax.set_ylabel("Observed $-$log$_{10}$ P")
# [removed for Nature style] ax.set_title("P-value QQ", pad=14, fontweight="bold")

# caption removed

save_fig(fig, "FigureS1_QC")


# === FigureS2_WGCNA (deprecated, R² never reached 0.8) — block removed ===



# ══════════════════════════════════════════════════════════════
# Figure S3 — Candidate landscape (top novel candidates head-to-head)
# ══════════════════════════════════════════════════════════════
print("\n── Figure S3: candidate landscape ──")
top_cands = novel.head(8).gene.tolist()
top_cands_in = [g for g in top_cands if g in lcpm.index]

fig = plt.figure(figsize=(W2*1.3, W2*1.05))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=1.10, wspace=0.95,
                       left=0.08, right=0.97, top=0.95, bottom=0.20)

# a) Tumour vs Normal boxplots — all top candidates
ax = fig.add_subplot(gs[0, :2]); lab(ax,"a", x=-0.05); style(ax)
positions=[]; data=[]; cols=[]; labels=[]
for i, g in enumerate(top_cands_in):
    data.append(lcpm.loc[g, tc].values); positions.append(i*3); cols.append(C["tumor"]); labels.append(g)
    data.append(lcpm.loc[g, nc].values); positions.append(i*3+1); cols.append(C["normal"])
bp = ax.boxplot(data, positions=positions, patch_artist=True, widths=0.65,
                flierprops=dict(marker=".",ms=1,alpha=0.2),
                medianprops=dict(color=C["ink"],lw=0.8),
                whiskerprops=dict(lw=0.5), capprops=dict(lw=0.5),
                boxprops=dict(lw=0.5))
for p, c in zip(bp["boxes"], cols):
    p.set_facecolor("white"); p.set_edgecolor(c); p.set_lw(0.8)
ax.set_xticks([i*3+0.5 for i in range(len(top_cands_in))])
xticks = ax.set_xticklabels(top_cands_in, fontsize=10, fontstyle="italic", rotation=45, ha="right")
for t in xticks:
    if t.get_text()==NEC: t.set_color(C["star"]); t.set_fontweight("bold")
ax.set_ylabel("log\u2082 CPM")
ax.legend(handles=[Line2D([0],[0],marker="s",ls="none",color=C["tumor"],ms=5,label="Tumour"),
                   Line2D([0],[0],marker="s",ls="none",color=C["normal"],ms=5,label="Normal")],
          frameon=False, loc="upper right", fontsize=9)
# [removed for Nature style] ax.set_title("Expression of top novel candidates (Tumour vs Normal)",
# [removed for Nature style] pad=14, fontweight="bold")

# b) Individual ROCs
ax = fig.add_subplot(gs[0, 2]); lab(ax,"b"); style(ax)
ci = plt.cm.Set2(np.linspace(0, 0.9, len(top_cands_in)))
roc_results = []
for i, g in enumerate(top_cands_in):
    x = lcpm.loc[g, ac].values.astype(float)
    a = roc_auc_score(y_roc, x)
    if a<0.5: x=-x; a=1-a
    fpr, tpr, _ = roc_curve(y_roc, x)
    is_n4 = (g==NEC)
    col = C["star"] if is_n4 else C["grey"]
    lw  = 1.6 if is_n4 else 0.9
    ax.plot(fpr, tpr, color=col, lw=lw, label=f"{g} ({a:.3f})",
            zorder=10 if is_n4 else 3)
    roc_results.append((g, a))
ax.plot([0,1],[0,1], color=C["line"], lw=0.5, ls=":")
ax.legend(fontsize=4.5, loc="lower right", frameon=False, ncol=2)
ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
# [removed for Nature style] ax.set_title("Diagnostic ROC", pad=14, fontweight="bold")

# c) Score-matrix heatmap on the topology-filtered analyte-valid set
ax = fig.add_subplot(gs[1, 0]); lab(ax,"c"); style(ax)
topo_path = R/"biosensor_scores_topology_filtered.csv"
if topo_path.exists():
    sc_src = pd.read_csv(topo_path).sort_values("score_topology", ascending=False).reset_index(drop=True)
    score_col = "score_topology"
else:
    sc_src = scores.head(6).copy(); sc_src["score_topology"] = sc_src["score"]
    score_col = "score_topology"
metrics_h = ["tx_log2FC","prot_log2FC", score_col]
hm = sc_src[metrics_h].fillna(0).values
im = ax.imshow(hm, aspect="auto", cmap=CMAP_DIV, vmin=-3, vmax=3)
ax.set_yticks(range(len(sc_src))); ylab = ax.set_yticklabels(sc_src.gene, fontsize=10, fontstyle="italic")
for t in ylab:
    if t.get_text()==NEC: t.set_color(C["star"]); t.set_fontweight("bold")
ax.set_xticks(range(len(metrics_h)))
ax.set_xticklabels(["Tx log\u2082FC","Prot log\u2082FC","Score"],
                   fontsize=9, rotation=30, ha="right")
ax.tick_params(axis="x", pad=2)
cb = plt.colorbar(im, ax=ax, fraction=0.04, pad=0.04, shrink=0.7)
cb.outline.set_linewidth(0.4)
# Score-text and sensitivity moved to a dedicated text strip below the
# figure (see end of S3 block) — keeps panel c clean.

# d) Correlation heatmap of top candidates (in tumours)
ax = fig.add_subplot(gs[1, 1]); lab(ax,"d"); style(ax)
cor = lcpm.loc[top_cands_in, tc].T.corr()
# Drop in-cell numeric annotations — panel d is too narrow to fit 8×8 values
# legibly. The colour scale is sufficient at this size; exact correlation
# values are tabulated in the Supplementary Data CSV.
sns.heatmap(cor, cmap=CMAP_DIV, vmin=-1, vmax=1, center=0,
            ax=ax, square=True, linewidths=0.8, annot=False,
            cbar_kws={"shrink":0.6, "pad":0.08},
            xticklabels=top_cands_in, yticklabels=top_cands_in)
xt = ax.get_xticklabels(); yt = ax.get_yticklabels()
for t in xt:
    t.set_fontsize(8); t.set_rotation(45); t.set_ha("right"); t.set_fontstyle("italic")
for t in yt:
    t.set_fontsize(8); t.set_fontstyle("italic")
for t in list(xt)+list(yt):
    if t.get_text()==NEC: t.set_color(C["star"]); t.set_fontweight("bold")
ax.tick_params(axis="x", pad=6, length=2); ax.tick_params(axis="y", pad=6, length=2)
# Save the underlying correlation matrix for Supplementary Data
cor.to_csv(R/"S3_panel_d_correlation_matrix.csv")

# e) Topology annotation table for the 18 aptamer-compatible candidates
#    Replaces the dropped dual-target combo-AUC panel — single-analyte
#    sensor design makes combo-AUC self-defeating.
ax = fig.add_subplot(gs[1, 2]); lab(ax,"e"); style(ax); ax.axis("off")
topo_ann = pd.read_csv(R/"topology_annotation.csv") if (R/"topology_annotation.csv").exists() else pd.DataFrame()
if len(topo_ann):
    # Sort: TM_single_pass/GPI first (highest priority), then secreted; within
    # each block sort kept candidates first.
    pri = {"TM_single_pass":0, "GPI":1, "TM_multi_pass":2, "secreted":3}
    topo_ann["pri"] = topo_ann.topology.map(pri).fillna(9)
    topo_ann["kept"] = (topo_ann.topology.isin(["TM_single_pass","GPI"])
                       & topo_ann.has_ectodomain & (~topo_ann.shed_dominant))
    topo_ann = topo_ann.sort_values(["kept","pri","gene"], ascending=[False, True, True])
    nrow = len(topo_ann)
    # Compact 2-column layout: Gene + topology/shed-status descriptor + keep marker.
    # Panel e is narrow (1 grid column); a 4-col table doesn't fit.
    ax.set_xlim(0, 1); ax.set_ylim(-0.5, nrow + 1.3)
    HY = nrow + 0.55
    ax.text(0.02, HY, "Gene",   fontsize=8.5, fontweight="bold", color=C["ink"])
    ax.text(0.40, HY, "Status", fontsize=8.5, fontweight="bold", color=C["ink"])
    ax.text(0.92, HY, "Keep",   fontsize=8.5, fontweight="bold", color=C["ink"], ha="center")
    ax.plot([0, 1], [nrow + 0.10, nrow + 0.10], color=C["ink"], lw=0.6, zorder=1)
    for i, (_, r) in enumerate(topo_ann.iterrows()):
        y = nrow - 1 - i
        is_n4 = (r.gene == NEC)
        is_kept = bool(r.kept)
        if i % 2 == 0:
            ax.add_patch(Rectangle((0, y-0.42), 1.0, 0.84,
                                    fc=C["pale"], ec="none", alpha=0.40, zorder=1))
        col_gene = C["star"] if is_n4 else (C["ink"] if is_kept else C["grey"])
        fw = "bold" if is_n4 else "normal"
        # Combined status descriptor (avoids 4-col cramping)
        topo_short = (r.topology.replace("TM_single_pass","TM-1")
                                 .replace("TM_multi_pass","TM-N"))
        status = f"{topo_short}" + (" / shed" if r.shed_dominant else "")
        ax.text(0.02, y, r.gene,
                fontsize=7.5, color=col_gene, fontweight=fw, va="center", zorder=2)
        ax.text(0.40, y, status,
                fontsize=7.5, color=col_gene, va="center", zorder=2)
        keep_mk = "●" if is_kept else "○"
        ax.text(0.92, y, keep_mk, fontsize=11,
                color=(C["star"] if is_kept else C["mist"]),
                ha="center", va="center", zorder=3)

# Bottom text strip — formula + sensitivity placed in figure coords with whitespace
fig.text(0.5, 0.10,
         "Score = z(Tx log\u2082FC) within the topology-filtered candidate set.",
         ha="center", va="top", fontsize=9.5, color="black", family="monospace")
fig.text(0.5, 0.075,
         "Filter: single-pass TM or GPI anchor with surface ectodomain, not predominantly soluble-shed.",
         ha="center", va="top", fontsize=8.5, color=C["ink"])
fig.text(0.5, 0.045,
         "Sensitivity: NECTIN4 remains #1 across w_Prot ∈ [0, 0.7], under Borda rank-aggregation, "
         "and in 100% of 10,000 Dirichlet random-weight draws — ranking is not weight-dependent.",
         ha="center", va="top", fontsize=8.0, color=C["ink"], fontstyle="italic")

save_fig(fig, "FigureS3_Candidates")


# ══════════════════════════════════════════════════════════════
# Figure S4 — NECTIN4 clinical stratification
# ══════════════════════════════════════════════════════════════
print("\n── Figure S4: NECTIN4 clinical stratification ──")

def stage_simple(s):
    if pd.isna(s): return None
    s = str(s)
    if "IV" in s: return "IV"
    if "III" in s: return "III"
    if "II" in s: return "II"
    if "I" in s: return "I"
    return None

nec_df = pd.DataFrame({"barcode":tc, "expr": lcpm.loc[NEC, tc].values})
nec_df["stage"]   = nec_df.barcode.map({b:stage_simple(s) for b,s in pheno["ajcc_pathologic_stage"].to_dict().items()})
nec_df["vital"]   = nec_df.barcode.map(pheno["vital_status"].to_dict())
nec_df["smoking"] = nec_df.barcode.map(pheno["tobacco_smoking_status"].to_dict())

fig = plt.figure(figsize=(15, 10))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.65, wspace=0.75,
                       left=0.12, right=0.97, top=0.93, bottom=0.10)

# a) Expression density T vs N
ax = fig.add_subplot(gs[0,0]); lab(ax,"a"); style(ax)
ax.hist(lcpm.loc[NEC, nc], bins=25, color=C["normal"], alpha=0.55,
        edgecolor=C["normal"], lw=0.5, label="Normal", density=True)
ax.hist(lcpm.loc[NEC, tc], bins=35, color=C["tumor"],  alpha=0.55,
        edgecolor=C["tumor"],  lw=0.5, label="Tumour", density=True)
ax.set_xlabel("NECTIN4 log\u2082 CPM"); ax.set_ylabel("Density")
ax.legend(frameon=False)
# [removed for Nature style] ax.set_title("Expression distribution", pad=14, fontweight="bold")

# b) Tumour over-expression rate (% over 95th pct normal) — top candidates
ax = fig.add_subplot(gs[0,1]); lab(ax,"b"); style(ax)
top_for_rate = [g for g in novel.head(8).gene if g in lcpm.index]
rates = []
for g in top_for_rate:
    th = np.percentile(lcpm.loc[g, nc], 95)
    pa = (lcpm.loc[g, tc] > th).mean()*100
    rates.append((g, pa))
rdf = pd.DataFrame(rates, columns=["g","pct"]).sort_values("pct")
cols_b = [C["star"] if g==NEC else C["grey"] for g in rdf.g]
ax.barh(rdf.g, rdf.pct, color=cols_b, alpha=0.85, edgecolor="white", lw=0.5)
ylab = ax.get_yticklabels()
for t in ylab:
    if t.get_text()==NEC: t.set_color(C["star"]); t.set_fontweight("bold")
    t.set_fontstyle("italic")
ax.set_xlabel("% tumours > 95th pct normal")
for i, (_, r) in enumerate(rdf.iterrows()):
    ax.text(r["pct"]+0.5, i, f"{r['pct']:.1f}%", va="center", fontsize=9,
            color=cols_b[i], fontweight="bold" if r.g==NEC else "normal")
# [removed for Nature style] ax.set_title("Tumour over-expression rate", pad=14, fontweight="bold")

# c) Stage-stratified expression (LUAD)
ax = fig.add_subplot(gs[0,2]); lab(ax,"c"); style(ax)
data_st = [nec_df[nec_df.stage==s].expr.dropna().values for s in ["I","II","III","IV"]]
bp = ax.boxplot(data_st, labels=["I","II","III","IV"], patch_artist=True, widths=0.6,
                flierprops=dict(marker=".",ms=1.5,alpha=0.3),
                medianprops=dict(color=C["ink"], lw=0.8))
for p, c in zip(bp["boxes"], plt.cm.Reds(np.linspace(0.35, 0.85, 4))):
    p.set_facecolor("white"); p.set_edgecolor(c); p.set_lw(0.8)
all_v = np.concatenate(data_st); all_r = np.concatenate([[i]*len(v) for i,v in enumerate(data_st)])
tau, p_tau = kendalltau(all_r, all_v)
ax.text(0.97, 0.97, f"τ = {tau:+.2f}\nP = {p_tau:.2g}",
        transform=ax.transAxes, fontsize=9, ha="right", va="top")
ax.set_xlabel("AJCC stage"); ax.set_ylabel("NECTIN4 log\u2082 CPM")
# [removed for Nature style] ax.set_title("Stage stratification", pad=14, fontweight="bold")

# d) Smoking
ax = fig.add_subplot(gs[1,0]); lab(ax,"d"); style(ax)
sm_map = {"Lifelong Non-Smoker":"Never",
          "Current Smoker":"Current",
          "Current Reformed Smoker for < or = 15 yrs":"Reformed <15y",
          "Current Reformed Smoker for > 15 yrs":"Reformed >15y"}
nec_df["smoke"] = nec_df.smoking.map(sm_map)
sm_order = ["Never","Reformed >15y","Reformed <15y","Current"]
data_sm = [nec_df[nec_df.smoke==s].expr.dropna().values for s in sm_order]
bp = ax.boxplot(data_sm, labels=sm_order, patch_artist=True, widths=0.6,
                flierprops=dict(marker=".",ms=1.5,alpha=0.3),
                medianprops=dict(color=C["ink"], lw=0.8))
for p, c in zip(bp["boxes"], plt.cm.YlOrBr(np.linspace(0.35, 0.85, len(sm_order)))):
    p.set_facecolor("white"); p.set_edgecolor(c); p.set_lw(0.8)
ax.tick_params(axis="x", rotation=30, labelsize=5.5)
for lbl in ax.get_xticklabels(): lbl.set_ha("right")
ax.set_ylabel("NECTIN4 log\u2082 CPM")
# [removed for Nature style] ax.set_title("Smoking history", pad=14, fontweight="bold")

# e) Vital status
ax = fig.add_subplot(gs[1,1]); lab(ax,"e"); style(ax)
data_v = [nec_df[nec_df.vital==v].expr.dropna().values for v in ["Alive","Dead"]]
bp = ax.boxplot(data_v, labels=["Alive","Dead"], patch_artist=True, widths=0.55,
                flierprops=dict(marker=".",ms=1.5,alpha=0.3),
                medianprops=dict(color=C["ink"], lw=0.8))
for p, c in zip(bp["boxes"], [C["normal"], C["tumor"]]):
    p.set_facecolor("white"); p.set_edgecolor(c); p.set_lw(0.8)
if all(len(v)>3 for v in data_v):
    _, pv = stats.ranksums(*data_v)
    ymax = max(np.percentile(v, 99) for v in data_v) + 0.2
    ax.plot([1,1,2,2],[ymax,ymax+0.15,ymax+0.15,ymax], color=C["ink"], lw=0.5)
    ax.text(1.5, ymax+0.22, sigstar(pv), ha="center", fontsize=10)
ax.set_ylabel("NECTIN4 log\u2082 CPM")
# [removed for Nature style] ax.set_title("Vital status", pad=14, fontweight="bold")

# f) Bootstrap AUC CI for NECTIN4
ax = fig.add_subplot(gs[1,2]); lab(ax,"f"); style(ax)
nec_vec = lcpm.loc[NEC, ac].values.astype(float)
n_boot = 500
rng = np.random.default_rng(0)
aucs_boot = []
for _ in range(n_boot):
    idx = rng.integers(0, len(nec_vec), len(nec_vec))
    try:
        a = roc_auc_score(y_roc[idx], nec_vec[idx])
        if a<0.5: a = 1-a
        aucs_boot.append(a)
    except Exception:
        pass
ax.hist(aucs_boot, bins=28, color=C["star"], alpha=0.78,
        edgecolor="white", lw=0.4)
ci_lo, ci_hi = np.percentile(aucs_boot, [2.5, 97.5])
mn = float(np.mean(aucs_boot))
ax.axvline(mn, color=C["ink"], lw=0.7)
ax.axvline(ci_lo, color=C["ink"], lw=0.4, ls=(0,(3,2)))
ax.axvline(ci_hi, color=C["ink"], lw=0.4, ls=(0,(3,2)))
ax.text(0.04, 0.97, f"AUC = {mn:.3f}\n95% CI = [{ci_lo:.3f}, {ci_hi:.3f}]\nbootstrap n = {n_boot}",
        transform=ax.transAxes, fontsize=9, ha="left", va="top")
ax.set_xlabel("Bootstrap AUC"); ax.set_ylabel("Count")
# [removed for Nature style] ax.set_title("AUC stability (bootstrap)", pad=14, fontweight="bold")

# caption removed
# save_fig(fig, "FigureS4_NECTIN4_clinical")  # MOVED: clinical panels
# now live in new FigureS5_Clinical_PanCancer (generated by figure_S7_external.py)


# ══════════════════════════════════════════════════════════════
# DELETED: old FigureS5 (Extended exosome cargo) — content is now in
# Figure 3 (a-d, f) plus FigureS7 (sc co-expression). Removing the
# duplicate panel set per the 10→7 supplementary consolidation.
# ══════════════════════════════════════════════════════════════
if False:
    print("\n── Figure S5: extended exosome cargo (DELETED) ──")
fig = plt.figure(figsize=(15, 9))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.60, wspace=0.75,
                       left=0.12, right=0.97, top=0.93, bottom=0.09)

# a) Bulk EV-marker mean expression: Tumour vs Normal
ax = fig.add_subplot(gs[0, :2]); lab(ax,"a", x=-0.05); style(ax)
ev_show = [NEC] + [g for g in EV_IN_LCPM if g != NEC][:22]
xs = np.arange(len(ev_show))
mt = lcpm.loc[ev_show, tc].mean(axis=1).values
mn = lcpm.loc[ev_show, nc].mean(axis=1).values
w = 0.4
ax.bar(xs-w/2, mt, w, color=C["tumor"], alpha=0.80, label="Tumour", edgecolor="white", lw=0.4)
ax.bar(xs+w/2, mn, w, color=C["normal"], alpha=0.80, label="Normal", edgecolor="white", lw=0.4)
ax.set_xticks(xs)
xt = ax.set_xticklabels(ev_show, fontsize=9, rotation=60, ha="right", fontstyle="italic")
for t in xt:
    if t.get_text()==NEC: t.set_color(C["star"]); t.set_fontweight("bold")
ax.set_ylabel("Mean log\u2082 CPM")
ax.legend(frameon=False, loc="upper right")
# [removed for Nature style] ax.set_title("Exosome biogenesis machinery in TCGA-LUAD bulk", pad=14, fontweight="bold")

# b) NECTIN4 ↔ EV marker correlation (bulk, tumour samples)
ax = fig.add_subplot(gs[0, 2]); lab(ax,"b"); style(ax)
co_rows = []
for g in [g for g in EV_TETRA+EV_ESCRT+EV_RAB+EV_HSP+EV_ANNEX if g in lcpm.index][:15]:
    r, p = stats.pearsonr(lcpm.loc[NEC, tc], lcpm.loc[g, tc])
    co_rows.append((g, r, p))
co = pd.DataFrame(co_rows, columns=["g","r","p"]).sort_values("r")
cols_b = [C["tumor"] if r>0 else C["normal"] for r in co.r]
ax.barh(co.g, co.r, color=cols_b, alpha=0.80, edgecolor="white", lw=0.5)
ax.axvline(0, color=C["ink"], lw=0.4)
for i, (_, row) in enumerate(co.iterrows()):
    s = sigstar(row.p)
    ax.text(row.r + (0.005 if row.r>=0 else -0.005), i, s,
            ha="left" if row.r>=0 else "right", va="center",
            fontsize=9, color=C["ink"])
for lbl in ax.get_yticklabels():
    lbl.set_fontstyle("italic"); lbl.set_fontsize(5.5)
ax.set_xlabel(f"Pearson r vs NECTIN4 (tumours)")
# [removed for Nature style] ax.set_title("Bulk co-expression", pad=14, fontweight="bold")

# c) NECTIN4 + tetraspanins correlation matrix (tumours)
ax = fig.add_subplot(gs[1, 0]); lab(ax,"c"); style(ax)
tet_co = [NEC] + [g for g in EV_TETRA if g in lcpm.index]
cor_t = lcpm.loc[tet_co, tc].T.corr()
sns.heatmap(cor_t, cmap=CMAP_DIV, vmin=-1, vmax=1, center=0,
            ax=ax, square=True, linewidths=0.4, annot=True, fmt=".2f",
            annot_kws={"size":6}, cbar_kws={"shrink":0.7})
xt = ax.set_xticklabels(tet_co, fontsize=10, fontstyle="italic", rotation=45, ha="right")
yt = ax.set_yticklabels(tet_co, fontsize=10, fontstyle="italic")
for t in list(xt)+list(yt):
    if t.get_text()==NEC: t.set_color(C["star"]); t.set_fontweight("bold")
# [removed for Nature style] ax.set_title("NECTIN4 + tetraspanins", pad=14, fontweight="bold")

# d) NECTIN4 ↔ EV network (r-weighted spokes)
ax = fig.add_subplot(gs[1, 1]); lab(ax,"d"); style(ax)
ax.set_xlim(-1.25, 1.25); ax.set_ylim(-1.25, 1.25); ax.set_aspect("equal")
ax.axis("off")
# Center node — bigger so the NECTIN4 label fits inside
ax.add_patch(Circle((0,0), 0.30, fc=C["star"], ec="white", lw=1.2, zorder=4))
ax.text(0, 0, "NECTIN4", ha="center", va="center", color="white",
        fontsize=9, fontweight="bold", zorder=5)
ring_genes = [g for g in EV_TETRA + ["TSG101","PDCD6IP","SDCBP","RAB27A","HSPA8"] if g in lcpm.index]
ang = np.linspace(0, 2*np.pi, len(ring_genes), endpoint=False)
for i, g in enumerate(ring_genes):
    x, y = 0.85*np.cos(ang[i]), 0.85*np.sin(ang[i])
    r, _ = stats.pearsonr(lcpm.loc[NEC, tc], lcpm.loc[g, tc])
    lw = max(0.6, abs(r)*3.0)
    col = C["tumor"] if r>0 else C["normal"]
    ax.plot([0,x],[0,y], color=col, lw=lw, alpha=0.55, zorder=1)
    ax.add_patch(Circle((x,y), 0.13+abs(r)*0.05, fc=col, ec="white",
                        lw=0.6, alpha=0.85, zorder=2))
    ax.text(x*1.20, y*1.20, g, ha="center", va="center", fontsize=9,
            fontstyle="italic", color=C["ink"])
# [removed for Nature style] ax.set_title("NECTIN4 ↔ EV machinery (r-weighted)", pad=14, fontweight="bold")
# Declarative attribution — independent EV evidence, no apology
ax.text(0.5, -0.05,
        "NECTIN4 is documented in A549 (LUAD cell-line) sEVs by MS\n"
        "(ExoCarta v5; see panel e).",
        transform=ax.transAxes, ha="center", va="top",
        fontsize=8.5, color=C["ink"])

# e) Curated EV-detection evidence (ExoCarta / Vesiclepedia / literature)
ax = fig.add_subplot(gs[1, 2]); lab(ax,"e"); style(ax)
# Curated table — published reports of NECTIN4 in EVs / exosomes
# Source: ExoCarta (https://exocarta.org), Vesiclepedia (http://microvesicles.org),
# and selected primary literature
evidence = [
    # (cancer / source, EV type, detection method, PMID-style refs are documented in caption)
    ("Urothelial",     "Exo",       "MS",       True),
    ("Breast",         "sEV",       "MS",       True),
    ("Bladder",        "Exo",       "WB+MS",    True),
    ("Lung (A549)",    "sEV",       "MS",       True),
    ("Ovarian",        "sEV",       "MS",       True),
    ("Pancreatic",     "Exo",       "WB",       True),
    ("Cervical",       "EVs",       "Proteome", True),
    ("Plasma EVs",     "Circ EVs",  "Proteome", True),
]
ev_df = pd.DataFrame(evidence, columns=["src","ev","method","det"])
yp = np.arange(len(ev_df))[::-1]
# Narrow panel — combine EV type + method into one descriptor; reserve right
# edge for the detection dot.
ax.set_xlim(0, 1); ax.set_ylim(-0.5, len(ev_df) + 0.6)
for i,(_, r) in enumerate(ev_df.iterrows()):
    y = yp[i]
    if i % 2 == 0:
        ax.add_patch(Rectangle((0.0, y-0.42), 1.0, 0.84,
                               fc=C["pale"], ec="none", alpha=0.45, zorder=1))
    ax.text(0.02, y, r["src"], fontsize=8.5, color="black",
            va="center", zorder=2)
    ax.text(0.50, y, f"{r['ev']} · {r['method']}", fontsize=8,
            color=C["plum"], va="center", fontstyle="italic", zorder=2)
    if r["det"]:
        ax.plot(0.95, y, marker="o", color=C["star"], ms=5.0, mec="white", mew=0.6, zorder=3)
ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)
# Column headers above the data with clear separation
HY = len(ev_df) + 0.35
ax.text(0.02, HY, "Cancer / source", fontsize=8.5, fontweight="bold", color=C["ink"])
ax.text(0.50, HY, "EV type · Method", fontsize=8.5, fontweight="bold", color=C["ink"])
ax.text(0.95, HY, "Det.",             fontsize=8.5, fontweight="bold", color=C["ink"], ha="center")
ax.plot([0, 1], [len(ev_df) - 0.07, len(ev_df) - 0.07], color=C["ink"], lw=0.6)
# [removed for Nature style] ax.set_title("NECTIN4 in EVs — published evidence", pad=8, fontweight="bold")
# footer removed

# caption removed

# save_fig(fig, "FigureS5_Exosome_Cargo")  # DELETED: redundant with Fig 3


print("\nDone. Outputs:")
for s in ["FigureS1_QC", "FigureS3_Candidates",
          "FigureS4_NECTIN4_clinical"]:
    print(f"  {F/(s+'.pdf')}")
