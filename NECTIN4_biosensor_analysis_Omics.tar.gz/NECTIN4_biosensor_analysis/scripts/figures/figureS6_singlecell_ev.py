#!/usr/bin/env python3
"""
Figure S7 — Single-cell EV co-expression & cross-cohort reproducibility.

Merged from the previous S7_KNUH_crosscohort + S7_SingleCell_EV.  The
per-tetraspanin breakdown and triple co-expression headline already live
in main Figure 3e; this supplementary figure carries the residual
single-cell evidence: cross-cohort distribution agreement (Kim 2020 vs
KNUH 117 k), cumulative tetraspanin co-expression, and per-patient
triple-positive distribution.

Panels
  a  Kim 2020 (tLung) vs KNUH 117 k: per-donor NECTIN4⁺ epithelial rate
  b  Cumulative tetraspanin co-expression in NECTIN4⁺ CNV-confirmed
     malignant cells (Kim 2020)
  c  Per-patient distribution of NECTIN4⁺ cells co-expressing ≥ 2 of
     CD9 / CD63 / CD81
  d  Cohort QC + cross-cohort notes
"""
import warnings; warnings.filterwarnings("ignore")
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import to_rgba
from matplotlib.patches import Rectangle
import anndata as ad
import seaborn as sns

R = Path("results"); F = Path("figures"); F.mkdir(exist_ok=True)
DATA = Path("data")

C = {
    "ink":    "#26333D", "tumor":  "#9E3B4E", "normal": "#6E94A6",
    "star":   "#C06A33", "sage":   "#6E8C73", "gold":   "#C9A24A",
    "plum":   "#7C6884", "grey":   "#AEACA2", "pale":   "#EDE7DC",
    "mist":   "#D3D8DA", "line":   "#9AA0A4",
}

plt.rcParams.update({
    "font.family":"sans-serif",
    "font.sans-serif":["TeX Gyre Heros","Helvetica Neue","Helvetica","Arial","Nimbus Sans","Liberation Sans","DejaVu Sans"],
    "font.size":11, "axes.titlesize":12, "axes.labelsize":11,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9,
    "figure.dpi":300, "savefig.dpi":300, "savefig.bbox":"standard",
    "axes.linewidth":0.6, "axes.edgecolor":C["ink"],
    "axes.labelcolor":C["ink"], "text.color":C["ink"],
    "xtick.color":C["ink"], "ytick.color":C["ink"],
    "axes.spines.top":False, "axes.spines.right":False,
    "lines.linewidth":1.0, "pdf.fonttype":42, "ps.fonttype":42,
})
sns.set_style("ticks")

def lab(ax, s):
    fig = ax.figure; fig.canvas.draw()
    bbox = ax.get_position()
    fig.text(bbox.x0 - 0.040, bbox.y1 + 0.014, s,
             fontsize=11, fontweight="bold", va="bottom", ha="left", color=C["ink"])
def style(ax):
    for sp in ax.spines.values(): sp.set_color(C["ink"]); sp.set_linewidth(0.6)

# ── Load Kim 2020 per-patient rates ───────────────────────────
print("Loading Kim 2020 per-patient rates ...")
sc = pd.read_csv(R/"sc_nectin4_ev.csv", index_col=0)
if "NECTIN4" not in sc.columns and "PVRL4" in sc.columns:
    sc = sc.rename(columns={"PVRL4":"NECTIN4"})
bo = pd.read_csv(R/"sc_barcode_origin.csv").set_index("barcode")
shared = sc.index.intersection(bo.index)
df_kim = pd.DataFrame({
    "n4": sc.loc[shared,"NECTIN4"].values > 0,
    "origin": bo.loc[shared,"sample_origin"].values,
    "cell_type": bo.loc[shared,"cell_type"].values,
}, index=shared)
df_kim["patient"] = ["_".join(b.split("_")[-2:]) for b in df_kim.index]
df_kim["is_epi"] = df_kim.cell_type.str.lower().str.contains("pitheli")
pr_kim = (df_kim[df_kim.is_epi & (df_kim.origin=="tLung")]
          .groupby("patient")
          .agg(n=("n4","size"), pct_pos=("n4", lambda x: 100*x.mean()))
          .reset_index())
pr_kim = pr_kim[pr_kim.n >= 50]
print(f"  Kim 2020 tLung patients (n≥50 epi cells): {len(pr_kim)}")

# ── Load KNUH 117k per-donor rates ────────────────────────────
print("Loading KNUH 117 k per-donor rates ...")
try:
    knuh_df = pd.read_csv(R/"scrna2_per_donor_nectin4.csv")
    knuh = knuh_df.rename(columns={"pct_nectin4_pos":"pct_pos"})
    print(f"  KNUH donors: {len(knuh)}")
except Exception as e:
    print(f"  KNUH load failed: {e}")
    knuh = pd.DataFrame({"pct_pos":[]})

# ── Load CNV-confirmed malignant cell co-expression matrix ────
print("Loading CNV-confirmed malignant cell EV-gene matrix ...")
src_e = pd.read_csv(R/"sc_cnv_malignancy_with_evgenes.csv", index_col=0)
src_e = src_e[src_e.malignant_cnv].copy()
for c in ["NECTIN4","CD9","CD63","CD81"]:
    src_e[c] = src_e[c] > 0
src_e["patient"] = src_e["Sample"]
n4_cells = src_e[src_e.NECTIN4]
tet_count = n4_cells[["CD9","CD63","CD81"]].sum(axis=1).values
total_n4 = n4_cells.shape[0]
print(f"  CNV-confirmed malignant NECTIN4+ cells: {total_n4:,}")

# ══════════════════════════════════════════════════════════════
# Figure
# ══════════════════════════════════════════════════════════════
fig = plt.figure(figsize=(14, 9))
gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.55, wspace=0.40,
                       left=0.09, right=0.97, top=0.94, bottom=0.09)

# ── a) Kim vs KNUH cross-cohort comparison ──────────────────
ax = fig.add_subplot(gs[0,0]); lab(ax,"a"); style(ax)
data_c = [pr_kim.pct_pos.values, knuh.pct_pos.values]
parts = ax.violinplot(data_c, positions=[0,1], widths=0.7,
                       showmeans=False, showextrema=False)
for pc, col in zip(parts["bodies"], [C["plum"], C["star"]]):
    pc.set_facecolor(to_rgba(col, 0.30)); pc.set_edgecolor(col); pc.set_lw(0.8)
bp = ax.boxplot(data_c, positions=[0,1], widths=0.20,
                patch_artist=True, showfliers=False,
                medianprops=dict(color=C["ink"], lw=1.0),
                whiskerprops=dict(color=C["ink"], lw=0.6),
                capprops=dict(color=C["ink"], lw=0.6),
                boxprops=dict(lw=0.6))
for p, col in zip(bp["boxes"], [C["plum"], C["star"]]):
    p.set_facecolor("white"); p.set_edgecolor(col)
for xi, vals, col in [(0, data_c[0], C["plum"]), (1, data_c[1], C["star"])]:
    jit = np.random.normal(xi, 0.05, len(vals))
    ax.scatter(jit, vals, s=18, color=col, alpha=0.75,
               edgecolors="white", lw=0.4, zorder=3)
ax.set_xticks([0,1])
ax.set_xticklabels([f"Kim 2020\ntLung\n(n = {len(data_c[0])})",
                     f"KNUH 117 k\nLUAD\n(n = {len(data_c[1])})"], fontsize=10)
ax.set_ylabel("% NECTIN4\u207A epithelial cells (per donor)")
_, p_cc = stats.ranksums(*data_c) if len(data_c[1]) else (0, 1.0)
ymax = max([v for d in data_c for v in d] + [50])
ax.set_ylim(top=ymax*1.30)
ax.text(0.03, 0.97, f"rank-sum  P = {p_cc:.2g}",
        transform=ax.transAxes, ha="left", va="top",
        fontsize=9.5, fontweight="bold", color="black",
        bbox=dict(fc="white", ec=C["mist"], lw=0.5, pad=3))

# ── b) Cumulative tetraspanin co-expression ───────────────────
ax = fig.add_subplot(gs[0,1]); lab(ax,"b"); style(ax)
cats = ["≥ 0", "≥ 1", "≥ 2", "= 3"]
counts = [
    int((tet_count >= 0).sum()),
    int((tet_count >= 1).sum()),
    int((tet_count >= 2).sum()),
    int((tet_count == 3).sum()),
]
pct = [100*c/total_n4 for c in counts]
cols_b = [C["mist"], C["gold"], C["star"], C["tumor"]]
ax.bar(cats, pct, color=cols_b, edgecolor="white", lw=0.4, width=0.7)
for i, v in enumerate(pct):
    ax.text(i, v + 1.0, f"{v:.1f}%", ha="center", fontsize=9.5,
            fontweight="bold", color="black")
ax.set_ylim(0, 110)
ax.set_ylabel("% of NECTIN4\u207A malignant cells")
ax.set_xlabel("co-expressing this many of CD9 / CD63 / CD81")

# ── c) Per-patient triple-positive distribution ──────────────
ax = fig.add_subplot(gs[1,0]); lab(ax,"c"); style(ax)
per_pt = []
for pid, sub in n4_cells.groupby("patient"):
    if len(sub) < 30: continue
    trip = (sub[["CD9","CD63","CD81"]].sum(axis=1) >= 2)
    per_pt.append({"patient":pid, "n_cells":len(sub),
                   "pct_triple":100*trip.mean()})
pp = pd.DataFrame(per_pt).sort_values("pct_triple", ascending=False)
xp = np.arange(len(pp))
ax.bar(xp, pp.pct_triple, color=C["tumor"], edgecolor="white", lw=0.4, width=0.85)
ax.axhline(pp.pct_triple.median(), color=C["ink"], lw=0.8, ls=(0,(3,2)),
           label=f"median = {pp.pct_triple.median():.1f}%")
ax.set_xticks([])
ax.set_xlabel(f"each bar = one patient (CNV-confirmed malignant, n = {len(pp)})")
ax.set_ylabel("% NECTIN4\u207A cells with ≥ 2 tetraspanins", fontsize=10)
ax.set_ylim(0, 110)
ax.legend(loc="lower left", frameon=False, fontsize=9)

# ── d) Cohort QC + cross-cohort note ─────────────────────────
ax = fig.add_subplot(gs[1,1]); lab(ax,"d"); style(ax); ax.axis("off")
ax.set_xlim(0, 1); ax.set_ylim(0, 1)
notes = [
    ("Kim 2020 (GSE131907)",
     f"tLung tumour epithelial cells from {len(pr_kim)} donors\n"
     f"median NECTIN4\u207A rate per donor = {np.median(pr_kim.pct_pos):.0f}%"),
    ("KNUH 117 k",
     f"primary-tumour LUAD donors (CZ CellxGene); {len(knuh)} patients\n"
     f"median NECTIN4\u207A rate per donor = {np.median(knuh.pct_pos):.0f}%"
     if len(knuh) else "KNUH cohort table not found"),
    ("Cross-cohort consistency",
     f"rank-sum P = {p_cc:.2g}; both cohorts show ubiquitous NECTIN4\u207A\n"
     f"epithelial signal, never absent in any donor"),
    ("Tetraspanin co-expression",
     "in CNV-confirmed malignant Kim 2020 cells: ≥1 of CD9/63/81 = 99.3%,\n"
     "≥2 = 94.9%, all 3 = 71.2% (Fig 3e + panels b,c above)"),
    ("EV-loading prerequisite",
     "NECTIN4\u207A malignant cells almost universally co-express the\n"
     "tetraspanin loading machinery required for EV display"),
]
y0 = 0.95; step = 0.18
for i,(k,v) in enumerate(notes):
    y = y0 - i*step
    ax.add_patch(Rectangle((0.005, y-0.013), 0.018, 0.026,
                            fc=C["star"], ec="none",
                            transform=ax.transAxes, clip_on=False))
    ax.text(0.040, y, k, fontsize=9.5, fontweight="bold", color="black", va="center")
    ax.text(0.040, y-0.05, v, fontsize=7.5, color="black", va="top", linespacing=1.2)

plt.rcParams["savefig.bbox"] = "standard"
for ext in ("pdf","png"):
    fig.savefig(F/f"FigureS6_SingleCell_EV.{ext}", facecolor="white", dpi=350)
plt.close(fig)
print(f"\n[\u2713] FigureS6_SingleCell_EV.pdf (+ .png)")
