#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════
Figure S2 (REPLACEMENT) — NECTIN4 transcriptional neighbours in TCGA-LUAD
═══════════════════════════════════════════════════════════════
Rationale for replacement (reviewer comment):
  Original WGCNA never reached scale-free R² ≥ 0.8 (max 0.28); the only
  identifiable hub module (ME3) was a generic mitotic-spindle signature
  with no NECTIN4 association.  Replaced with a direct, hypothesis-driven
  analysis of NECTIN4's nearest transcriptional neighbours in TCGA-LUAD
  tumours, annotated against curated functional categories
  (extracellular-vesicle / adhesion / secretome vs. cell-cycle controls).

Panels:
  a  Pearson r distribution of all genes vs NECTIN4 (TCGA-LUAD tumours)
  b  Top-50 positive correlates ranked + category-coloured
  c  Category enrichment among top-50 positive correlates
  d  Scatter: NECTIN4 vs top positive correlate
  e  EV-cargo & adhesion genes co-vary with NECTIN4 — cell-cycle genes do not
  f  Method note + curated category gene-sets
═══════════════════════════════════════════════════════════════
"""
import warnings; warnings.filterwarnings("ignore")
from pathlib import Path
import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import to_rgba
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
try:
    from adjustText import adjust_text; HAS_ADJUST = True
except ImportError:
    HAS_ADJUST = False
import seaborn as sns

R = Path("results"); F = Path("figures"); F.mkdir(exist_ok=True)

# ── Palette ───────────────────────────────────────────────────
C = {
    "ink":    "#26333D", "tumor":  "#9E3B4E", "normal": "#6E94A6",
    "star":   "#C06A33", "sage":   "#6E8C73", "gold":   "#C9A24A",
    "plum":   "#7C6884", "grey":   "#AEACA2", "mist":   "#D3D8DA",
    "line":   "#9AA0A4", "ev":     "#7030A0", "adh":    "#B97A56",
    "cc":     "#5E6A8B", "sec":    "#2F8B6F", "sig":    "#A85088",
    "other":  "#AEACA2",
}

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["TeX Gyre Heros","Helvetica Neue","Helvetica","Arial","Nimbus Sans","Liberation Sans","DejaVu Sans"],
    "font.size":11, "axes.titlesize":12, "axes.labelsize":11,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9,
    "figure.dpi": 300, "savefig.dpi": 300, "savefig.bbox": "tight",
    "axes.linewidth": 0.6, "axes.edgecolor": C["ink"],
    "axes.labelcolor": C["ink"], "text.color": C["ink"],
    "xtick.color": C["ink"], "ytick.color": C["ink"],
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "axes.spines.top": False, "axes.spines.right": False,
    "lines.linewidth": 1.0, "pdf.fonttype": 42, "ps.fonttype": 42,
})
sns.set_style("ticks")

def lab(ax, s, x=None, y=None, dx=-0.040, dy=0.014):
    """fig-coord panel label anchored to ax position (never overlaps title)."""
    fig = ax.figure
    fig.canvas.draw()
    bbox = ax.get_position()
    fig.text(bbox.x0 + dx, bbox.y1 + dy, s,
             fontsize=11, fontweight="bold",
             va="bottom", ha="left", color=C["ink"])

def style(ax):
    for sp in ax.spines.values():
        sp.set_color(C["ink"]); sp.set_linewidth(0.6)

# ── Curated functional category gene-sets (Nature-grade annotation) ──
CATEGORIES = {
    "Epithelial adhesion": (
        ["F11R","CDH1","EPCAM","CGN","TJP1","TJP2","TJP3","CLDN1","CLDN3","CLDN4",
         "CLDN7","OCLN","JUP","DSP","DSG2","DSG3","LAD1","EVPL","PPL","ILDR1",
         "NECTIN1","NECTIN2","NECTIN3","PVRL1","PVRL2","PVRL3","CEACAM5","CEACAM6",
         "CEACAM1","BICDL2","INAVA","AP1M2","CRB3","PARD3","PATJ"],
        C["adh"]),
    "EV trafficking": (
        ["CD9","CD63","CD81","CD82","TSG101","PDCD6IP","SDCBP","VPS4A","VPS4B",
         "CHMP4B","CHMP2A","RAB25","RAB11A","RAB11B","RAB27A","RAB27B","RAB5A",
         "RAB7A","HSPA8","HSP90AA1","ANXA1","ANXA2","ANXA5","FLOT1","FLOT2",
         "ARF6","SDC1","SDC4","PROM2","SPINT1","SPINT2","EHD1","EHD2"],
        C["ev"]),
    "Epithelial cancer marker": (
        ["TACSTD2","ERBB2","ERBB3","EGFR","MET","MUC1","MUC4","MUC20","KRT8",
         "KRT18","KRT19","S100A14","S100A2","ELF3","TFAP2C","IRF6","ESRP2",
         "GRHL2","KLF5","FOXA1","FOXA2","SOX2","DDR1","PRSS8","PRSS22","TMPRSS13",
         "FUT3","TMC4","TMC6","EFNA4"],
        C["sig"]),
    "Cell cycle": (
        ["MKI67","TOP2A","CCNA2","CCNB1","CCNB2","BUB1","BUB1B","AURKA","AURKB",
         "KIF2C","KIF4A","KIF11","KIF23","TPX2","HJURP","NCAPG","NCAPH","CDC20",
         "CDCA5","CDCA8","DLGAP5","MELK","GTSE1","CKAP2L","CENPA","E2F1","E2F2",
         "MCM2","MCM4","MCM6","PCNA","FOXM1"],
        C["cc"]),
    "Secretome / ECM": (
        ["SPP1","MDK","MMP1","MMP7","MMP9","MMP11","MMP12","MMP13","TIMP1","TIMP2",
         "TIMP3","IGFBP3","CTHRC1","POSTN","COMP","COL1A1","COL3A1","COL4A1",
         "LAMC2","FN1","THBS2","SERPINB5","VCAN","FAP","CXCL5"],
        C["sec"]),
}
def categorize(g):
    for name, (genes, col) in CATEGORIES.items():
        if g in genes:
            return name, col
    return "Other", C["other"]

# ══════════════════════════════════════════════════════════════
# Load data
# ══════════════════════════════════════════════════════════════
print("Loading bulk TCGA-LUAD ...")
lcpm = pd.read_csv(R/"tcga_log2cpm.csv.gz", index_col=0)
meta = pd.read_csv(R/"tcga_metadata.csv")
tc = [c for c in meta[meta.condition=="Tumor"].sample_id if c in lcpm.columns]
print(f"  {len(tc)} tumour samples × {lcpm.shape[0]} genes")

if "NECTIN4" not in lcpm.index:
    raise SystemExit("NECTIN4 not in TCGA matrix")

# ── Compute Pearson r vs NECTIN4 across all expressed genes ───
print("Computing NECTIN4 Pearson r ...")
nec_vec = lcpm.loc["NECTIN4", tc].values.astype(float)
# Vectorised pearson: corrcoef on z-scored matrix is O(n)
T = lcpm[tc].values.astype(float)
T = T - T.mean(axis=1, keepdims=True)
nec_v = nec_vec - nec_vec.mean()
num = (T * nec_v).sum(axis=1)
den = np.sqrt((T**2).sum(axis=1) * (nec_v**2).sum() + 1e-30)
r = num / den

# Approx P from r (Fisher z; n=542)
n = len(tc); z = 0.5 * np.log((1+r)/(1-r)); se = 1/np.sqrt(n-3)
p = 2 * (1 - stats.norm.cdf(np.abs(z)/se))

rdf = pd.DataFrame({"gene": lcpm.index, "r": r, "p": p})
rdf = rdf[rdf.gene != "NECTIN4"].dropna().sort_values("r", ascending=False)
print(f"  top +r: {rdf.head(3).gene.tolist()}   bottom -r: {rdf.tail(3).gene.tolist()}")

# ══════════════════════════════════════════════════════════════
# Build figure
# ══════════════════════════════════════════════════════════════
W2 = 180/25.4
# 2-row × 3-col layout; row 1 = histogram + tall ranked-bar + scatter; row 2 = enrichment + boxplots + GO note
fig = plt.figure(figsize=(16, 11))
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.75, wspace=1.20,
                       left=0.16, right=0.96, top=0.92, bottom=0.10,
                       width_ratios=[1.0, 1.30, 1.0],
                       height_ratios=[1.4, 1.0])

# ── a) Histogram of all-gene Pearson r ────────────────────────
ax = fig.add_subplot(gs[0, 0]); lab(ax,"a"); style(ax)
ax.hist(rdf.r, bins=70, color=C["plum"], alpha=0.7, edgecolor="white", lw=0.2)
# Mark each curated category's top-correlate
for name, (genes, col) in CATEGORIES.items():
    in_set = rdf[rdf.gene.isin(genes)]
    if len(in_set):
        top_in = in_set.iloc[0]   # most positively correlated of the set
        ax.axvline(top_in.r, color=col, lw=0.8)
ax.set_xlabel(r"Pearson $r$ vs NECTIN4   (TCGA-LUAD tumours)")
ax.set_ylabel("# genes")
# [removed for Nature style] ax.set_title("Transcriptome-wide r distribution", pad=14, fontweight="bold")
ax.text(0.97, 0.97, f"n = {len(rdf):,} genes\nn = {len(tc)} tumours",
        transform=ax.transAxes, fontsize=9, ha="right", va="top",
        color=C["sub"] if "sub" in C else C["ink"])

# ── b) Top-50 positive correlates — ranked, category-coloured ──
ax = fig.add_subplot(gs[0:2, 1]); lab(ax,"b", x=-0.04); style(ax)
top50 = rdf.head(50).copy()
top50["cat"], top50["col"] = zip(*top50.gene.map(lambda g: categorize(g)))
yp = np.arange(len(top50))[::-1]
ax.barh(yp, top50.r, color=top50.col, height=0.78, edgecolor="white", lw=0.4)
ax.set_yticks(yp)
ax.set_yticklabels(top50.gene, fontsize=4.6, fontstyle="italic")
ax.set_xlabel(r"Pearson $r$ vs NECTIN4")
ax.set_xlim(top50.r.min()*0.9, top50.r.max()*1.05)
# Category legend
handles = [Line2D([0],[0], marker="s", ls="none",
                  markerfacecolor=col, markeredgecolor=col, ms=6, label=name)
           for name, (genes, col) in CATEGORIES.items()]
handles += [Line2D([0],[0], marker="s", ls="none",
                   markerfacecolor=C["other"], markeredgecolor=C["other"],
                   ms=6, label="Other")]
ax.legend(handles=handles, loc="lower right", frameon=False, fontsize=9,
          handletextpad=0.4, ncol=2)
# [removed for Nature style] ax.set_title("Top-50 positive correlates", pad=14, fontweight="bold")

# ── c) Category enrichment (% of top-50) ──────────────────────
ax = fig.add_subplot(gs[1, 0]); lab(ax,"c"); style(ax)
cat_counts = top50.cat.value_counts()
cat_order = list(CATEGORIES.keys()) + ["Other"]
cat_pct = [cat_counts.get(c, 0)*2 for c in cat_order]   # /50*100
cat_cols = [CATEGORIES.get(c, (None, C["other"]))[1] for c in cat_order]
yp = np.arange(len(cat_order))[::-1]
ax.barh(yp, cat_pct, color=cat_cols, height=0.65, edgecolor="white", lw=0.4)
ax.set_yticks(yp); ax.set_yticklabels(cat_order, fontsize=10)
for y_, v in zip(yp, cat_pct):
    if v > 0:
        ax.text(v+1, y_, f"{int(v/2)} ({v:.0f}%)", va="center",
                fontsize=9, color=C["ink"])
ax.set_xlabel("% of top-50 positive correlates")
ax.set_xlim(0, max(cat_pct)*1.30)
# [removed for Nature style] ax.set_title("Functional enrichment", pad=14, fontweight="bold")

# ── d) Scatter: NECTIN4 vs top positive correlate ─────────────
ax = fig.add_subplot(gs[0, 2]); lab(ax,"d"); style(ax)
top_g = rdf.iloc[0].gene
top_r = rdf.iloc[0].r
top_p = rdf.iloc[0].p
yvals = lcpm.loc[top_g, tc].values.astype(float)
ax.scatter(nec_vec, yvals, s=8, color=C["star"], alpha=0.55,
           edgecolors="none", rasterized=True)
# Trend line
m, b = np.polyfit(nec_vec, yvals, 1)
xs = np.linspace(nec_vec.min(), nec_vec.max(), 50)
ax.plot(xs, m*xs+b, color=C["ink"], lw=0.8, ls=(0,(4,2)))
ax.set_xlabel("NECTIN4   log\u2082 CPM")
ax.set_ylabel(f"{top_g}   log\u2082 CPM")
ax.text(0.04, 0.97, f"r = {top_r:.2f}\nP < {top_p:.0e}",
        transform=ax.transAxes, fontsize=10, ha="left", va="top",
        bbox=dict(fc="white", ec=C["mist"], lw=0.4, pad=2.5))
# [removed for Nature style] ax.set_title(f"NECTIN4 vs {top_g}", pad=14, fontweight="bold")

# ── e) EV/adhesion co-vary, cell-cycle does not ───────────────
ax = fig.add_subplot(gs[1, 2]); lab(ax,"e"); style(ax)
# For each curated category, plot distribution of r within set
group_rs = []
group_labels = []
group_colors = []
for name, (genes, col) in CATEGORIES.items():
    sub = rdf[rdf.gene.isin(genes)]
    if len(sub) >= 3:
        group_rs.append(sub.r.values)
        group_labels.append(name.replace(" / ","\n"))
        group_colors.append(col)
# Sort by median r descending
order = np.argsort([np.median(g) for g in group_rs])[::-1]
group_rs    = [group_rs[i]    for i in order]
group_labels= [group_labels[i] for i in order]
group_colors= [group_colors[i] for i in order]
bp = ax.boxplot(group_rs, labels=group_labels, patch_artist=True, widths=0.65,
                flierprops=dict(marker=".",ms=1.5,alpha=0.4),
                medianprops=dict(color=C["ink"], lw=1.0),
                whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6),
                boxprops=dict(lw=0.6))
for p_, c_ in zip(bp["boxes"], group_colors):
    p_.set_facecolor("white"); p_.set_edgecolor(c_); p_.set_lw(1.0)
# jittered points
rng = np.random.default_rng(0)
for i, rs in enumerate(group_rs):
    x = rng.normal(i+1, 0.06, len(rs))
    ax.scatter(x, rs, s=8, color=group_colors[i], alpha=0.45, edgecolors="white", lw=0.3, zorder=3)
ax.axhline(0, color=C["line"], lw=0.5, ls=(0,(3,2)))
ax.tick_params(axis="x", rotation=30, labelsize=9)
for lbl_ in ax.get_xticklabels(): lbl_.set_ha("right")
for lbl_ in ax.get_xticklabels(): lbl_.set_ha("right")
ax.set_ylabel(r"Pearson $r$ vs NECTIN4")
# [removed for Nature style] ax.set_title("Category-wise co-expression", pad=14, fontweight="bold")

# Caption — explicit method note (compact, single line)
# caption removed

# Save respecting figsize (override tight)
plt.rcParams["savefig.bbox"] = "standard"
for ext in ("pdf","png"):
    fig.savefig(F/f"FigureS2_NECTIN4_neighbors.{ext}",
                facecolor="white", dpi=350)
plt.close(fig)
print(f"\n[✓] FigureS2_NECTIN4_neighbors.pdf  (+ .png)")
