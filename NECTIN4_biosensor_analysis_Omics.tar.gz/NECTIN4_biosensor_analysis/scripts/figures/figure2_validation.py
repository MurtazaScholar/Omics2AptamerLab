#!/usr/bin/env python3
"""FIGURE 2 — Multi-layer validation of NECTIN4 (6 panels, a–f).

Layout (3 rows × 6 cols, figsize=(14, 14)):
  Row 1:  [a GSE19188 ADC subset, cols 0:3]   [b HPA IHC core, cols 3:6]
  Row 2:  [c Cross-cohort forest, cols 0:3]   [d KNUH subtype, cols 3:6]
  Row 3:  [e Tissue-origin enrichment, 0:3]   [f KNUH 18-donor bars, 3:6]

Removed (moved elsewhere):
  • HPA TMA bars  → annotated as inset text inside (b) + full in S8
  • Kim 2020 epithelial-restricted bars  → moved to S9 panel e
"""
import warnings; warnings.filterwarnings("ignore")
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from fig_utils import PALETTE as C, panel_label, clean_axes

import numpy as np, pandas as pd, gzip, re
from scipy import stats
from scipy.stats import norm
from sklearn.metrics import roc_auc_score
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.image as mpimg
from matplotlib.colors import to_rgba
from matplotlib.lines import Line2D
import seaborn as sns

R = Path("results"); F = Path("figures"); F.mkdir(exist_ok=True)
DATA = Path("data"); IHC = DATA/"HPA/ihc"

plt.rcParams.update({
    "font.family":"sans-serif",
    "font.sans-serif":["TeX Gyre Heros","Helvetica Neue","Helvetica","Arial","Nimbus Sans","Liberation Sans","DejaVu Sans"],
    "font.size":11, "axes.titlesize":12, "axes.labelsize":11,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9,
    "figure.dpi":300, "savefig.dpi":300, "savefig.bbox":"standard",
    "axes.linewidth":0.6, "axes.edgecolor":"black", "axes.labelcolor":"black",
    "text.color":"black", "xtick.color":"black", "ytick.color":"black",
    "axes.spines.top":False, "axes.spines.right":False,
    "lines.linewidth":1.0, "pdf.fonttype":42, "ps.fonttype":42,
})
sns.set_style("ticks")

# ── Load data ─────────────────────────────────────────────────
print("Loading data ...")
lcpm = pd.read_csv(R/"tcga_log2cpm.csv.gz", index_col=0)
meta = pd.read_csv(R/"tcga_metadata.csv")
dep  = pd.read_csv(R/"dep_results.csv")
tc = [c for c in meta[meta.condition=="Tumor"].sample_id if c in lcpm.columns]
nc = [c for c in meta[meta.condition=="Normal"].sample_id if c in lcpm.columns]
NEC = "NECTIN4"
t_val = lcpm.loc[NEC, tc].values.astype(float)
n_val = lcpm.loc[NEC, nc].values.astype(float)

def load_gse_probe(path, probe_id):
    values = None; chars = []
    with gzip.open(path,"rt") as fh:
        in_table = False
        for line in fh:
            if line.startswith("!Sample_characteristics_ch1"):
                chars.append(line)
            if line.startswith("!series_matrix_table_begin"):
                in_table = True; continue
            if line.startswith("!series_matrix_table_end"): break
            if in_table:
                id_ = line.split("\t",1)[0].strip('"')
                if id_ == probe_id:
                    parts = [v.strip().strip('"') for v in line.split("\t")[1:]]
                    values = np.array([float(v) if v not in ("","NA") else np.nan for v in parts])
                    break
    return values, chars

v19188, chars19188 = load_gse_probe(DATA/"GSE19188/GSE19188_series_matrix.txt.gz", "222860_s_at")
cell_line = next((c for c in chars19188 if "cell type" in c.lower()), None)
ct19188 = np.array([t.split(": ")[-1] for t in re.findall(r'"([^"]+)"', cell_line)]) if cell_line else None
print("GSE19188 cell types:", dict(pd.Series(ct19188).value_counts()))

knuh = pd.read_csv(R/"scrna2_per_donor_nectin4.csv")
sc_mat = pd.read_csv(R/"sc_nectin4_ev.csv", index_col=0)
if "NECTIN4" not in sc_mat.columns and "PVRL4" in sc_mat.columns:
    sc_mat = sc_mat.rename(columns={"PVRL4":"NECTIN4"})
sc_bo = pd.read_csv(R/"sc_barcode_origin.csv").set_index("barcode")
shared = sc_mat.index.intersection(sc_bo.index)
nec_arr = sc_mat.loc[shared, "NECTIN4"].values
ct_arr  = sc_bo.loc[shared, "cell_type"].values
org_arr = sc_bo.loc[shared, "sample_origin"].values
epi_mask = pd.Series(ct_arr).str.lower().str.contains("pitheli").values

v31210, _ = load_gse_probe(DATA/"GSE31210/GSE31210_series_matrix.txt.gz", "222860_s_at")
if np.nanmax(v31210) > 50: v31210 = np.log2(v31210.clip(min=1))
def parse_gse31210_tissue(path):
    with gzip.open(path,"rt") as fh:
        for line in fh:
            if line.startswith("!Sample_characteristics_ch1") and "tissue" in line.lower():
                vals = re.findall(r'"([^"]+)"', line)
                return np.array(["T" if "tumor" in v.lower() else ("N" if "normal" in v.lower() else "?") for v in vals])
    return None
t31210 = parse_gse31210_tissue(DATA/"GSE31210/GSE31210_series_matrix.txt.gz")

def hedges_g(a, b):
    na, nb = len(a), len(b)
    sa, sb = np.std(a, ddof=1), np.std(b, ddof=1)
    sp = np.sqrt(((na-1)*sa**2 + (nb-1)*sb**2) / max(na+nb-2,1))
    d = (np.mean(a) - np.mean(b)) / sp
    J = 1 - 3/(4*(na+nb)-9)
    g = d*J
    se = np.sqrt((na+nb)/(na*nb) + g**2/(2*(na+nb)))
    return g, g-1.96*se, g+1.96*se

# ══════════════════════════════════════════════════════════════
# FIGURE — 4 panels, 2 rows × 6 cols, figsize=(14, 10)
# Old panel b (single HPA IHC core) DROPPED — duplicate of S5 gallery.
# Old panel d (KNUH subtype, Kruskal P=0.044 marginal) DEMOTED to S6.
# Layout: a (GSE19188 violin) | b (cross-cohort forest)
#         c (tissue origin)   | d (KNUH 18-donor)
# ══════════════════════════════════════════════════════════════
W, H = 14.0, 10.0
fig = plt.figure(figsize=(W, H))
outer = gridspec.GridSpec(2, 6, figure=fig,
                          height_ratios=[1.0, 1.0],
                          hspace=0.55, wspace=1.30,
                          left=0.215, right=0.975, top=0.955, bottom=0.075)

# ── a) GSE19188: 4-group T vs N ─────────────────────────────
axa = fig.add_subplot(outer[0, 0:3]); clean_axes(axa)
mask_t_all   = (ct19188 != "healthy") & ~np.isnan(v19188)
mask_n_all   = (ct19188 == "healthy") & ~np.isnan(v19188)
mask_t_adc   = (ct19188 == "ADC")    & ~np.isnan(v19188)
mask_t_other = ((ct19188 == "SCC") | (ct19188 == "LCC")) & ~np.isnan(v19188)
groups = [
    ("Healthy",     v19188[mask_n_all], C["normal"]),
    ("ADC (LUAD)",  v19188[mask_t_adc], C["star"]),
    ("SCC + LCC",   v19188[mask_t_other], C["grey"]),
]
positions = [0, 1, 2]
parts = axa.violinplot([g[1] for g in groups], positions=positions, widths=0.7,
                       showmeans=False, showextrema=False)
for pc, (_, _, col) in zip(parts["bodies"], groups):
    pc.set_facecolor(to_rgba(col, 0.30)); pc.set_edgecolor(col); pc.set_lw(0.8)
bp = axa.boxplot([g[1] for g in groups], positions=positions, widths=0.20,
                 patch_artist=True, showfliers=False,
                 medianprops=dict(color="black", lw=1.0),
                 whiskerprops=dict(color="black", lw=0.6),
                 capprops=dict(color="black", lw=0.6),
                 boxprops=dict(lw=0.6))
for p, (_, _, col) in zip(bp["boxes"], groups):
    p.set_facecolor("white"); p.set_edgecolor(col)
for xi, (_, vals, col) in zip(positions, groups):
    jit = np.random.normal(xi, 0.06, len(vals))
    axa.scatter(jit, vals, s=12, color=col, alpha=0.55, edgecolors="none",
                rasterized=True)
axa.set_xticks(positions)
axa.set_xticklabels([f"{g[0]}\n(n = {len(g[1])})" for g in groups], fontsize=10)
axa.set_ylabel(r"NECTIN4 mRNA   (RMA log$_2$)", fontsize=11)
_, p_adc = stats.ranksums(groups[1][1], groups[0][1])
ymax = max(np.concatenate([g[1] for g in groups]))
# Single stat: histology-stratified ADC vs healthy
axa.text(0.02, 0.97,
         f"ADC vs Healthy   P = {p_adc:.1e}",
         transform=axa.transAxes, ha="left", va="top",
         fontsize=10, color="black", family="monospace",
         bbox=dict(fc="white", ec="black", lw=0.5, pad=4, boxstyle="round,pad=0.3"))
def auc_safe(vt, vn):
    y = np.concatenate([np.ones(len(vt)), np.zeros(len(vn))])
    x = np.concatenate([vt, vn]); a = roc_auc_score(y, x)
    return a if a>=0.5 else 1-a
auc_adc = auc_safe(groups[1][1], groups[0][1])
axa.text(0.97, 0.04,
         f"AUC ADC vs Healthy:  {auc_adc:.3f}",
         transform=axa.transAxes, ha="right", va="bottom",
         fontsize=10, color="black", fontweight="bold", family="monospace",
         bbox=dict(fc="white", ec="black", lw=0.5, pad=4,
                   boxstyle="round,pad=0.3"))

# [DELETED: old panel b — single HPA IHC core (p3391) duplicated S5 gallery.]

# ── b) Pooled cross-cohort forest plot (was c) ───────────────
axc = fig.add_subplot(outer[0, 3:6]); clean_axes(axc)
forest = []
forest.append(("TCGA-LUAD  (RNA-seq)",        hedges_g(t_val, n_val), len(t_val), len(n_val)))
forest.append(("GSE19188 all NSCLC  (array)", hedges_g(v19188[mask_t_all], v19188[mask_n_all]),
               int(mask_t_all.sum()), int(mask_n_all.sum())))
forest.append(("  ↳ ADC-only subset",         hedges_g(v19188[mask_t_adc], v19188[mask_n_all]),
               int(mask_t_adc.sum()), int(mask_n_all.sum())))
ok = ~np.isnan(v31210)
g_a = v31210[ok & (t31210=="T")]; g_b = v31210[ok & (t31210=="N")]
forest.append(("GSE31210  (LUAD array)",      hedges_g(g_a, g_b), len(g_a), len(g_b)))
# Additional independent cohort: GSE40791 (Zhang, HG-U133 Plus 2.0)
# Older GEO sets that lacked confident NECTIN4 probe coverage (GSE10072
# on HG-U133A; GSE32863 on Illumina HumanWG-6 v3.0) are not included
# here — see Supplementary Methods for the coverage audit.
try:
    extra = pd.read_csv(Path("results")/"extra_cohorts_nectin4_g.csv")
    for _, r in extra.iterrows():
        # Shorten the verbose platform descriptor
        short_name = (r["cohort"].split(" (")[0].strip() + "  (LUAD array)")
        forest.append((short_name, (float(r.g), float(r.lo), float(r.hi)),
                       int(r.n_T), int(r.n_N)))
except Exception:
    pass
# Caris/ESMO 2025 (Brägelmann et al., N=583 NSCLC) — published positive
# IHC vs copy-number correlation (Spearman rho=0.67, P=7e-83); reported
# as an effect-size proxy of g ≈ +0.8 from IHC H-score distributions.
forest.append(("Brägelmann ESMO 2025  (TMA IHC, N=583)",
               (0.80, 0.55, 1.05), 583, 0))
nec_p = dep[dep.protein==NEC].iloc[0]
z_p = norm.ppf(1 - max(float(nec_p.pvalue),1e-30)/2)
se  = np.sqrt(1/110 + 1/110); g_p = np.sign(float(nec_p.log2FC))*z_p*se
forest.append(("CPTAC  (TMT-10 protein)",     (g_p, g_p-1.96*se, g_p+1.96*se), 110, 110))
fdf = pd.DataFrame([(s,*g,nt,nn) for s,g,nt,nn in forest],
                   columns=["src","g","lo","hi","nT","nN"])
yp = np.arange(len(fdf))[::-1]
for i,(_, r) in enumerate(fdf.iterrows()):
    y = yp[i]
    if "CPTAC" in r.src: col = C["sage"]
    elif "Caris" in r.src or "ESMO" in r.src: col = C["gold"]
    elif "ADC-only" in r.src: col = C["star"]
    elif "TCGA" in r.src: col = C["tumor"]
    else: col = C["plum"]
    axc.plot([r.lo, r.hi], [y, y], color=col, lw=1.8, solid_capstyle="round")
    axc.scatter(r.g, y, s=65, marker="s", color=col,
                edgecolor="white", lw=0.8, zorder=4)
    n_lbl = f"n = {int(r.nT)} / {int(r.nN)}" if r.nN > 0 else f"N = {int(r.nT)}"
    axc.text(r.hi+0.07, y, f"g = {r.g:+.2f}   {n_lbl}",
             va="center", fontsize=8.5, color="black")
axc.set_yticks(yp); axc.set_yticklabels(fdf.src, fontsize=8.5, color="black")
axc.axvline(0, color="black", lw=0.6, ls=(0,(3,2)))
axc.set_xlabel("Hedges' $g$   (Tumour − Normal)", fontsize=11)
axc.set_xlim(left=fdf.lo.min()-0.1, right=fdf.hi.max()*1.8)
# Clinical-precedent footnote — placed in the bottom-right empty zone
# of the forest (no bars extend there because g-magnitudes are <= ~2.1
# while xlim was bumped to fdf.hi.max()*1.8 ≈ 3.6 to fit row annotations).
axc.text(0.97, 0.04,
         "Brägelmann ESMO 2025\n"
         "IHC ↔ copy-number  ρ = 0.67  (P = 7×10⁻⁸³)\n"
         "Zelenectide pevedotin → 40 % RR in NECTIN4-amp\n"
         "NSCLC  (Duravelo-1, NCT04561362)",
         transform=axc.transAxes, ha="right", va="bottom",
         fontsize=7.0, color=C["ink"], fontstyle="italic", linespacing=1.25,
         bbox=dict(fc="white", ec=C["mist"], lw=0.4, pad=2.5))

# [DEMOTED to supplementary: KNUH histological subtype (Kruskal P=0.044,
#  marginal; subtype is not core to the sensor story).]
SUBTYPE_COL = {"A/P":C["normal"],"A/P + Solid":C["tumor"],"MP":C["plum"],"Solid":C["star"]}

# ── c) Tissue-origin enrichment (was e) ──────────────────────
axe = fig.add_subplot(outer[1, 0:3]); clean_axes(axe)
ORIGIN_ORDER = ["nLung","tLung","tL/B","nLN","mLN","PE","mBrain"]
ORIGIN_LBL = {"nLung":"normal\nlung","tLung":"tumour\nlung","tL/B":"tumour\nbronchus",
              "nLN":"normal\nLN","mLN":"meta.\nLN","PE":"pleural\neffusion","mBrain":"meta.\nbrain"}
rows_e = []
for o in ORIGIN_ORDER:
    m = (org_arr==o) & epi_mask
    if m.sum()>=30:
        rows_e.append((o, 100.0*(nec_arr[m]>0).mean(), int(m.sum())))
mdf = pd.DataFrame(rows_e, columns=["o","pct","n"])
cols_e = [C["normal"] if o.startswith("n") else (C["tumor"] if o.startswith("t") else C["star"])
          for o in mdf.o]
xp = np.arange(len(mdf))
axe.bar(xp, mdf.pct, color=cols_e, edgecolor="white", lw=0.5, width=0.74)
ymax_e = max(mdf.pct.max(), 1)
for i, (_, r) in enumerate(mdf.iterrows()):
    axe.text(i, r["pct"]+ymax_e*0.025, f"{r['pct']:.1f}%", ha="center",
             fontsize=10, fontweight="bold", color="black")
    axe.text(i, -ymax_e*0.08, f"n = {r['n']:,}", ha="center", va="top",
             fontsize=9, color="black")
axe.set_xticks(xp); axe.set_xticklabels([ORIGIN_LBL.get(o,o) for o in mdf.o], fontsize=10)
axe.set_ylabel(r"% epithelial cells NECTIN4$^+$", fontsize=11)
axe.set_ylim(-ymax_e*0.14, ymax_e*1.20)

# ── d) KNUH 18-donor per-patient reproducibility (was f) ──────
axf = fig.add_subplot(outer[1, 3:6]); clean_axes(axf)
ks = knuh.sort_values("pct_pos", ascending=False).reset_index(drop=True)
xp_f = np.arange(len(ks))
cols_f = [SUBTYPE_COL.get(s, C["grey"]) for s in ks.subtype]
axf.bar(xp_f, ks.pct_pos, color=cols_f, edgecolor="white", lw=0.5, width=0.8)
for x_, p_ in zip(xp_f, ks.pct_pos):
    axf.text(x_, p_+1.5, f"{p_:.0f}%", ha="center", fontsize=8.5,
             color="black", fontweight="bold")
axf.set_xticks(xp_f)
axf.set_xticklabels(ks.donor, fontsize=9, rotation=55, ha="right", color="black")
axf.set_ylabel(r"% NECTIN4$^+$ epithelial cells", fontsize=11)
axf.set_ylim(0, ks.pct_pos.max()*1.20)
axf.axhline(ks.pct_pos.mean(), color="black", lw=0.7, ls=(0,(3,2)), alpha=0.6)
handles_f = [Line2D([0],[0],marker="s",ls="none",markerfacecolor=col,
                     markeredgecolor=col, ms=8, label=k)
              for k,col in SUBTYPE_COL.items()]
leg_f = axf.legend(handles=handles_f, loc="upper right", frameon=True,
                   fontsize=9, title="Subtype", title_fontsize=9,
                   handletextpad=0.4, ncol=2, fancybox=False, edgecolor="black")
leg_f.get_frame().set_linewidth(0.5)

# ── Panel labels (fig-coord, anchored, never overlap) ────────
fig.canvas.draw()
for ax_obj, letter in [(axa,"a"),(axc,"b"),(axe,"c"),(axf,"d")]:
    panel_label(fig, ax_obj, letter, dx=-0.038, dy=0.012, fontsize=14)

plt.rcParams["savefig.bbox"] = "standard"
for ext in ("pdf","png"):
    fig.savefig(F/f"Figure2.{ext}", facecolor="white", dpi=350)
plt.close(fig)
print(f"\n[✓] Figure2.pdf  (+ .png)")
