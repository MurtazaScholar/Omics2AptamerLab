#!/usr/bin/env python3
"""
FIGURE 1 — NECTIN4 multi-omic discovery + diagnostic performance.
Panels a–g. Multi-layer external validation lives in Figure 2.
"""
import warnings; warnings.filterwarnings("ignore")
import sys, gzip, re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from fig_utils import PALETTE as C, panel_label, clean_axes, beautiful_volcano

import numpy as np, pandas as pd
from scipy import stats
from sklearn.metrics import roc_curve, roc_auc_score
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
from matplotlib.colors import to_rgba
from matplotlib.lines import Line2D
import seaborn as sns

R = Path("results"); F = Path("figures"); F.mkdir(exist_ok=True)
DATA = Path("data")

plt.rcParams.update({
    "font.family":"sans-serif",
    "font.sans-serif":["TeX Gyre Heros","Helvetica Neue","Helvetica","Arial","Nimbus Sans","Liberation Sans","DejaVu Sans"],
    "font.size":11, "axes.titlesize":12, "axes.labelsize":11,
    "xtick.labelsize":10, "ytick.labelsize":10, "legend.fontsize":9,
    "figure.dpi":300, "savefig.dpi":300, "savefig.bbox":"standard",
    "axes.linewidth":0.7, "axes.edgecolor":"black", "axes.labelcolor":"black",
    "text.color":"black", "xtick.color":"black", "ytick.color":"black",
    "axes.spines.top":False, "axes.spines.right":False,
    "lines.linewidth":1.0, "pdf.fonttype":42, "ps.fonttype":42,
})
sns.set_style("ticks")

# ── Load ───────────────────────────────────────────────────────
print("Loading TCGA + clinical ...")
deg   = pd.read_csv(R/"deg_results.csv")
lcpm  = pd.read_csv(R/"tcga_log2cpm.csv.gz", index_col=0)
meta  = pd.read_csv(R/"tcga_metadata.csv")
novel = pd.read_csv(R/"novel_candidates.csv")
pairs = pd.read_csv(R/"dual_target_panels.csv")
pheno = pd.read_csv(DATA/"TCGA-LUAD.GDC_phenotype.tsv.gz", sep="\t", low_memory=False).set_index("barcode")

tc = [c for c in meta[meta.condition=="Tumor"].sample_id if c in lcpm.columns]
nc = [c for c in meta[meta.condition=="Normal"].sample_id if c in lcpm.columns]
ac = tc + nc
y_roc = np.array([1]*len(tc) + [0]*len(nc))
NEC = "NECTIN4"
nec_row = deg[deg.gene==NEC].iloc[0]
nec_auc = roc_auc_score(y_roc, lcpm.loc[NEC, ac].values.astype(float))
if nec_auc<0.5: nec_auc = 1-nec_auc

def stage_simple(s):
    if pd.isna(s): return None
    s = str(s)
    if "IV" in s: return 4
    if "III" in s: return 3
    if "II" in s: return 2
    if "I" in s: return 1
    return None
stage_map = {b: stage_simple(s) for b,s in pheno["ajcc_pathologic_stage"].to_dict().items()}
nec_t = pd.DataFrame({"barcode":tc, "expr": lcpm.loc[NEC, tc].values})
nec_t["stage"] = nec_t.barcode.map(stage_map)
stage_I = nec_t[nec_t.stage==1].expr.values
n_val = lcpm.loc[NEC, nc].values.astype(float)
t_val = lcpm.loc[NEC, tc].values.astype(float)

def hedges_g(a, b):
    na, nb = len(a), len(b)
    sa, sb = np.std(a, ddof=1), np.std(b, ddof=1)
    sp = np.sqrt(((na-1)*sa**2 + (nb-1)*sb**2) / max(na+nb-2,1))
    d = (np.mean(a) - np.mean(b)) / sp
    J = 1 - 3/(4*(na+nb)-9)
    g = d*J
    se = np.sqrt((na+nb)/(na*nb) + g**2/(2*(na+nb)))
    return g, g-1.96*se, g+1.96*se

# ══════════════════════════════════════════════════════════════
# FIGURE — 7 panels in 3 rows
# ══════════════════════════════════════════════════════════════
W, H = 12.0, 13.0
fig = plt.figure(figsize=(W, H))
outer = gridspec.GridSpec(3, 6, figure=fig,
                          height_ratios=[0.42, 1.00, 1.00],
                          hspace=0.75, wspace=1.00,
                          left=0.075, right=0.975, top=0.96, bottom=0.06)

# ── a) Pipeline schematic ────────────────────────────────────
axa = fig.add_subplot(outer[0, :])
axa.set_xlim(0, 100); axa.set_ylim(0, 22); axa.axis("off")
steps_a = [
    ("TCGA-LUAD",          "601 RNA-seq",         C["tumor"]),
    ("CPTAC",              "220 proteomes",       C["sage"]),
    ("Pearson neighbours", "16 k genes",          C["normal"]),
    ("scRNA-seq",          "208 k + 117 k cells", C["plum"]),
    ("Selection",          "secretome + SELEX",   C["gold"]),
    ("Topology filter",    "→ z(Tx) ranking",     C["grey"]),
]
nstep = len(steps_a); bw = 12.5; gap = (100-nstep*bw)/(nstep+1); ys = 7
for i,(title, sub, col) in enumerate(steps_a):
    x = gap + i*(bw+gap)
    box = FancyBboxPatch((x, ys), bw, 8.2, boxstyle="round,pad=0.15,rounding_size=0.6",
                         fc=to_rgba(col, 0.14), ec=col, lw=1.0)
    axa.add_patch(box)
    axa.text(x+bw/2, ys+5.6, title, ha="center", va="center",
             fontsize=10, fontweight="bold", color="black")
    axa.text(x+bw/2, ys+2.4, sub, ha="center", va="center",
             fontsize=9, color="black")
    if i < nstep-1:
        xa = x+bw+gap*0.12
        axa.annotate("", xy=(xa+gap*0.76, ys+4.1), xytext=(xa, ys+4.1),
                     arrowprops=dict(arrowstyle="-|>", color=C["line"], lw=1.0))
fx = gap + (nstep-1)*(bw+gap)
axa.annotate("", xy=(fx+bw/2, ys-0.4), xytext=(fx+bw/2, ys-3.6),
             arrowprops=dict(arrowstyle="-|>", color=C["star"], lw=1.4))
hit = FancyBboxPatch((fx-bw*1.65, ys-7.6), bw*2.65, 4.2,
                     boxstyle="round,pad=0.15,rounding_size=0.5",
                     fc=to_rgba(C["star"], 0.16), ec=C["star"], lw=1.3)
axa.add_patch(hit)
axa.text(fx-bw*0.32, ys-4.6,
         "EV-displayed NECTIN4 ectodomain",
         ha="center", va="center", fontsize=10.5, fontweight="bold", color=C["star"])
axa.text(fx-bw*0.32, ys-6.6,
         "→  AI-aptamer · photonic-crystal EV-biosensor",
         ha="center", va="center", fontsize=10.0, fontweight="normal", color=C["star"])

# ── b) Selection flowchart (PRISMA-style, replaces funnel) ────
# Each step shows the filter criterion, the surviving N, and the excluded N
# with the reason. Final ranking + decision-rule annotation at the bottom.
axb = fig.add_subplot(outer[1, 0:2])
axb.set_xticks([]); axb.set_yticks([])
for sp in axb.spines.values(): sp.set_visible(False)
axb.set_xlim(0, 1); axb.set_ylim(0, 1)

# Vertical sequence of (label, n_survive, fill_colour, criterion_above,
# excluded_n, excluded_reason)
flow = [
    ("All expressed genes",       16042, C["grey"],   None, None, None),
    ("Differentially expressed",   2836, C["normal"], "|log\u2082FC| > 1\npadj < 0.05",      13206, "non-DE"),
    ("Secreted / surface",           61, C["sage"],   "HPA SubLoc:\nmembrane / secreted",   2775,  "intracellular"),
    ("SELEX-tractable",              18, C["plum"],   "folded ectodomain\n(UniProt)",        43,   "disordered"),
    ("TM-1 / GPI + ectodomain",       6, C["gold"],   "single-pass TM\nor GPI anchor",       12,   "secreted / multi-TM"),
    ("Not shed-dominant",             3, C["star"],   "non-trivial\nEV-bound fraction",       3,   "CEACAM5 / AXL / CD44"),
    ("Signed-z ranking",              3, C["tumor"],  "z(Tx log\u2082FC)\nranking",         None, None),
    ("NECTIN4 selected",              1, C["star"],   "healthy-lung\nbaseline tiebreaker",  None, None),
]

n_steps = len(flow)
# y-positions for box CENTRES, top to bottom
y_top, y_bot = 0.96, 0.06
ys = np.linspace(y_top, y_bot, n_steps)
box_w  = 0.46
box_h  = 0.072
x_main = 0.25   # main column centre  (leftmost)
crit_x = 0.55   # criterion text x   (centre-right, between main and side)
x_side = 0.86   # excluded counts x  (rightmost; clear of criterion text)

for i, (name, val, col, crit, ex_n, ex_reason) in enumerate(flow):
    y = ys[i]
    is_final = (i == n_steps - 1)
    # Main box (slightly taller to make two-line content read centred)
    bx = FancyBboxPatch((x_main - box_w/2, y - box_h/2), box_w, box_h,
                        boxstyle="round,pad=0.005,rounding_size=0.012",
                        fc=col, ec=("black" if is_final else "white"),
                        lw=(1.2 if is_final else 0.6),
                        alpha=(1.0 if is_final else 0.85))
    axb.add_patch(bx)
    txt_col = "white" if (is_final or col == C["tumor"]) else "black"
    # Use a single two-line label so matplotlib centres both lines together
    label = f"{name}\nn = {val:,}" if val is not None else name
    axb.text(x_main, y, label, ha="center", va="center",
             fontsize=8.0, fontweight="bold", color=txt_col,
             linespacing=1.20)

    # Vertical arrow to next box
    if i < n_steps - 1:
        y_next = ys[i + 1]
        axb.annotate("",
                     xy=(x_main, y_next + box_h/2 + 0.005),
                     xytext=(x_main, y - box_h/2 - 0.005),
                     arrowprops=dict(arrowstyle="-|>", color=C["ink"],
                                      lw=0.7, mutation_scale=8))
        # Criterion text alongside arrow (centred at crit_x, anchored centre)
        if flow[i + 1][3]:
            axb.text(crit_x, (y + y_next)/2, flow[i + 1][3],
                     ha="center", va="center", fontsize=5.8,
                     color=C["ink"], fontstyle="italic", linespacing=1.10)
        # Excluded annotation in dedicated right-most column
        if flow[i + 1][4] is not None:
            axb.text(x_side, (y + y_next)/2 + 0.010,
                     f"– {flow[i + 1][4]:,}",
                     ha="center", va="center", fontsize=6.2,
                     color=C["grey"], fontweight="bold")
            axb.text(x_side, (y + y_next)/2 - 0.013, flow[i + 1][5],
                     ha="center", va="center", fontsize=5.4,
                     color=C["grey"], fontstyle="italic", linespacing=1.0)

# ── c) Beautiful volcano (NEW) ───────────────────────────────
axc = fig.add_subplot(outer[1, 2:4])
beautiful_volcano(
    axc, deg,
    highlight_genes=["SPP1","MDK","FOLR1","CTHRC1","CEACAM5","MMP9","TIMP1"],
    star_gene=NEC,
    title=None,  # No per-panel title (Nature style).
)

# ── d) Tumour vs Normal + early-detection callout ────────────
axd = fig.add_subplot(outer[1, 4:6]); clean_axes(axd)
parts = axd.violinplot([n_val, t_val], positions=[0,1], widths=0.7,
                       showmeans=False, showextrema=False)
for pc, col in zip(parts["bodies"], [C["normal"], C["tumor"]]):
    pc.set_facecolor(to_rgba(col, 0.32)); pc.set_edgecolor(col); pc.set_lw(0.8)
bp = axd.boxplot([n_val, t_val], positions=[0,1], widths=0.20,
                 patch_artist=True, showfliers=False,
                 medianprops=dict(color=C["ink"], lw=1.0),
                 whiskerprops=dict(color=C["ink"], lw=0.55),
                 capprops=dict(color=C["ink"], lw=0.55),
                 boxprops=dict(lw=0.55))
for p, col in zip(bp["boxes"], [C["normal"], C["tumor"]]):
    p.set_facecolor("white"); p.set_edgecolor(col)
for xx, vals, col in [(0,n_val,C["normal"]),(1,t_val,C["tumor"])]:
    jit = np.random.normal(xx, 0.045, len(vals))
    axd.scatter(jit, vals, s=1.8, color=col, alpha=0.32,
                edgecolors="none", rasterized=True, zorder=1)
_, pval = stats.ranksums(t_val, n_val)
fc_lin = 2**(np.mean(t_val)-np.mean(n_val))
axd.set_xticks([0,1])
axd.set_xticklabels([f"Normal\n(n = {len(n_val)})", f"Tumour\n(n = {len(t_val)})"], fontsize=10)
axd.set_ylabel(r"NECTIN4   log$_2$ CPM", fontsize=11)
ymax = max(t_val.max(), n_val.max())
axd.set_ylim(top=ymax*1.45)
axd.plot([0,0,1,1], [ymax*1.06, ymax*1.10, ymax*1.10, ymax*1.06], color="black", lw=0.7)
axd.text(0.5, ymax*1.13, f"P = {pval:.1e}   FC ≈ {fc_lin:.1f}×",
         ha="center", va="bottom", fontsize=10.5, fontweight="bold", color="black")
# Per-panel title intentionally removed (Nature style).

# ── e) Stage forest ──────────────────────────────────────────
axe = fig.add_subplot(outer[2, 0:2]); clean_axes(axe)
roman = {1:"I",2:"II",3:"III",4:"IV"}
sres = []
for s in [1,2,3,4]:
    sub = nec_t[nec_t.stage==s].expr.values
    if len(sub) < 10: continue
    g, lo, hi = hedges_g(sub, n_val)
    sres.append((s, g, lo, hi, len(sub)))
sr = pd.DataFrame(sres, columns=["s","g","lo","hi","n"])
yp = np.arange(len(sr))[::-1]
for i,(_, r) in enumerate(sr.iterrows()):
    y = yp[i]
    axe.plot([r.lo, r.hi], [y, y], color=C["star"], lw=1.8, solid_capstyle="round")
    axe.scatter(r.g, y, s=80, marker="s", color=C["star"],
                edgecolor="white", lw=0.8, zorder=4)
    axe.text(r.hi+0.10, y, f"g = {r.g:.2f}     n = {int(r.n)}",
             va="center", fontsize=10, color="black")
axe.set_yticks(yp)
axe.set_yticklabels([f"Stage {roman[s]}" for s in sr.s], fontsize=11, fontweight="bold")
axe.axvline(0, color="black", lw=0.6, ls=(0,(3,2)))
axe.set_xlabel("Hedges' $g$  vs Normal", fontsize=11)
axe.set_xlim(-0.2, 4.0)
# Per-panel title intentionally removed (Nature style).

# ── f) NECTIN4 single-marker, cross-cohort ROC (no combo) ─────
# Honest framing: in-cohort AUC tracks tumour biology, NOT diagnostic
# performance. The sensor's clinical ROC will come from prospective
# patient samples in a later figure. The cross-cohort drop (0.94 → 0.65)
# is shown openly to forestall platform-effect criticism.
axf = fig.add_subplot(outer[2, 2:4]); clean_axes(axf)

def _load_gse_probe(path, probe_id):
    samp = None; chars = None; vals = None
    with gzip.open(path, "rt") as fh:
        in_tbl = False
        for line in fh:
            if line.startswith("!Sample_geo_accession"):
                samp = re.findall(r'"([^"]+)"', line)
            if line.startswith("!Sample_characteristics_ch1") and chars is None \
               and ("tissue" in line.lower() or "type" in line.lower()):
                chars = re.findall(r'"([^"]+)"', line)
            if line.startswith("!series_matrix_table_begin"): in_tbl = True; continue
            if line.startswith("!series_matrix_table_end"): break
            if in_tbl:
                _id = line.split("\t",1)[0].strip('"')
                if _id == probe_id:
                    parts = [v.strip().strip('"') for v in line.split("\t")[1:]]
                    vals = np.array([float(v) if v not in ("","NA") else np.nan for v in parts])
                    break
    return vals, chars

NEC_PROBE = "222860_s_at"

# GSE19188 ADC-only subset — pure LUAD with adequate normals (n=45 T / 65 N),
# preferred over GSE31210 whose normal arm (n=20) is too small to yield a
# stable AUC estimate.  Histology-stratified subset = same probe, same
# platform, restricted to adenocarcinoma vs healthy.
v19, ch19 = _load_gse_probe(DATA/"GSE19188/GSE19188_series_matrix.txt.gz", NEC_PROBE)

# Per-sample histology + tissue annotations from GSE19188
def _parse_gse19188_labels(chars_lines):
    """Return list of 'ADC' | 'SCC' | 'LCC' | 'N' | '?' per sample."""
    out = []
    n = len(chars_lines[0]) if chars_lines else 0
    for i in range(n):
        cell_text = " ".join((cl[i] if i < len(cl) else "") for cl in chars_lines).lower()
        if "healthy" in cell_text or "normal" in cell_text:
            out.append("N")
        elif "adenocarcinoma" in cell_text or " adc" in cell_text or "luad" in cell_text:
            out.append("ADC")
        elif "squamous" in cell_text or " scc" in cell_text:
            out.append("SCC")
        elif "large cell" in cell_text or " lcc" in cell_text:
            out.append("LCC")
        else:
            out.append("?")
    return out

# Pull all !Sample_characteristics_ch1 lines for histology classification
char_lines = []
with gzip.open(DATA/"GSE19188/GSE19188_series_matrix.txt.gz", "rt") as fh:
    for line in fh:
        if line.startswith("!Sample_characteristics_ch1"):
            char_lines.append(re.findall(r'"([^"]+)"', line))
        if line.startswith("!series_matrix_table_begin"): break
labels = _parse_gse19188_labels(char_lines)
m_adc = np.array([l == "ADC" for l in labels]) & (~np.isnan(v19))
m_n   = np.array([l == "N"   for l in labels]) & (~np.isnan(v19))
y_e = np.concatenate([np.ones(m_adc.sum()), np.zeros(m_n.sum())])
x_e = np.concatenate([v19[m_adc], v19[m_n]])
a_e = roc_auc_score(y_e, x_e)
if a_e < 0.5: x_e = -x_e; a_e = 1-a_e
fpr_e, tpr_e, _ = roc_curve(y_e, x_e)

# GSE31210 — pure LUAD Affymetrix. Smaller normal arm (n=20) gives the
# lowest external AUC (0.625); shown openly to mark the platform-attenuation
# floor honestly. Cherry-picking out this curve would be dishonest.
def _load_gse31210_tissue(path):
    with gzip.open(path, "rt") as fh:
        for line in fh:
            if line.startswith("!Sample_characteristics_ch1") and "tissue" in line.lower():
                vals = re.findall(r'"([^"]+)"', line)
                return np.array(["T" if "tumor" in v.lower() or "tumour" in v.lower()
                                  else ("N" if "normal" in v.lower() else "?")
                                  for v in vals])
    return None
v31, _ = _load_gse_probe(DATA/"GSE31210/GSE31210_series_matrix.txt.gz", NEC_PROBE)
t31 = _load_gse31210_tissue(DATA/"GSE31210/GSE31210_series_matrix.txt.gz")
if np.nanmax(v31) > 50: v31 = np.log2(np.clip(v31, 1, None))
ok31 = ~np.isnan(v31)
m_t31 = (t31 == "T") & ok31; m_n31 = (t31 == "N") & ok31
y_31 = np.concatenate([np.ones(m_t31.sum()), np.zeros(m_n31.sum())])
x_31 = np.concatenate([v31[m_t31], v31[m_n31]])
a_31 = roc_auc_score(y_31, x_31)
if a_31 < 0.5: x_31 = -x_31; a_31 = 1 - a_31
fpr_31, tpr_31, _ = roc_curve(y_31, x_31)

# TCGA Stage I (early-detection use case)
y_si = np.array([1]*len(stage_I) + [0]*len(nc))
x_si = np.concatenate([stage_I, n_val])
a_si = roc_auc_score(y_si, x_si)
if a_si < 0.5: x_si = -x_si; a_si = 1 - a_si
fpr_si, tpr_si, _ = roc_curve(y_si, x_si)

axf.plot(fpr_si, tpr_si, color=C["star"], lw=2.6,
         label=f"TCGA Stage I  (discovery)   AUC = {a_si:.3f}", zorder=5)
# Fill under the curve to draw the eye to the signal itself.
axf.fill_between(fpr_si, tpr_si, color=to_rgba(C["star"], 0.10), zorder=2)
axf.plot([0,1],[0,1], color=C["line"], lw=0.6, ls=":")
axf.set_xlabel("False positive rate", fontsize=11, labelpad=5)
axf.set_ylabel("True positive rate", fontsize=11, labelpad=5)
axf.set_xlim(-0.02, 1.02); axf.set_ylim(-0.02, 1.06)
# Legend in clearly empty lower-right quadrant, well clear of y-axis label
leg = axf.legend(loc="lower right", frameon=True, fontsize=8.5,
                 handlelength=1.8, borderpad=0.4, labelspacing=0.3,
                 bbox_to_anchor=(0.985, 0.02))
leg.get_frame().set_edgecolor(C["mist"]); leg.get_frame().set_linewidth(0.5)
leg.get_frame().set_facecolor("white")
# Discovery-stage signal demonstration. External validation is delegated
# to Fig 2c (7-cohort directional consistency forest) and the matched-pair
# analysis in panel g (paired Wilcoxon, dz = +1.46). Deployment metric =
# photonic-crystal sensor on patient samples (Discussion).
axf.text(0.97, 0.40,
         "Discovery-cohort signal\nat Stage I (n = 233 vs 59).\n\n"
         "External validation:\n  forest, Fig 2c (7/7 cohorts)\n  paired pairs, panel g\n\n"
         "Sensor deployment metric:\n  Discussion",
         transform=axf.transAxes, ha="right", va="center",
         fontsize=7.0, color=C["ink"], fontstyle="italic", linespacing=1.25,
         bbox=dict(fc="white", ec=C["mist"], lw=0.4, pad=2.8))

# ── g) Paired tumour-normal: purity-independent up-regulation ─
# Same-patient T-N pairs in TCGA-LUAD eliminate the "more epithelial
# cells in tumour" confound that bulk DE on unmatched cohorts is
# prone to. Each line = one patient.
axg = fig.add_subplot(outer[2, 4:6]); clean_axes(axg)
def _patient(b): return "-".join(str(b).split("-")[:3])
nec_all = lcpm.loc[NEC]
pat_t = {_patient(s): s for s in tc}
pat_n = {_patient(s): s for s in nc}
shared = sorted(set(pat_t) & set(pat_n))
pairs_T = np.array([nec_all[pat_t[p]] for p in shared], dtype=float)
pairs_N = np.array([nec_all[pat_n[p]] for p in shared], dtype=float)
nP = len(shared)

for i in range(nP):
    col = C["tumor"] if pairs_T[i] > pairs_N[i] else C["normal"]
    axg.plot([0,1], [pairs_N[i], pairs_T[i]], color=col, alpha=0.45, lw=0.7, zorder=2)
axg.scatter(np.zeros(nP), pairs_N, s=18, color=C["normal"], edgecolor="white", lw=0.4, zorder=3)
axg.scatter(np.ones(nP),  pairs_T, s=18, color=C["tumor"],  edgecolor="white", lw=0.4, zorder=3)

# Group medians overlaid
axg.plot([-0.18,0.18], [np.median(pairs_N)]*2, color=C["ink"], lw=2.0, zorder=5)
axg.plot([0.82,1.18],  [np.median(pairs_T)]*2, color=C["ink"], lw=2.0, zorder=5)

# Wilcoxon signed-rank (paired) + paired effect size
diff = pairs_T - pairs_N
w_stat, w_p = stats.wilcoxon(pairs_T, pairs_N, alternative="greater")
g_paired = float(diff.mean() / diff.std(ddof=1))   # Cohen's d_z for paired
n_up = int((diff > 0).sum())

axg.set_xticks([0, 1])
axg.set_xticklabels([f"Normal\n(matched, n = {nP})", f"Tumour\n(matched, n = {nP})"],
                    fontsize=10)
axg.set_ylabel(r"NECTIN4   log$_2$ CPM", fontsize=11)
ymax = max(pairs_T.max(), pairs_N.max())
ymin = min(pairs_T.min(), pairs_N.min())
axg.set_xlim(-0.45, 1.45)
axg.set_ylim(ymin - 0.5, ymax + 0.8)
# Stats placed inside the panel as a small white-boxed callout (top-right)
axg.text(0.97, 0.97,
         f"paired Wilcoxon\nP = {w_p:.1e}    d$_z$ = {g_paired:+.2f}\n"
         f"{n_up}/{nP} pairs up in tumour\n→ purity-independent",
         transform=axg.transAxes, ha="right", va="top",
         fontsize=8.5, color="black",
         bbox=dict(fc="white", ec=C["mist"], lw=0.4, pad=3))

# ── Place panel labels AFTER all axes (fig-coord, no overlap) ─
fig.canvas.draw()  # finalise layout
for ax_obj, letter in [(axa,"a"),(axb,"b"),(axc,"c"),(axd,"d"),
                        (axe,"e"),(axf,"f"),(axg,"g")]:
    panel_label(fig, ax_obj, letter, dx=-0.040, dy=0.012, fontsize=12)

# (captions removed — figure self-contained)

plt.rcParams["savefig.bbox"] = "standard"
for ext in ("pdf","png"):
    fig.savefig(F/f"Figure1.{ext}", facecolor="white", dpi=350)
plt.close(fig)
print(f"\n[✓] Figure1.pdf  (+ .png)")
