#!/usr/bin/env python3
"""
Audit every defensible AUC option for NECTIN4 discrimination.
Reports honest numbers so the manuscript can choose its headline.
"""
import warnings; warnings.filterwarnings("ignore")
import gzip, re
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

R = Path("results"); DATA = Path("data")

# ── TCGA ──
lcpm = pd.read_csv(R/"tcga_log2cpm.csv.gz", index_col=0)
meta = pd.read_csv(R/"tcga_metadata.csv")
pheno = pd.read_csv(DATA/"TCGA-LUAD.GDC_phenotype.tsv.gz", sep="\t", low_memory=False).set_index("barcode")

tc = [c for c in meta[meta.condition=="Tumor"].sample_id if c in lcpm.columns]
nc = [c for c in meta[meta.condition=="Normal"].sample_id if c in lcpm.columns]
NEC = "NECTIN4"

def stage_simple(s):
    if pd.isna(s): return None
    s = str(s)
    if "IV"  in s: return 4
    if "III" in s: return 3
    if "II"  in s: return 2
    if "I"   in s: return 1

stage_map = {b: stage_simple(s) for b,s in pheno["ajcc_pathologic_stage"].to_dict().items()}
stageI_t = [b for b in tc if stage_map.get(b) == 1]
print(f"TCGA Stage I tumours: {len(stageI_t)},  TCGA normals: {len(nc)}")

audit = []

def auc_of(a, b):
    y = np.array([1]*len(a) + [0]*len(b))
    x = np.concatenate([a, b])
    v = roc_auc_score(y, x)
    return v if v >= 0.5 else 1-v

# 1) TCGA in-cohort, all stages (resubstitution)
t_all = lcpm.loc[NEC, tc].values.astype(float)
n_all = lcpm.loc[NEC, nc].values.astype(float)
a1 = auc_of(t_all, n_all)
audit.append(("TCGA in-cohort (all stages, resubstitution)",
              len(t_all), len(n_all), a1))

# 2) TCGA 5-fold CV (within-cohort, properly held-out)
y_roc = np.array([1]*len(tc) + [0]*len(nc))
x_roc = np.concatenate([t_all, n_all]).reshape(-1, 1)
skf = StratifiedKFold(5, shuffle=True, random_state=42)
cv_aucs = []
for tr, te in skf.split(x_roc, y_roc):
    # Single-feature: rank by raw value, no model fitting required
    a = roc_auc_score(y_roc[te], x_roc[te, 0])
    cv_aucs.append(a if a >= 0.5 else 1-a)
audit.append(("TCGA 5-fold CV (single-feature, held-out)",
              len(tc), len(nc), float(np.mean(cv_aucs))))

# 3) TCGA Stage-I only (early-detection use case)
t_s1 = lcpm.loc[NEC, stageI_t].values.astype(float)
a3 = auc_of(t_s1, n_all)
audit.append(("TCGA Stage I tumours vs Normal",
              len(t_s1), len(n_all), a3))

# 4) GSE19188 ADC-only
NEC_PROBE = "222860_s_at"
def load_probe(path, probe_id=NEC_PROBE):
    vals = None
    with gzip.open(path, "rt") as fh:
        in_tbl = False
        for line in fh:
            if line.startswith("!series_matrix_table_begin"): in_tbl = True; continue
            if line.startswith("!series_matrix_table_end"): break
            if in_tbl:
                _id = line.split("\t",1)[0].strip('"')
                if _id == probe_id:
                    parts = [v.strip().strip('"') for v in line.split("\t")[1:]]
                    vals = np.array([float(v) if v not in ("","NA","null") else np.nan
                                      for v in parts])
                    break
    return vals

def gse_labels(path, schema="default"):
    rows = []
    with gzip.open(path, "rt") as fh:
        for line in fh:
            if (line.startswith("!Sample_characteristics_ch1") or
                line.startswith("!Sample_source_name_ch1") or
                line.startswith("!Sample_title")):
                rows.append(re.findall(r'"([^"]+)"', line))
            if line.startswith("!series_matrix_table_begin"): break
    n = max(len(r) for r in rows)
    full = [" | ".join(r[i] for r in rows if i < len(r)).lower() for i in range(n)]
    out = []
    for s in full:
        if schema == "gse19188":
            if "healthy" in s or "normal" in s: out.append("N")
            elif "adenocarcinoma" in s or " adc" in s: out.append("T_ADC")
            elif "squamous" in s: out.append("T_SCC")
            elif "large cell" in s: out.append("T_LCC")
            else: out.append("?")
        else:
            if "tumor" in s or "tumour" in s or "adenocarcinoma" in s or "luad" in s:
                out.append("T")
            elif "normal" in s or "healthy" in s or "adjacent" in s or "non-tumor" in s:
                out.append("N")
            else: out.append("?")
    return out

v19 = load_probe(DATA/"GSE19188/GSE19188_series_matrix.txt.gz")
l19 = gse_labels(DATA/"GSE19188/GSE19188_series_matrix.txt.gz", "gse19188")
m_adc = np.array([l == "T_ADC" for l in l19]) & (~np.isnan(v19))
m_n   = np.array([l == "N"     for l in l19]) & (~np.isnan(v19))
audit.append(("GSE19188 LUAD subset", int(m_adc.sum()), int(m_n.sum()),
              auc_of(v19[m_adc], v19[m_n])))

# 4b) GSE19188 all NSCLC vs normal
m_t = np.array([l.startswith("T") for l in l19]) & (~np.isnan(v19))
audit.append(("GSE19188 all NSCLC", int(m_t.sum()), int(m_n.sum()),
              auc_of(v19[m_t], v19[m_n])))

# 5) GSE31210
v31 = load_probe(DATA/"GSE31210/GSE31210_series_matrix.txt.gz")
l31 = gse_labels(DATA/"GSE31210/GSE31210_series_matrix.txt.gz")
m_t = np.array([l == "T" for l in l31]) & (~np.isnan(v31))
m_n = np.array([l == "N" for l in l31]) & (~np.isnan(v31))
xv = v31.copy()
if np.nanmax(xv) > 50: xv = np.log2(np.clip(xv, 1, None))
audit.append(("GSE31210", int(m_t.sum()), int(m_n.sum()),
              auc_of(xv[m_t], xv[m_n])))

# 6) GSE40791
v40 = load_probe(DATA/"GSE40791/GSE40791_series_matrix.txt.gz")
l40 = gse_labels(DATA/"GSE40791/GSE40791_series_matrix.txt.gz")
m_t = np.array([l == "T" for l in l40]) & (~np.isnan(v40))
m_n = np.array([l == "N" for l in l40]) & (~np.isnan(v40))
audit.append(("GSE40791 (Zhang)", int(m_t.sum()), int(m_n.sum()),
              auc_of(v40[m_t], v40[m_n])))

# Sort + print
audit_df = pd.DataFrame(audit, columns=["cohort","n_T","n_N","AUC"])
print()
print(audit_df.sort_values("AUC", ascending=False).to_string(index=False))
audit_df.to_csv(R/"auc_options_audit.csv", index=False)
print(f"\n[\u2713] {R/'auc_options_audit.csv'}")
