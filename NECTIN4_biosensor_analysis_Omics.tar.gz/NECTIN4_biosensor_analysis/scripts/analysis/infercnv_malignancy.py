#!/usr/bin/env python3
"""
Use the Kim 2020 (GSE131907) author-provided inferCNV malignancy calls to
rebuild the analytical compartment for NECTIN4 + tetraspanin co-expression.

Kim et al. 2020 (Cell) ran inferCNV on every epithelial cluster against
normal alveolar / airway epithelial cells as the diploid reference and
encoded the result in Cell_subtype:

    Malignant cells          (mBrain / mLN / tL/B  — metastatic / pleural)
    tS1, tS2, tS3            (tLung primary tumour  — LUAD subtypes 1-3,
                              all CNV-confirmed malignant)
    AT1, AT2, Ciliated, Club (nLung — diploid reference)

So "CNV-confirmed malignant" = Cell_subtype ∈ {Malignant cells, tS1, tS2, tS3}.
This dump produces a single CSV that downstream figure scripts can join on.
"""
import anndata as ad
import numpy as np, pandas as pd
from pathlib import Path

R = Path("results")

print("Loading GSE131907 processed h5ad ...")
a = ad.read_h5ad("data/GSE131907/GSE131907_processed.h5ad")
print(f"  cells: {a.shape[0]:,}   genes: {a.shape[1]:,}")

# Author-provided inferCNV-derived malignancy calls
MALIGNANT_SUBTYPES = {"Malignant cells", "tS1", "tS2", "tS3"}
NORMAL_EPI_SUBTYPES = {"AT1", "AT2", "Ciliated", "Club"}

obs = a.obs.copy()
obs["malignant_cnv"] = obs.Cell_subtype.isin(MALIGNANT_SUBTYPES)
obs["normal_epi"]    = obs.Cell_subtype.isin(NORMAL_EPI_SUBTYPES)

# Pull EV-cargo gene expression (PVRL4 → NECTIN4)
GENES = ["PVRL4","CD9","CD63","CD81","CD82","TSG101","PDCD6IP","SDCBP",
         "RAB27A","RAB27B","HSPA8","ANXA1","ANXA2"]
g_in = [g for g in GENES if g in a.var.index]
print(f"  pulling {len(g_in)} EV genes: {g_in}")
X = a[:, g_in].X
if hasattr(X, "toarray"): X = X.toarray()
expr = pd.DataFrame(X, index=a.obs.index, columns=g_in)
expr = expr.rename(columns={"PVRL4":"NECTIN4"})

# Join with metadata
out = obs[["Sample","Sample_Origin","Cell_type","Cell_subtype",
           "malignant_cnv","normal_epi"]].join(expr)
out.to_csv(R/"sc_cnv_malignancy_with_evgenes.csv")

# Sanity printout
print()
print("CNV-confirmed malignant cells: {:,}".format(out.malignant_cnv.sum()))
print("Normal lung epithelial:        {:,}".format(out.normal_epi.sum()))
print()
print("NECTIN4+ rate by compartment:")
for grp, mask in [("CNV-confirmed malignant", out.malignant_cnv),
                  ("Normal lung epithelial",  out.normal_epi)]:
    sub = out[mask]
    pct = 100 * (sub.NECTIN4 > 0).mean()
    print(f"  {grp:30s}  n = {len(sub):>7,}   NECTIN4+ = {pct:5.1f}%")
print(f"\n[\u2713] {R/'sc_cnv_malignancy_with_evgenes.csv'}")
