#!/usr/bin/env python3
"""
Compute NECTIN4 Hedges' g in three additional LUAD T+N GEO cohorts:
  GSE10072  Landi 2008  — Affymetrix HG-U133A         (58 T / 49 N)
  GSE32863  Selamat 2012 — Illumina HumanWG-6          (paired T+N)
  GSE40791  Zhang        — Affymetrix HG-U133 Plus 2.0 (100 T / 100 N)

Outputs: results/extra_cohorts_nectin4_g.csv
"""
import warnings; warnings.filterwarnings("ignore")
import gzip, re
from pathlib import Path
import numpy as np, pandas as pd

R = Path("results"); R.mkdir(exist_ok=True)
DATA = Path("data")

# NECTIN4 probe IDs we know about (PVRL4 was the older symbol)
NECTIN4_PROBES = {
    "Affymetrix": ["222860_s_at", "1564315_at"],
    "Illumina":   ["ILMN_1786428", "ILMN_3239433"],
}

def load_probes(path, probe_ids):
    """Return {probe_id: values_array}, sample_geos, characteristics_list."""
    out, sample_geos, chars_list = {}, None, []
    with gzip.open(path, "rt") as fh:
        in_tbl = False
        for line in fh:
            if line.startswith("!Sample_geo_accession"):
                sample_geos = re.findall(r'"([^"]+)"', line)
            elif line.startswith("!Sample_characteristics_ch1"):
                chars_list.append(re.findall(r'"([^"]+)"', line))
            elif line.startswith("!Sample_source_name_ch1"):
                chars_list.append(re.findall(r'"([^"]+)"', line))
            elif line.startswith("!Sample_title"):
                chars_list.append(re.findall(r'"([^"]+)"', line))
            elif line.startswith("!series_matrix_table_begin"):
                in_tbl = True
                continue
            elif line.startswith("!series_matrix_table_end"):
                break
            elif in_tbl:
                _id = line.split("\t", 1)[0].strip('"')
                if _id in probe_ids:
                    parts = [v.strip().strip('"') for v in line.split("\t")[1:]]
                    out[_id] = np.array([
                        float(v) if v not in ("", "NA", "null") else np.nan
                        for v in parts
                    ])
    return out, sample_geos, chars_list

def hedges_g(a, b):
    a = np.asarray(a, float); a = a[~np.isnan(a)]
    b = np.asarray(b, float); b = b[~np.isnan(b)]
    na, nb = len(a), len(b)
    sa, sb = np.std(a, ddof=1), np.std(b, ddof=1)
    sp = np.sqrt(((na-1)*sa**2 + (nb-1)*sb**2) / max(na+nb-2, 1))
    d = (np.mean(a) - np.mean(b)) / sp
    J = 1 - 3/(4*(na+nb) - 9)
    g = d * J
    se = np.sqrt((na+nb)/(na*nb) + g**2/(2*(na+nb)))
    return g, g - 1.96*se, g + 1.96*se, na, nb

def classify_tissue(s):
    s = s.lower()
    if any(k in s for k in ["tumor", "tumour", "lung cancer", "adenocarc", "ad ca", "cancer"]):
        return "T"
    if any(k in s for k in ["normal", "healthy", "non-tumor", "non-tumour", "adjacent"]):
        return "N"
    return "?"

results = []

# ── GSE10072 (Landi 2008, HG-U133A) ──────────────────────────
print("\n── GSE10072 ──")
probes, samples, chars = load_probes(
    DATA/"GSE10072/GSE10072_series_matrix.txt.gz",
    NECTIN4_PROBES["Affymetrix"]
)
print(f"  samples: {len(samples)}; probes hit: {list(probes.keys())}")
# Tissue classification from title (source_name_ch1)
labels = []
for cl in chars:
    if cl and any("Adenocarcinoma" in c or "Normal" in c or "Tumor" in c for c in cl):
        labels = [classify_tissue(c) for c in cl]; break
if not labels:
    # Try Sample_title
    labels = [classify_tissue(" ".join([cl[i] for cl in chars if i < len(cl)]))
              for i in range(len(samples))]
print(f"  T={labels.count('T')}, N={labels.count('N')}, ?={labels.count('?')}")
if probes:
    pid = list(probes.keys())[0]
    vals = probes[pid]
    if np.nanmax(vals) > 50: vals = np.log2(np.clip(vals, 1, None))
    t_vals = vals[[i for i,l in enumerate(labels) if l=="T"]]
    n_vals = vals[[i for i,l in enumerate(labels) if l=="N"]]
    g, lo, hi, nt, nn = hedges_g(t_vals, n_vals)
    print(f"  Hedges' g = {g:+.3f} [{lo:+.3f}, {hi:+.3f}]  n_T={nt}, n_N={nn}")
    results.append(("GSE10072 (Affymetrix HG-U133A, Landi 2008)", g, lo, hi, nt, nn))

# ── GSE32863 (Selamat 2012, Illumina HumanWG-6) ──────────────
print("\n── GSE32863 ──")
probes, samples, chars = load_probes(
    DATA/"GSE32863/GSE32863_series_matrix.txt.gz",
    NECTIN4_PROBES["Illumina"]
)
print(f"  samples: {len(samples)}; probes hit: {list(probes.keys())}")
# Find tissue label
labels = []
for cl in chars:
    if cl and any(("tumor" in c.lower() or "non-tumor" in c.lower() or
                   "adjacent" in c.lower() or "adenocarc" in c.lower()) for c in cl):
        labels = [classify_tissue(c) for c in cl]; break
print(f"  T={labels.count('T')}, N={labels.count('N')}, ?={labels.count('?')}")
if probes:
    pid = list(probes.keys())[0]
    vals = probes[pid]
    if np.nanmax(vals) > 50: vals = np.log2(np.clip(vals, 1, None))
    t_vals = vals[[i for i,l in enumerate(labels) if l=="T"]]
    n_vals = vals[[i for i,l in enumerate(labels) if l=="N"]]
    g, lo, hi, nt, nn = hedges_g(t_vals, n_vals)
    print(f"  Hedges' g = {g:+.3f} [{lo:+.3f}, {hi:+.3f}]  n_T={nt}, n_N={nn}")
    results.append(("GSE32863 (Illumina HumanWG-6, Selamat 2012)", g, lo, hi, nt, nn))

# ── GSE40791 (Zhang, HG-U133 Plus 2.0) ───────────────────────
print("\n── GSE40791 ──")
probes, samples, chars = load_probes(
    DATA/"GSE40791/GSE40791_series_matrix.txt.gz",
    NECTIN4_PROBES["Affymetrix"]
)
print(f"  samples: {len(samples)}; probes hit: {list(probes.keys())}")
labels = []
for cl in chars:
    if cl and any(("tumor" in c.lower() or "adenocarc" in c.lower() or "normal" in c.lower())
                  for c in cl):
        labels = [classify_tissue(c) for c in cl]; break
print(f"  T={labels.count('T')}, N={labels.count('N')}, ?={labels.count('?')}")
if probes:
    pid = list(probes.keys())[0]
    vals = probes[pid]
    if np.nanmax(vals) > 50: vals = np.log2(np.clip(vals, 1, None))
    t_vals = vals[[i for i,l in enumerate(labels) if l=="T"]]
    n_vals = vals[[i for i,l in enumerate(labels) if l=="N"]]
    g, lo, hi, nt, nn = hedges_g(t_vals, n_vals)
    print(f"  Hedges' g = {g:+.3f} [{lo:+.3f}, {hi:+.3f}]  n_T={nt}, n_N={nn}")
    results.append(("GSE40791 (Affymetrix HG-U133 Plus 2.0, Zhang)", g, lo, hi, nt, nn))

out = pd.DataFrame(results, columns=["cohort","g","lo","hi","n_T","n_N"])
out.to_csv(R/"extra_cohorts_nectin4_g.csv", index=False)
print(f"\n[\u2713] {R/'extra_cohorts_nectin4_g.csv'}")
print(out.to_string(index=False))
