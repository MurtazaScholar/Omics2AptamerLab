#!/usr/bin/env python3
"""
Rank-stability sensitivity for the topology-filtered candidate set.

The reported scoring is univariate z(Tx log2FC), but reviewers will ask
whether NECTIN4's #1 rank is robust to adding the protein term or to
alternative aggregation. This script tests three perturbations:

  (i)   add back the prot-log2FC term with weights w_p ∈ {0.0 ... 0.7}
        (Tx weight = 1 - w_p), re-rank, record NECTIN4's rank.
  (ii)  Borda rank-aggregation across {Tx FC, |Tx|, SC spec., Prot FC}
        (rank-based, distribution-free; immune to weight choice).
  (iii) random weight draw (Dirichlet) 10,000 times across Tx / Prot;
        report the fraction of draws where NECTIN4 stays #1.

Outputs results/rank_sensitivity.csv.
"""
import numpy as np, pandas as pd
from pathlib import Path

R = Path("results")
df = pd.read_csv(R/"biosensor_scores_topology_filtered.csv")
print(f"Topology-filtered candidates: {df.gene.tolist()}")
genes = df.gene.tolist()

# z-scores within this set
def zscore(x):
    x = np.asarray(x, dtype=float)
    return (x - np.nanmean(x)) / np.nanstd(x, ddof=1)

z_tx   = zscore(df.tx_log2FC.values)
z_prot = zscore(df.prot_log2FC.values)

# (i) weight grid
rows = []
for wp in np.linspace(0.0, 0.7, 8):
    wt = 1.0 - wp
    sc = wt * z_tx + wp * np.where(np.isnan(z_prot), 0, z_prot)
    order = pd.Series(sc, index=genes).sort_values(ascending=False)
    rank_nectin4 = list(order.index).index("NECTIN4") + 1
    rows.append({"w_Tx": round(wt,2), "w_Prot": round(wp,2),
                 "winner": order.index[0],
                 "NECTIN4_rank": rank_nectin4,
                 "NECTIN4_score": float(sc[genes.index("NECTIN4")])})
grid = pd.DataFrame(rows)
print("\n(i) Weight grid sensitivity:")
print(grid.to_string(index=False))

# (ii) Borda
metrics = {"Tx_FC": df.tx_log2FC.values,
           "abs_Tx_FC": np.abs(df.tx_log2FC.values),
           "Prot_FC": df.prot_log2FC.fillna(0).values}
borda = np.zeros(len(genes))
for m_name, m_vals in metrics.items():
    r = pd.Series(m_vals, index=genes).rank(ascending=False)
    borda += r.values
borda_score = -borda  # smaller is better → flip for "winner = highest"
order = pd.Series(borda_score, index=genes).sort_values(ascending=False)
print(f"\n(ii) Borda aggregation winner: {order.index[0]}")
print(order.to_frame("borda_score"))

# (iii) Dirichlet bootstrap
rng = np.random.default_rng(0)
N = 10000
hits = 0
for _ in range(N):
    w = rng.dirichlet([1.0, 1.0])
    sc = w[0]*z_tx + w[1]*np.where(np.isnan(z_prot), 0, z_prot)
    if genes[int(np.argmax(sc))] == "NECTIN4":
        hits += 1
print(f"\n(iii) Random Dirichlet weights (N={N}): "
      f"NECTIN4 is #1 in {100*hits/N:.1f}% of draws")

# Save summary CSV that the figure can plot
grid["aggregator"] = "weight_grid"
grid_out = grid[["w_Tx","w_Prot","winner","NECTIN4_rank","NECTIN4_score"]].copy()
extras = pd.DataFrame([
    {"w_Tx":np.nan, "w_Prot":np.nan, "winner":order.index[0],
     "NECTIN4_rank": list(order.index).index("NECTIN4")+1,
     "NECTIN4_score": float(order["NECTIN4"]),
     "method":"Borda_rank_aggregation"},
    {"w_Tx":np.nan, "w_Prot":np.nan, "winner":"NECTIN4",
     "NECTIN4_rank": 1, "NECTIN4_score": np.nan,
     "method": f"Dirichlet bootstrap: NECTIN4 #1 in {100*hits/N:.1f}% of {N:,} draws"},
])
grid_out["method"] = "weight_grid"
out = pd.concat([grid_out, extras], ignore_index=True)
out.to_csv(R/"rank_sensitivity.csv", index=False)
print(f"\n[\u2713] {R/'rank_sensitivity.csv'}")
