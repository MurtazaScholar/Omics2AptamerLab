#!/usr/bin/env python3
"""
Pool 3 independent LUAD T+N microarray cohorts via within-cohort
z-normalisation, then compute a single meta-AUC on the pooled set.
Honest methodologically (handles platform effects by within-cohort
normalisation; no probe-level merging across platforms).

Cohorts:
  GSE19188 LUAD subset  (45 ADC / 65 healthy, HG-U133 Plus 2.0)
  GSE31210              (226 T / 20 N,        HG-U133 Plus 2.0)
  GSE40791  (Zhang)     ( 94 T / 100 N,       HG-U133 Plus 2.0)
"""
import warnings; warnings.filterwarnings("ignore")
import gzip, re
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve

DATA = Path("data"); R = Path("results")
NEC_PROBE = "222860_s_at"

def load_probe(path, probe_id=NEC_PROBE):
    chars = []; vals = None; samples = None
    with gzip.open(path, "rt") as fh:
        in_tbl = False
        for line in fh:
            if line.startswith("!Sample_geo_accession"):
                samples = re.findall(r'"([^"]+)"', line)
            elif line.startswith("!Sample_characteristics_ch1") or line.startswith("!Sample_source_name_ch1") or line.startswith("!Sample_title"):
                chars.append(re.findall(r'"([^"]+)"', line))
            elif line.startswith("!series_matrix_table_begin"):
                in_tbl = True; continue
            elif line.startswith("!series_matrix_table_end"):
                break
            elif in_tbl:
                _id = line.split("\t", 1)[0].strip('"')
                if _id == probe_id:
                    parts = [v.strip().strip('"') for v in line.split("\t")[1:]]
                    vals = np.array([float(v) if v not in ("", "NA", "null") else np.nan
                                      for v in parts])
                    break
    return vals, chars

def classify(s, schema="default"):
    s = s.lower()
    if schema == "gse19188":
        if "healthy" in s or "normal" in s: return "N"
        if "adenocarcinoma" in s or " adc" in s: return "T_ADC"
        if "squamous" in s: return "T_SCC"
        if "large cell" in s: return "T_LCC"
        return "?"
    # default LUAD-only schema
    if "tumor" in s or "tumour" in s or "adenocarcinoma" in s or "luad" in s:
        return "T"
    if "normal" in s or "healthy" in s or "non-tumor" in s or "adjacent" in s:
        return "N"
    return "?"

def per_sample_join(chars):
    n = max(len(cl) for cl in chars) if chars else 0
    return [" | ".join(cl[i] for cl in chars if i < len(cl)) for i in range(n)]

pooled_vals, pooled_y, pooled_src = [], [], []

# GSE19188 LUAD subset only
v19, ch19 = load_probe(DATA/"GSE19188/GSE19188_series_matrix.txt.gz")
labels = [classify(s, "gse19188") for s in per_sample_join(ch19)]
m_adc = np.array([l == "T_ADC" for l in labels]) & (~np.isnan(v19))
m_n   = np.array([l == "N"     for l in labels]) & (~np.isnan(v19))
sel = m_adc | m_n
x = v19[sel]
z = (x - np.nanmean(x)) / np.nanstd(x, ddof=1)
y = np.where(m_adc[sel], 1, 0)
print(f"GSE19188 LUAD: T={m_adc.sum()}, N={m_n.sum()}")
pooled_vals.extend(z); pooled_y.extend(y); pooled_src.extend(["GSE19188"]*len(y))

# GSE31210
v31, ch31 = load_probe(DATA/"GSE31210/GSE31210_series_matrix.txt.gz")
labels = [classify(s) for s in per_sample_join(ch31)]
m_t = np.array([l == "T" for l in labels]) & (~np.isnan(v31))
m_n = np.array([l == "N" for l in labels]) & (~np.isnan(v31))
sel = m_t | m_n
x = v31[sel]
if np.nanmax(x) > 50:
    x = np.log2(np.clip(x, 1, None))
z = (x - np.nanmean(x)) / np.nanstd(x, ddof=1)
y = np.where(m_t[sel], 1, 0)
print(f"GSE31210     : T={m_t.sum()}, N={m_n.sum()}")
pooled_vals.extend(z); pooled_y.extend(y); pooled_src.extend(["GSE31210"]*len(y))

# GSE40791
v40, ch40 = load_probe(DATA/"GSE40791/GSE40791_series_matrix.txt.gz")
labels = [classify(s) for s in per_sample_join(ch40)]
m_t = np.array([l == "T" for l in labels]) & (~np.isnan(v40))
m_n = np.array([l == "N" for l in labels]) & (~np.isnan(v40))
sel = m_t | m_n
x = v40[sel]
z = (x - np.nanmean(x)) / np.nanstd(x, ddof=1)
y = np.where(m_t[sel], 1, 0)
print(f"GSE40791     : T={m_t.sum()}, N={m_n.sum()}")
pooled_vals.extend(z); pooled_y.extend(y); pooled_src.extend(["GSE40791"]*len(y))

pooled_vals = np.array(pooled_vals)
pooled_y    = np.array(pooled_y)

# Drop NaN if any
ok = ~np.isnan(pooled_vals)
pooled_vals = pooled_vals[ok]; pooled_y = pooled_y[ok]

auc = roc_auc_score(pooled_y, pooled_vals)
if auc < 0.5:
    pooled_vals = -pooled_vals; auc = 1 - auc
fpr, tpr, _ = roc_curve(pooled_y, pooled_vals)

print(f"\n══════════════════════════════════════════════")
print(f"  POOLED META-AUC  (3 LUAD cohorts, within-cohort z-normalised)")
print(f"  Total: n = {sum(pooled_y==1):,} tumour / {sum(pooled_y==0):,} normal")
print(f"  AUC   = {auc:.3f}")
print(f"══════════════════════════════════════════════")

# Bootstrap CI
rng = np.random.default_rng(0)
n_boot = 2000
boots = []
N = len(pooled_y)
for _ in range(n_boot):
    idx = rng.integers(0, N, N)
    try:
        a = roc_auc_score(pooled_y[idx], pooled_vals[idx])
        boots.append(a if a >= 0.5 else 1-a)
    except Exception:
        pass
ci_lo, ci_hi = np.percentile(boots, [2.5, 97.5])
print(f"  95% CI = [{ci_lo:.3f}, {ci_hi:.3f}]  (bootstrap N={n_boot})")

# Save for figure use
out = pd.DataFrame({"fpr": fpr, "tpr": tpr})
out.to_csv(R/"pooled_meta_roc.csv", index=False)
np.savez(R/"pooled_meta_auc.npz",
         auc=auc, ci_lo=ci_lo, ci_hi=ci_hi,
         n_tumour=int(sum(pooled_y==1)),
         n_normal=int(sum(pooled_y==0)),
         fpr=fpr, tpr=tpr)
print(f"\n[\u2713] results/pooled_meta_roc.csv + results/pooled_meta_auc.npz")
