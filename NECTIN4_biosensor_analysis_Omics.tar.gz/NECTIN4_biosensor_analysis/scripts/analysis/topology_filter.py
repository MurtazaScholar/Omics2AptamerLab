#!/usr/bin/env python3
"""
Topology hard-filter for biosensor analyte selection.
Defines analyte = "single-pass TM / GPI-anchored protein with surface ectodomain,
not predominantly soluble-shed." This filter is applied BEFORE composite scoring
so that soluble / secreted candidates (CEACAM5, SPP1, MMP9, MDK, cytokines, ...)
drop out at the topology step, not via post-hoc rescue.

Annotations are hand-curated from UniProt (human reference) + primary literature
on shed kinetics. Each gene tagged:
  topology      = TM_single_pass | GPI | secreted | TM_multi_pass
  has_ectodomain = True/False
  shed_dominant  = True if circulating soluble form is the principal analyte
Source notes are stored in the `evidence` column for transparency.
"""
import pandas as pd
from pathlib import Path

R = Path("results")

# Hand-curated topology + shed annotation for the 18 aptamer-compatible candidates
# Sources: UniProt subcellular location + topology; PMID-cited shed literature.
TOPOLOGY = {
    # gene       topology         has_ecto shed_dominant  evidence
    "CEACAM5":   ("GPI",          True,    True,  "GPI-anchored ectodomain; circulating CEA is principal clinical analyte (PMID 16204678)"),
    "SPP1":      ("secreted",     False,   True,  "Secreted phosphoprotein; no TM/GPI anchor (UniProt P10451)"),
    "NECTIN4":   ("TM_single_pass", True,  False, "Type I single-pass TM with 3 Ig-like ectodomains; EV-displayed (UniProt Q96NY8; PMID 30575675)"),
    "MMP9":      ("secreted",     False,   True,  "Secreted matrix metalloproteinase (UniProt P14780)"),
    "MDK":       ("secreted",     False,   True,  "Secreted heparin-binding growth factor (UniProt P21741)"),
    "LCN2":      ("secreted",     False,   True,  "Secreted lipocalin (UniProt P80188)"),
    "IGFBP3":    ("secreted",     False,   True,  "Secreted IGF binding protein (UniProt P17936)"),
    "EPCAM":     ("TM_single_pass", True,  False, "Type I single-pass TM, large ectodomain, EV cargo (UniProt P16422)"),
    "WFDC2":     ("secreted",     False,   True,  "Secreted whey-acidic-protein (HE4); soluble serum marker (UniProt Q14508)"),
    "POSTN":     ("secreted",     False,   True,  "Secreted ECM protein periostin (UniProt Q15063)"),
    "TIMP1":     ("secreted",     False,   True,  "Secreted protease inhibitor (UniProt P01033)"),
    "CCL2":      ("secreted",     False,   True,  "Secreted chemokine (UniProt P13500)"),
    "IL1B":      ("secreted",     False,   True,  "Secreted cytokine (UniProt P01584)"),
    "AXL":       ("TM_single_pass", True,  True,  "Single-pass RTK; ectodomain is heavily shed as sAXL serum marker (PMID 24375645)"),
    "CD44":      ("TM_single_pass", True,  True,  "Single-pass TM; ectodomain shed by ADAM/MMP as sCD44 (PMID 12376544)"),
    "FOLR1":     ("GPI",          True,    False, "GPI-anchored folate receptor with surface ectodomain; minimal shedding (UniProt P15328)"),
    "IL6":       ("secreted",     False,   True,  "Secreted cytokine (UniProt P05231)"),
    "PTN":       ("secreted",     False,   True,  "Secreted heparin-binding growth factor pleiotrophin (UniProt P21246)"),
}

scores = pd.read_csv(R/"biosensor_scores_refitted.csv")

ann_rows = []
for g, (topo, has_ecto, shed, ev) in TOPOLOGY.items():
    ann_rows.append({"gene":g, "topology":topo, "has_ectodomain":has_ecto,
                     "shed_dominant":shed, "evidence":ev})
ann = pd.DataFrame(ann_rows)
df = scores.merge(ann, on="gene", how="left")

# Filter 1: must be membrane-anchored (TM_single_pass or GPI) with an ectodomain
mask_membrane = df.topology.isin(["TM_single_pass","GPI"]) & df.has_ectodomain
n_membrane = mask_membrane.sum()
print(f"After topology filter (single-pass TM or GPI, with ectodomain): {n_membrane}")
print("  →", df.loc[mask_membrane, "gene"].tolist())

# Filter 2: not predominantly soluble-shed (the analyte must remain on the EV membrane)
mask_keep = mask_membrane & (~df.shed_dominant)
n_keep = mask_keep.sum()
print(f"After shed-dominance filter (analyte stays on EV membrane): {n_keep}")
print("  →", df.loc[mask_keep, "gene"].tolist())

# Composite re-score on the filtered set, dropping the Prot term (CPTAC null for NECTIN4)
# Score = z(Tx log2FC) within the filtered subset.  SC spec is unavailable for most
# candidates in the upstream score table; if added later, weight 0.4 Tx + 0.6 SC.
filt = df[mask_keep].copy()
filt["score_topology"] = (filt.tx_log2FC - filt.tx_log2FC.mean()) / filt.tx_log2FC.std(ddof=1)
filt = filt.sort_values("score_topology", ascending=False).reset_index(drop=True)
print("\nFinal ranking on topology-filtered analyte-valid set:")
print(filt[["gene","tx_log2FC","tx_padj","score_topology"]].to_string(index=False))

# Save annotation + filtered scores
ann.to_csv(R/"topology_annotation.csv", index=False)
filt.to_csv(R/"biosensor_scores_topology_filtered.csv", index=False)
print(f"\n[✓] results/topology_annotation.csv")
print(f"[✓] results/biosensor_scores_topology_filtered.csv")
