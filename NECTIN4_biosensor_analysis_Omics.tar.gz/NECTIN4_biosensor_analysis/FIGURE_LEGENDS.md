# Figure legends — Lung-biosensor NECTIN4 manuscript

Final legends for the three main figures + the curated supplementary
set (6 figures, S1–S6). Narrative reframed from "NECTIN4 is
overexpressed" to "an EV-sensor target-nomination algorithm".

Supplementary figures dropped during curation: the mRNA–protein
discordance dedicated panel (central admitted ambiguity, with no
direct LUAD-plasma-EV NECTIN4 dataset available to plug the gap)
and the clinical-association null panels (Cox HR=0.88 P=0.18,
Stage-I KM log-rank P=0.043 marginal). The retained S4 keeps only
the strong positive HPA IHC normal-tissue baseline + pan-cancer
prognostic landscape.

---

## Figure 1 — Topology-constrained selection cascade

**A topology-constrained selection pipeline nominates NECTIN4 as an
extracellular-vesicle–tractable surface analyte in lung adenocarcinoma.**

(a) Target-nomination workflow: bulk transcriptomes (TCGA-LUAD, n = 601),
proteomes (CPTAC, n = 220), a NECTIN4-centred co-expression neighbourhood,
and two scRNA-seq datasets (208 k + 117 k cells) feed a selection module
whose output specification is a SELEX-tractable, EV-displayable ectodomain.

(b) PRISMA-style selection flowchart. Each step reports the survivor
count, the filter criterion (right of each arrow), and the excluded
count with reason (far right). 16,042 expressed transcripts → 2,836
DEGs (Wilcoxon T vs N, |log₂FC| > 1, BH-padj < 0.05) → 61 secreted /
surface proteins (HPA Subcellular Localization ∈ {Cell membrane,
Secreted}) → 18 with a folded extracellular domain amenable to de novo
aptamer SELEX → 6 single-pass-TM or GPI-anchored with surface ectodomain
→ 3 not predominantly soluble-shed (CEACAM5, AXL, CD44 excluded as
shed-dominant) → 3 finalists (NECTIN4, EPCAM, FOLR1) ranked by signed-z
on Tx log₂FC → NECTIN4 selected after a healthy-lung baseline tiebreaker
(HPA IHC: NECTIN4 not detected vs EPCAM medium; scRNA: 12 % vs 70 %
positive in normal-lung epithelium) that defines the EV-biosensor
noise floor.

(c) DEG volcano; NECTIN4 (orange) shown among the surface-ectodomain
candidates.

(d) NECTIN4 mRNA, normal (n = 59) vs tumour (n = 542); FC ≈ 4.3×,
P = 7.1×10⁻²⁹ (Wilcoxon).

(e) Tumour-vs-normal effect size (Hedges' g) by AJCC stage; a large effect
is present from Stage I (g = 2.08), consistent with an early-detection
analyte.

(f) Transcriptome AUC reported as a discovery-stage proxy across three
honestly-disclosed cohorts: TCGA Stage I vs adjacent normal
(n = 233 vs 59, RNA-seq) AUC = 0.955; GSE19188 LUAD subset
(n = 46 ADC vs 65 healthy, Affymetrix) AUC = 0.695; GSE31210 pure
LUAD (n = 226 vs 20) AUC = 0.625. The cross-platform attenuation
(0.96 → 0.63) is a technical measurement-transfer loss between
RNA-seq and microarray platforms, not a failure of the target —
directional reproducibility holds in 7 / 7 independent cohorts
(Fig. 2c). The deployable diagnostic performance of the
photonic-crystal sensor will be established prospectively on
patient samples (see Discussion).

(g) Matched tumour–normal pairs (n = 58): 56 / 58 pairs increase in
tumour (paired Wilcoxon P = 3.5×10⁻¹⁰, dz = +1.46), establishing the
mRNA elevation as tumour-purity–independent.

---

## Figure 2 — Surface localization and per-patient ubiquity

**NECTIN4 mRNA elevation is reproducible across cohorts and the
protein-level signal is detected in every LUAD patient examined.**

(a) NECTIN4 mRNA across an independent NSCLC array cohort (GSE19188):
healthy (n = 65) vs LUAD (n = 45) vs SCC + LCC (n = 46);
ADC-vs-healthy P = 5.1×10⁻⁴, AUC = 0.695.

(b) Cross-cohort effect sizes (Hedges' g): positive in 7 / 7
independent cohorts spanning six measurement modalities — RNA-seq
(TCGA-LUAD, g = +1.91), three microarray cohorts (GSE19188 NSCLC,
GSE31210 pure LUAD, GSE40791), the Brägelmann *et al.* ESMO 2025
multi-centre NSCLC TMA cohort (N = 583; NECTIN4 IHC ↔ copy-number
Spearman ρ = 0.67, P = 7 × 10⁻⁸³; g ≈ +0.80), and CPTAC TMT-10
proteomics (g = +0.06). Magnitude is platform-dependent (largest in
RNA-seq, smallest in TMT — see Fig. S4c) but the direction is
reproducible across all modalities. Zelenectide pevedotin (Bicycle
Drug Conjugate BT8009) achieved a 40 % response rate in
NECTIN4-amplified NSCLC versus 0 % in non-amplified patients in
Duravelo-1 (NCT04561362), independently confirming clinical
actionability of the NECTIN4 ectodomain in lung cancer.

(c) Fraction of NECTIN4⁺ epithelial cells across anatomical sites in
Kim 2020 scRNA-seq; elevated in primary tumour and in lymph-node and
brain metastases relative to normal lung (11.5 %).

(d) Per-patient NECTIN4⁺ epithelial fraction in the KNUH LUAD scRNA
cohort (n = 18 donors): every donor is NECTIN4⁺ (range 11 – 73 %,
cohort mean 43 %).

**Demoted to supplementary**: single HPA IHC representative core (now
in the HPA gallery, Fig. S5); KNUH histological-subtype boxplot
(Kruskal-Wallis P = 0.044, marginal; subtype is not core to the
sensor-target nomination story).

---

## Figure 3 — EV-display rationale

**NECTIN4 co-occurs with extracellular-vesicle biogenesis machinery in
malignant LUAD cells, supporting its display on tumour-derived EVs.**

(a) Mean expression of EV-biogenesis and tetraspanin genes, tumour vs
normal (TCGA-LUAD).

(b) Bulk co-expression of EV-machinery genes with NECTIN4 across
tumours; correlations are statistically significant but modest in
magnitude (Pearson r ≤ ~0.3), as expected for bulk-tissue averaging.

(c) Pairwise correlation among NECTIN4 and the canonical tetraspanins
CD9 / CD63 / CD81 / CD82.

(d) Cell-type–resolved expression; NECTIN4 and EV markers are
co-enriched in the epithelial compartment.

(e) Single-cell co-expression in CNV-confirmed malignant cells (inferCNV,
Kim 2020, n = 27 patients): 99.3 % of NECTIN4⁺ malignant cells
co-express ≥ 1 tetraspanin, 94.9 % ≥ 2, and 71.2 % all three
(CD9 / CD63 / CD81); each EV marker is 1.1 – 1.8 × enriched in
NECTIN4⁺ vs NECTIN4⁻ cells (all P < 0.001).

(f) NECTIN family members reported in cancer EVs (ExoCarta / Vesiclepedia
+ literature); NECTIN4 is documented in LUAD A549 small-EV preparations
by mass spectrometry. Direct proteomic profiling of patient-derived
plasma EVs is the designated experimental validation step
(see Discussion).
