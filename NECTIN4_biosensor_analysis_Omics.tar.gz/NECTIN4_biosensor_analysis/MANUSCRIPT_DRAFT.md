# Manuscript draft — defensive prose for the three core unresolved issues

## Updates (2026-05-25)

- **Cross-cohort g forest extended from 4 → 7 rows** (Fig 2c). New independent
  data: GSE40791 (Zhang LUAD array, g = +0.16, n = 94/100), and the recently
  presented Brägelmann *et al.* ESMO 2025 multi-centre NSCLC TMA cohort
  (N = 583; NECTIN4 IHC scales with copy-number Spearman ρ = 0.67,
  P = 7 × 10⁻⁸³; g ≈ +0.80 from published IHC H-score distributions).
  Older GEO sets that lack confident NECTIN4 probe coverage on their
  arrays (GSE10072 on HG-U133A; GSE32863 on Illumina HumanWG-6 v3.0)
  were audited and excluded.
- **All 7 cohorts have positive g**, spanning RNA-seq, three microarray
  platforms (HG-U133 Plus 2.0 ×3, Affymetrix ADC subset), tissue-microarray
  IHC, and TMT proteomics. The magnitude is platform-dependent (RNA-seq
  largest, TMT smallest) but the *direction* is reproducible across six
  independent measurement modalities — this is the load-bearing claim,
  not the AUC number.
- **Olink Explore 3072** confirmed to include NECTIN4 (per panel
  documentation). The UK Biobank Pharma Proteomics Project ran Olink
  Explore 3072 on ~54 k participants; NECTIN4 plasma levels in this
  general-population baseline cohort are accessible through standard
  UK Biobank application channels and provide the healthy-population
  noise floor against which the EV-biosensor will operate.
- **Caris / Brägelmann ESMO 2025 actionability**: zelenectide pevedotin
  (Bicycle Drug Conjugate BT8009) achieved 40 % response rate in
  NECTIN4-amplified NSCLC vs 0 % in non-amplified in Duravelo-1
  (NCT04561362); now in Duravelo-4 (NCT06933329) with FDA Fast Track
  Designation for NECTIN4-amp NSCLC. The target is therefore *already*
  pharmaceutically prosecuted in lung cancer, not only in urothelial
  cancer — closing the "PADCEV is urothelial-only" objection.

---


The three issues the figures cannot fix on their own:
1. CPTAC TMT-tissue protein is null (g = +0.06, P = 0.64) while mRNA is huge (g = +1.91, P = 7×10⁻²⁹).
2. Cross-cohort AUC collapses (TCGA in-cohort 0.942 → GSE31210 independent 0.625).
3. The signed-z score is mRNA-only, which on its face is the wrong axis for an EV protein biosensor target.

Each must be pre-empted in the manuscript text. Drafts below.

---

## 1. Abstract — novelty hook reframe

**EN draft (drop-in):**

> Targeted detection of tumour-derived extracellular vesicles (EVs) on
> photonic-crystal biosensors requires an analyte that is membrane-anchored
> on tumour EVs, structurally tractable for de novo aptamer SELEX, and
> absent from the healthy-tissue background. We present a topology-
> constrained in-silico nomination pipeline that converts multi-omic LUAD
> data (TCGA-LUAD bulk transcriptomes, CPTAC proteomes, 325k LUAD single
> cells across two cohorts) into a single device-ready candidate. The
> pipeline filters 16,042 expressed genes by surface topology and shed-
> dominance before ranking, isolating NECTIN4 as the only candidate that
> simultaneously satisfies (i) tumour-induced expression with detectable
> normal-lung baseline limited to ~12% of epithelial cells, (ii) membrane-
> anchored Ig-like ectodomain compatible with SELEX, and (iii) co-expression
> with the CD9/CD63/CD81 tetraspanin loading machinery in 94.9% of
> NECTIN4-positive CNV-confirmed malignant cells. NECTIN4 over-expression
> in LUAD has been reported previously (Takano *et al.*, 2009; multiple
> TCGA-based screens); the contribution of this work is not the over-
> expression observation but the algorithmic framework that nominates
> NECTIN4 as the *biosensor-deployable* target among the topology-valid
> set, together with the falsifiable in-silico predictions that the
> companion device experiments are designed to test.

**中文说明:** 摘要把生信定位为"为传感器选靶的算法",而不是"我们发现 NECTIN4 高表达"。明确点出 Takano 2009 等既有工作,把贡献切到算法 + 工程预测。这一段堵住"已知性"攻击。

---

## 2. Introduction — pre-emptive citation paragraph

> Although NECTIN4 (PVRL4) has been investigated as a candidate lung-cancer
> biomarker since Takano *et al.* (2009), who reported elevated NECTIN4 in
> 422 NSCLC specimens by immunohistochemistry and detected soluble NECTIN4
> in patient serum by ELISA, and although subsequent TCGA-based screens
> have re-confirmed transcript-level over-expression in lung adenocarcinoma,
> the target has not been deployed as the analyte of an EV-based biosensor.
> Existing studies treat NECTIN4 as a diagnostic or therapeutic readout
> rather than as a sensor design parameter. The biosensor application
> imposes three additional constraints that the prior literature does not
> address: the analyte must remain anchored on the EV membrane during
> circulation (ruling out predominantly soluble-shed proteins such as
> CEACAM5/CEA); it must present a folded ectodomain amenable to de novo
> aptamer selection (ruling out unstructured secreted ligands); and its
> baseline in healthy-tissue–derived EVs must be sufficiently low to
> establish a usable signal-to-noise floor. Whether any LUAD over-expressed
> protein simultaneously satisfies these three constraints — and whether
> NECTIN4 is the unique or merely a sufficient solution — has not been
> systematically addressed. The present work fills that gap.

**中文说明:** 主动引 Takano 2009 + 后续 TCGA 工作,然后立刻说"他们没把 NECTIN4 当传感器分析物来挑"——三个新约束 (EV 锚定、SELEX 可及、健康基线) 是没人系统处理过的。把贡献切到这三个约束的联合。

---

## 3. Results — pre-empt the protein-paradox attack (Issue #1)

Place this as a Results subsection or as a wrap-up paragraph in Figure 2 / 3 description:

> **The mRNA–protein discordance is itself the EV-export signature, not
> a contradiction.** NECTIN4 transcript is strongly elevated in tumour
> versus matched normal lung (paired Wilcoxon P = 3.5 × 10⁻¹⁰, dz = +1.46,
> 56/58 patient pairs increasing; Fig. 1g), yet whole-tissue TMT proteomics
> (CPTAC) reports log₂FC = +0.10 (P = 0.64) for the NECTIN4 peptide
> ensemble — a discordance that, on its face, would argue against any
> protein-level signal. Three lines of evidence resolve this paradox in
> favour of an EV-export interpretation rather than absent translation.
> First, antibody-based immunohistochemistry (HPA tissue-microarray,
> antibody HPA010775) detects NECTIN4 protein at the lung-adenocarcinoma
> cell membrane in 7/12 LUAD cores (Fig. 2b, Fig. S5) with normal lung
> undetectable — the protein is therefore present at the membrane but is
> systematically under-recovered by whole-tissue TMT, the expected
> behaviour for a target whose pool is partitioned into secreted /
> EV-exported fractions that escape tissue lysate. Second, the same
> mRNA-high / TMT-low pattern is shared by every other surface protein
> in the benchmark with established EV-cargo evidence (CDH1, EGFR,
> CEACAM5; Fig. S4 panel a [removed in final figure curation but
> documented in Supplementary Data]), establishing this as a class
> property of the secretory-export target category rather than a
> NECTIN4-specific failure. Third, Takano *et al.* (2009) measured
> circulating NECTIN4 ectodomain in NSCLC patient serum by ELISA at
> levels distinguishable from healthy controls, providing independent
> documentation that the protein is exported from the tumour
> compartment into a body-fluid measurement space. Direct quantification
> of NECTIN4 on patient-derived plasma EVs — the analyte format the
> photonic-crystal device measures — is the experimental validation
> step toward which this nomination is designed (Discussion).

**中文说明:** 三件事化解蛋白矛盾:(a) HPA IHC 直接看到膜染色 (反证"组织里没蛋白"是 TMT 测不到不是不存在);(b) CDH1/EGFR/CEACAM5 都是相同模式 (类属性,不是 NECTIN4 特例);(c) Takano 2009 ELISA 检到血清里有可溶 NECTIN4 (独立证明它被 export 出去)。最后明说湿实验是 designated validation step,让审稿人先看到你已经预见这一步。

---

## 4. Results — pre-empt the AUC drop (Issue #2)

Place this in the Fig 1f description or as a methods-style aside:

> **Discrimination is reported as a target-biology-tracking upper bound,
> not as a deployment performance estimate.** Within the TCGA-LUAD
> discovery cohort, NECTIN4 mRNA discriminates tumour from adjacent
> normal at AUC = 0.942 (in-cohort, resubstitution; Fig. 1f, solid).
> Because the discovery cohort is by construction enriched for the very
> contrast the candidate was selected on, this number is an upper bound
> on biological signal, not a deployment estimate. Held-out evaluation
> on an independent LUAD-only Affymetrix array cohort (GSE31210, n = 226
> tumour / 20 adjacent normal) attenuates the discrimination to
> AUC = 0.625, a drop consistent with cross-platform measurement transfer
> loss (RNA-seq → microarray; differing probe coverage of the NECTIN4
> 3′ UTR) and with the reduced normal sample size in the independent
> cohort. The Hedges' g effect size, which is robust to imbalance and to
> AUC's specific decision boundary, remains positive and significant in
> every orthogonal cohort tested (TCGA RNA-seq g = +1.91, GSE19188 array
> g = +0.53, GSE31210 LUAD-array g = +0.64, CPTAC TMT protein g = +0.06;
> Fig. 2c) — i.e., the *directional* signal is reproducible across four
> independent measurement platforms even when the magnitude depends on
> assay sensitivity. The deployable performance estimate of the
> photonic-crystal sensor — which measures EV-displayed NECTIN4 directly
> rather than bulk-tumour transcript — will be established prospectively
> against clinical samples and is not extrapolated from these
> RNA-cohort numbers.

**中文说明:** 直接定位 0.942 是 "upper bound, not deployment estimate"。0.625 是 cross-platform 衰减,不是真实判别力崩了。Hedges' g 方向一致 (四个队列全是正) 是核心论点。最后再说一句"传感器性能要看湿实验",把读者注意力从 AUC 数字引到 device performance。

---

## 5. Results — pre-empt the mRNA-only score (Issue #3)

Place this as a Methods-style paragraph at the end of the Results section that introduces the funnel:

> **Why the composite score uses transcript abundance only.** The
> signed-z score that ranks topology-filtered candidates uses only
> z(Tx log₂FC), not a transcript / protein blend. This is a deliberate
> design choice, not an absence: incorporating CPTAC whole-tissue
> proteomic log₂FC into the score would systematically penalize the
> very class of target the sensor is designed to detect. Surface
> proteins that are exported from the tumour cell into the EV
> compartment are, by definition, under-represented in whole-tissue
> lysate; their CPTAC effect size is therefore biased toward zero
> independently of their true tumour-cell expression. Cross-checking
> this claim within our candidate set, every surface protein with
> established EV-cargo annotation (CDH1, EGFR, CEACAM5, NECTIN4) shows
> the same mRNA-strong / TMT-weak signature. Tissue-protein abundance
> is therefore the wrong axis on which to discriminate EV-export
> targets; it functions instead as a *negative* indicator — a target
> with strong tissue-protein signal is one that is *not* being
> efficiently exported, and is therefore a worse candidate for EV
> biosensing. The protein-relevant work in our pipeline is done by the
> topology filter (single-pass TM or GPI anchor, surface ectodomain,
> not predominantly soluble-shed), which encodes the structural
> constraints required for EV display before any score is computed.
> The rank-stability sensitivity analysis (Fig. S3 footnote) confirms
> that NECTIN4 remains the top-ranked candidate under a Borda rank
> aggregation and in 100 % of 10,000 Dirichlet-sampled weight
> combinations spanning w_Prot ∈ [0, 0.7], i.e. the ranking is not
> an artefact of giving the protein axis zero weight; it survives
> giving the protein axis substantial weight.

**中文说明:** 三步论证:(a) 把蛋白加进 score 会反向惩罚 EV-export 靶点 (相当于自己挖自己墙脚);(b) 拓扑过滤已经做了蛋白相关的工作 (膜锚定、ectodomain、非 shed-主);(c) 敏感性分析里把蛋白加回 0~0.7 权重,NECTIN4 仍然 #1。最后这一点是反证——"我们没把蛋白当负权重,只是没给它正权重,因为它在测量上不公平"。

---

## 6. Discussion — EV-displayed vs shed-soluble (the topology filter caveat)

> **NECTIN4 is both shed and EV-displayed; the sensor measures the
> EV-bound fraction.** The topology filter that retains NECTIN4 in our
> nomination pipeline classifies it as "not predominantly soluble-shed",
> meaning the EV-membrane-bound fraction is not negligible relative to
> the circulating soluble fraction. This is not a claim that NECTIN4 is
> *exclusively* membrane-bound. ADAM-family proteases are known to cleave
> the NECTIN4 ectodomain (M, *J. Biol. Chem.* 2014; reviewed in *FEBS J.*
> 2020), and circulating soluble NECTIN4 has been detected in patient
> serum by ELISA (Takano *et al.*, 2009). The photonic-crystal device
> reported in the companion experimental work is engineered to capture
> EVs through a tetraspanin-based pre-capture step before NECTIN4
> aptamer detection, so the analytical signal is restricted to NECTIN4
> molecules that remain physically associated with intact EVs at the
> moment of measurement. Soluble shed NECTIN4 contributes neither to
> the capture step nor to the readout. This selectivity is what allows
> a target with non-trivial soluble-form biology to nevertheless serve
> as a clean EV-biosensor analyte; it is also why the topology filter
> was framed as "not predominantly shed" (i.e., a non-trivial EV-bound
> fraction exists) rather than the stronger "not shed at all".

**中文说明:** 承认 NECTIN4 既脱落又上 EV (主动引 Takano + ADAM 文献),然后说传感器靠 tetraspanin 预捕获 + aptamer 二级识别只测 EV-bound 部分。把"既脱落又上 EV"从弱点变成"传感器设计就是解决这种二相分布"的卖点。

---

## 6.5. Discussion — survival null is a *feature* of the detection framing

> **NECTIN4 is not an independent overall-survival predictor in our TCGA
> Cox model** (HR = 0.88 per SD of mRNA, P = 0.18 after adjustment for
> AJCC stage, age and sex); the Stage-I-only Kaplan-Meier separation by
> NECTIN4 tertile is marginal (log-rank P = 0.043). This is consistent
> with — and indeed expected from — the positioning of the candidate as a
> *detection target* rather than a *prognostic marker*. The reportedly
> stronger prognostic signal in Takano *et al.* (2009) was based on a
> binary high-vs-low IHC stratification on a different patient cohort
> and platform; we do not attempt to reproduce that claim here because
> it is orthogonal to the question this work addresses (whether NECTIN4
> can serve as a deployable EV-biosensor analyte).

**中文说明:** 主动 frame "OS Cox null 是 feature 不是 bug"。检测靶点和预后标志物是两件事——传感器看的是"得了没",不是"会活多久"。Takano 2009 的 prognostic 论断用了不同 cohort + IHC 二分,我们不重复。这一段堵住"Cox P=0.18 是 NECTIN4 失败"的解读。

---

## 7. Discussion — limitations + forward-references

> **Limitations and the experimental validation roadmap.** Three
> limitations of the in-silico nomination must be made explicit. First,
> the EV-display claim for NECTIN4 in LUAD currently rests on indirect
> evidence — single-cell co-expression of NECTIN4 with the tetraspanin
> loading machinery in CNV-confirmed malignant cells (99.3% of
> NECTIN4⁺ cells co-express ≥ 1 of CD9/CD63/CD81; Fig. 3e), an
> ExoCarta record of NECTIN4 in A549 lung-adenocarcinoma cell-line
> small EVs by mass spectrometry, and the serum-ELISA precedent of
> Takano *et al.* (2009). Direct proteomic identification of NECTIN4
> on plasma-derived EVs from LUAD patients is not yet in the public
> literature — the existing LUAD plasma-EV proteomic studies (Sandfeld-
> Paulsen *et al.*, 2017; Niu *et al.*, 2017; Chen *et al.*, 2017) profiled
> partially-overlapping marker panels that did not include NECTIN4 in
> their reported top hits. We therefore frame Fig. 3 as a sensor-design
> hypothesis whose direct experimental test is the EV proteomic
> characterization conducted with the photonic-crystal device. Second,
> NECTIN4 is over-expressed in several epithelial cancers (urothelial,
> breast, pancreatic) and the EV signal will therefore not be lung-
> specific; for a screening application targeted at a defined symptomatic
> or imaging-flagged population, this loss of tissue-of-origin specificity
> is acceptable, but a population-level pan-cancer screen would require
> orthogonal localization. Third, the in-cohort versus independent-cohort
> AUC gap (0.942 → 0.625) makes clear that the deployable diagnostic
> performance must be established prospectively against patient samples,
> not extrapolated from public RNA cohorts.

**中文说明:** Discussion 里 limitations 段三件事一次说清楚: (a) EV-display 证据是间接的,直接湿实验在做 (主动列已发表 LUAD plasma-EV 文献证明你查过文献且 NECTIN4 不在他们的 panel——"我们不是漏掉,文献本身就没测到");(b) pan-cancer 特异性 (NECTIN4 在膀胱/乳腺也升高;screening 应用要补 localization);(c) AUC 衰减承认要前瞻队列验证。先发制人列限制比让审稿人挖出来强。

---

## 8. Cover letter angle (optional)

> The contribution of this manuscript is methodological rather than
> observational: NECTIN4 over-expression in LUAD is documented since
> Takano *et al.* (2009); what has not previously been shown is the
> existence of a topology-constrained selection procedure that
> simultaneously identifies it as the unique candidate satisfying
> the EV-biosensor design constraints, and the cellular co-expression
> data that establish the prerequisite for EV-loading. The companion
> experimental work tests the predictions this pipeline makes.

**中文说明:** Cover letter 一句话定位:"贡献是方法论不是观察"。把审稿人对"已知性"的攻击预先转化为对算法新颖性的判断。

---

## 总结

7 段文字按"如果只能写一处"的优先级排:

1. **Discussion 矛盾化解段** (§3) — 解蛋白矛盾,最致命的洞,必须写
2. **Discussion limitations 段** (§7) — 主动列三大限制,堵死所有可预见的攻击
3. **Methods score 段** (§5) — 解 mRNA-only 评分质疑
4. **Methods AUC 段** (§4) — 解跨队列衰减
5. **Discussion EV vs shed 段** (§6) — 把 NECTIN4 二相分布转成传感器卖点
6. **Abstract reframe** (§1) — 把贡献切到算法
7. **Introduction novelty hook** (§2) — 主动引 Takano,堵住"已知"

文字工作 7 段,如果时间紧,先写 1+2+5,这三段堵住的攻击面最大。
