#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════
# Reproduce every figure in the NECTIN4 EV-biosensor target-nomination
# analysis. Run from the repository root after placing the input data
# under ./data and the upstream pipeline outputs under ./results
# (see README.md → "Input data").
# ════════════════════════════════════════════════════════════════════
set -euo pipefail
PY="${PYTHON:-python}"

echo "── Upstream analysis ──────────────────────────────────────────"
$PY scripts/analysis/topology_filter.py          # → results/topology_annotation.csv, biosensor_scores_topology_filtered.csv
$PY scripts/analysis/rank_sensitivity.py          # → results/rank_sensitivity.csv
$PY scripts/analysis/extra_cohorts_effectsize.py  # → results/extra_cohorts_nectin4_g.csv
$PY scripts/analysis/auc_options_audit.py         # → results/auc_options_audit.csv
$PY scripts/analysis/pooled_meta_auc.py           # → results/pooled_meta_*.{csv,npz}
$PY scripts/analysis/infercnv_malignancy.py       # → results/sc_cnv_malignancy_with_evgenes.csv

echo "── Main figures ───────────────────────────────────────────────"
$PY scripts/figures/figure1_selection_cascade.py        # → figures/Figure1.{pdf,png}
$PY scripts/figures/figure2_validation.py               # → figures/Figure2.{pdf,png}
$PY scripts/figures/figure3_ev_display.py               # → figures/Figure3.{pdf,png}

echo "── Supplementary figures ──────────────────────────────────────"
$PY scripts/figures/figureS1_S3_qc_candidates.py        # → figures/FigureS1_QC, FigureS3_Candidates
$PY scripts/figures/figureS2_coexpression.py            # → figures/FigureS2_NECTIN4_neighbors
$PY scripts/figures/figureS4_specificity_discordance.py # → figures/FigureS4_specificity_and_discordance
$PY scripts/figures/figureS5_hpa_ihc_gallery.py         # → figures/FigureS5_HPA_IHC
$PY scripts/figures/figureS6_singlecell_ev.py           # → figures/FigureS6_SingleCell_EV

echo "[✓] All figures regenerated under ./figures/"
